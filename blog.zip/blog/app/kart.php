<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\User;

class kart extends Model
{
    protected $table="karts";

    protected $fillable=[
    'user_id',
    'dish_id',
    'order_description',
    'addon_name',
    'special_request',
    'net_price',
    'quantity',
    'sub_total',
    'total',
    ];

    public function Users()
    {
        return hasMany('App\User');
    }
}

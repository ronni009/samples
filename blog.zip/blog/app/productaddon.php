<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\addon;

class productaddon extends Model
{
	protected $table="productaddons";

    protected $fillable=['product_name','addon_id','status'];

    public function addon()
    {
    	return hasMany('App\addon');
    }
}

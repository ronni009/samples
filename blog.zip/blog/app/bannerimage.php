<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\offer;
use App\dish;

class bannerimage extends Model
{
    protected $table="bannerimages";

    protected $fillable=['image',
                        'dish_id',
                        'offer_id',
                        //'check1',
                        //'check2',
                        'status',
                        ];

    public function offers()
    {
    	return $this->hasMany('App\offer');
    }
    public function dishes()
    {
    	return $this->hasMany('App\dish');
    }
}

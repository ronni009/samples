<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\dish;

class addonprice extends Model
{

    protected $table = "addonprices";

    protected $fillable=[
    'dish_id',
    'addon_name',
    'product1',
    'product2',
    'product3',
    'product4',
    'product5',
    'product6',
    'price1',
    'price2',
    'price3',
    'price4',
    'price5',
    'price6',
    'check2',
    ];

    public function dish()
    {
    	return $this->hasMany('App\dish');
    }
}

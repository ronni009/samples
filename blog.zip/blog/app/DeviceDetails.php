<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DeviceDetails extends Model
{
	protected $table = "device_details";

	protected $fillable = [
							'user_id',
							'device_id',
    						'gcm_id',
						  ];
}

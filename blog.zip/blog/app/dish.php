<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\category;
use App\addonprice;
use App\bannerimage;

class dish extends Model
{
    protected $table="dishes";

    protected $fillable=[
    'dish_name',
    'description',
    'image',
    'cat_id',
    'foodtype',
    'rest_id',
    ];

    public function category()
    {
    	return $this->hasMany('App\category');
    }
    public function addonprice()
    {
    	return $this->hasMany('App\addonprice');
    }
    public function bannerimages()
    {
        return $this->hasMany('App\bannerimage');
    }
}

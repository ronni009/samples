<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\DeviceDetails;

class RestDeviceController extends Controller
{
    public function postAddDevice(Request $request)
    {
        $response = array();

        $validator = \Validator::make($request->all(),[
            'user_id' => 'required',
            'device_id'   => 'required',
            'gcm_id'  => 'required',
        ]);

            if ($validator->fails()) {
                $response['success'] = false;
                $response['errors'] = $validator->getMessageBag()->toArray();
            }else {
                try {
                    $response['success'] = true;
                    $input = $request->all();
                $response['data'] = DeviceDetails::create([
                        'user_id' => $input['user_id'],
                        'device_id' => $input['device_id'],
                        'gcm_id' => $input['gcm_id'],
                        ]);
                } catch(Exception $ex) {
                    $response['success'] = false;
                    $response['errors'] = $ex->getMessage();
                }
            }
            return response()->json($response);
    }
}

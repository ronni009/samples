<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\cart;
use App\cartitem;
use App\orderlist;
use App\offer;
use App\User;
use App\clientlist;
use App\OrderItem;

class RestOrderController extends Controller
{
    public function postAddClient(Request $request)
    {
    		$response = array();

    		$validator = \Validator::make($request->all(),[
    			'client_name' => 'required',
    			'seat_no' => 'required|regex:/^[a-zA-Z0-9\s-]+$/',
    			'mobile_no' => 'required',
    			]);

    		if($validator->fails()){
    			$response['success'] = false;
    			$response['errors'] = $validator->getMessageBag()->toArray();
    		}else{
    		try{
    			$response['success'] = true;

    			$input = $request->all();

                $clientAdd = clientlist::create([
                    'client_name' => $input['client_name'],
                    'seat_no' => $input['seat_no'],
                    'mobile_no' => $input['mobile_no'],
                    'regular' => $input['regular'],
                    ]);

                $response['client_id'] = $clientAdd->id;

    		} catch(Exception $ex){
	    			$response['success'] = false;
	    			$response['error'] = $ex->getMessage();
    			}
    		}
    	return response()->json($response);
    }

    public function postAddOrder(Request $request)
    {
    	$response = array();

    	$validator = \Validator::make($request->all(),[
    			'cart_id' => 'required',
                'client_id'=>'required',
                
    			]);

    		if($validator->fails()){
    			$response['success'] = false;
    			$response['errors'] = $validator->getMessageBag()->toArray();
    		}else{

    				try{
    					$response['success'] = true;
                        $input = $request->all();


    					$clientData = clientlist::findorFail($input['client_id']);
                        $cartData = cart::findorFail($input['cart_id']);
                        $cartItemData = cartitem::where('cart_id',$cartData->id)->get();
    
                       
                            if ($clientData->count()){
                            OrderList::create([
                            'client_id' => $clientData->id,
                            'sub_total' => $cartData->sub_total,
                            'total' => $cartData->total,
                            'default_value' => "order in process",
                            ]);

                        $selectOrderList = OrderList::where('client_id',$input['client_id'])->first();

                        if ($cartItemData->count()) {
                            
                            foreach ($cartItemData as $items) {


                                OrderItem::create([
                                'order_id' => $selectOrderList->id,
                                'dish_id' => $items->dish_id,
                                'offer_id' => $items->offer_id,
                                'restaurant_id' => $items->restaurant_id,
                                'dish_name' => $items->dish_name,
                                'offer_name' => $items->offer_name,
                                'image' => @$items->image,
                                'small' => $items->small,
                                'medium' => $items->medium,
                                'large' => $items->large,
                                'regular' => $items->regular,
                                'addon_name' => $items->addon_name,
                                'addon_price' => $items->addon_price,
                                'special_request' => $items->special_request,
                                'unit_price' => $items->unit_price,
                                'quantity' => $items->quantity,
                                'final_price' => $items->final_price,
                                'default_value' => "N/A",
                                ]);
                            }
                        }
                
                $cartData = cart::findorFail($input['cart_id'])->update([
                    'sub_total' => 0.00,
                    'total' => 0.00,
                    ]);
                $cartItemData = cartitem::where('cart_id',$input['cart_id'])->delete();

                $response['OrderId'] = $selectOrderList->id;
                $response['message'] = "Order placed successfully";

                        }else{
                            $response['success'] = false;
                            $response['error'] = "Client Id not found";
                        }

    				} catch(Exception $ex){
    					$response['success'] = false;
    					$response['error'] = $ex->getMessage();
    				}
       }
       return response()->json($response);
    }
}
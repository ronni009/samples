<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\dish;
use App\dishprice;
use App\addonprice;
use App\offer;
use App\OrderItem;
use App\Orderlist;
use App\clientlist;
use Excel;
use File;

class ReportController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('pages.reports.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $input = $request->all();   
        //print_r($input); die;
        $date_to = Date('y:m:d', strtotime($input['date_to']));
        $date_from = Date('y:m:d', strtotime($input['date_from']));

        if ($input['report_id'] == 1) {
                     $dishData = dish::leftjoin('dishprice','dishes.id','=','dishprice.dish_id')
                                ->leftjoin('addonprices','dishes.id','=','addonprices.dish_id')
                                ->leftjoin('restaurants','dishes.rest_id','=','restaurants.id')
                                ->leftjoin('categories','dishes.cat_id','=','categories.id')
                                ->select('dishes.id','dishes.dish_name','dishes.description',
                                'dishes.image','restaurants.rest_name','categories.category_name',
                                'dishes.foodtype','dishprice.small','dishprice.medium',
                                'dishprice.large','dishprice.regular','addonprices.product1',
                                'addonprices.product2','addonprices.product3','addonprices.product4',
                                'addonprices.product5','addonprices.product6','addonprices.price1',
                                'addonprices.price2','addonprices.price3','addonprices.price4',
                                'addonprices.price5','addonprices.price6','dishes.created_at','dishes.updated_at')
                                ->whereBetween('dishes.created_at',[$date_to,$date_from])->get();

        Excel::create('dishes', function($excel) use($dishData) {
        $excel->sheet('Sheet 1', function($sheet) use($dishData) {
        $sheet->fromArray($dishData);
        });
        })->export('xls');

        }

        if ($input['report_id'] == 2) {
            $offerData = offer::whereBetween('created_at',[$date_to,$date_from])->get();
            
            Excel::create('offers', function($excel) use($offerData) {
            $excel->sheet('Sheet 1', function($sheet) use($offerData) {
            $sheet->fromArray($offerData);
            });
            })->export('xls');

        }

        if ($input['report_id'] == 3) {
            $orderData = Orderlist::leftjoin('order_items','orderlists.id','=','order_items.order_id')
                                  ->leftjoin('clientlists','orderlists.client_id','=','clientlists.id')
                                  ->select('orderlists.id','orderlists.client_id','orderlists.sub_total',
                                    'orderlists.total','order_items.id','order_items.order_id','order_items.dish_name',
                                    'order_items.offer_name','order_items.small','order_items.medium',
                                    'order_items.large','order_items.addon_name','order_items.addon_price',
                                    'order_items.special_request','order_items.unit_price','order_items.quantity',
                                    'order_items.final_price','clientlists.id','clientlists.client_name','clientlists.seat_no',
                                    'clientlists.mobile_no','orderlists.created_at','orderlists.updated_at')
                                    ->whereBetween('orderlists.created_at',[$date_to,$date_from])->get();

            Excel::create('offers', function($excel) use($orderData) {
            $excel->sheet('Sheet 1', function($sheet) use($orderData) {
            $sheet->fromArray($orderData);
            });
            })->export('xls');
        }

        return "no results found";
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}

<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Http\Requests;
use App\OrderItem;
use App\Orderlist;
use App\restaurant;
use App\Dish;
use App\clientlist;

class OrdersController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $orderList = Orderlist::where('default_value','!=','Order Delivered')->orderby('id','desc')->get();
        return view('pages.orders.index',compact('orderList'));
    }

    public function index2()
    {
        $orderList = Orderlist::where('default_value','=','Order Delivered')->orderby('id','desc')->get();
        return view('pages.orders.delivered',compact('orderList'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $orderItem = OrderItem::leftjoin('restaurants','order_items.restaurant_id','=','restaurants.id')
                                        ->select('order_items.*','restaurants.rest_name')    
                                        ->where('order_id',$id)->get();

        $orderList = Orderlist::where('id',$id)->first();
        $clientData = orderlist::leftjoin('clientlists','orderlists.client_id','=','clientlists.id')
                                 ->select('clientlists.*')
                                 ->where('orderlists.id',$id)->first();

        return view('pages.orders.show',compact('orderItem','orderList','clientData'));
    }

     public function show2($id)
    {
        $orderItem = OrderItem::leftjoin('restaurants','order_items.restaurant_id','=','restaurants.id')
                                        ->select('order_items.*','restaurants.rest_name')    
                                        ->where('order_id',$id)->get();

        $orderList = Orderlist::where('id',$id)->first();
        $clientData = orderlist::leftjoin('clientlists','orderlists.client_id','=','clientlists.id')
                                 ->select('clientlists.*')
                                 ->where('orderlists.id',$id)->first();
        return view('pages.orders.show2',compact('orderItem','orderList','clientData'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        try{
             //data storing
             $update = $request->all();
             //print_r($update); die;
             //initialization
             Orderlist::findorFail($id)->update([
                'default_value' => $update['default_value'],
                ]);
            } catch(Exception $ex){
            
            echo 'message : ' .$ex->getMessage();
            }
        return redirect()->route('orders.index');
    }

    public function billshow($id)       //bill generating
    {
        $orderItem = OrderItem::leftjoin('restaurants','order_items.restaurant_id','=','restaurants.id')
                                        ->select('order_items.*','restaurants.rest_name')    
                                        ->where('order_id',$id)->get();

        $orderList = Orderlist::findorFail($id)->first();
        $clientData = orderlist::leftjoin('clientlists','orderlists.client_id','=','clientlists.id')
                                 ->select('clientlists.*')
                                 ->where('orderlists.id',$id)->first();

        return view('pages.orders.bill',compact('orderItem','orderList','clientData'));
    }
    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\addon;
use App\productaddon;
use App\category;
use App\dish;
use App\dishprice;
use App\addonprice;
use App\restaurant;

class MenuController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $dish_list=dish::join('categories','dishes.cat_id','=','categories.id')
                         ->join('dishprice','dishes.id','=','dishprice.dish_id')  
                         ->join('restaurants','dishes.rest_id','=','restaurants.id')
                         ->select('dishes.*','restaurants.rest_name','categories.category_name','dishprice.*')->get();
        return view('pages.menu.index',compact('dish_list'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $category_list=category::lists('category_name','id');
        $addon_list=addon::lists('addon_name','id');
        $product_list=productaddon::lists('product_name','product_name');
        $restaurant_name=restaurant::lists('rest_name','id');
        return view('pages.menu.create',compact('category_list','addon_list','product_list','restaurant_name'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {   
        $i=0;
        while ($i==0){
            try{
                $i=1;
                //validation
                $this->validate($request,[
                'dish_name'=>'required|unique:dishes,dish_name',
                'image'   =>'required|image|dimensions:min_width=400,min_height=300|max:1024',
                'rest_id' => 'required',
                'cat_id' => 'required',
                ]);
                //storing data
                $input=$request->except('image');
                $image=$request->image;
                if($image){
                    $imageName=$image->getClientOriginalName();
                    $image->move('images',$imageName);
                    $input['image']=$imageName;
                }
                //insert data
                dish::create([
                    'dish_name'=>trim($input['dish_name']),
                    'description'=>trim($input['description']),
                    'image'=>$input['image'],
                    'cat_id'=>$input['cat_id'],
                    'foodtype'=>$input['foodtype'],
                    'rest_id'=>$input['rest_id'],
                    ]);
            } catch(Exception $ex){
             $i=0;
            echo 'message : ' .$ex->getMessage();
            }
        }
        
        $j=0;
        while ($j==0){
            try{
                $j=1;
                 if ($input['regular'] == null ) {
                    $input['regular']="N/A";
                    }

                    if ($input['small'] == null ) {
                        $input['small']="N/A";
                    }
                    
                    if ($input['medium'] == null ) {
                        $input['medium']="N/A";
                    }
                    
                    if ($input['large'] == null ) {
                        $input['large']="N/A";
                    }
                $dish_id=dish::where('dish_name','=',$input['dish_name'])->first();
                     dishprice::create([
                    'dish_id'=>$dish_id->id,
                    'small'=>$input['small'],
                    'medium'=>$input['medium'],
                    'large'=>$input['large'],
                    'regular'=>$input['regular'],
                    'check1'=>$input['check1'] 
                    ]);
            } catch(Exception $ex){
             $j=0;
            echo 'message : ' .$ex->getMessage();
            }
        }
        
        $k=0;
        while ($k==0){
            try{
                $k=1;
                if($input['product1']=='' && $input['product2']==''&& $input['product3']=='' && $input['product4']=='' &&
                $input['product5']=='' && $input['product6']=='' && $input['price1']=='' && $input['price2']=='' && $input['price3']=='' && 
                $input['price4']=='' && $input['price5']=='' && $input['price6']=='' ){
                $input['product1']="N/A";
                $input['product2']="N/A";
                $input['product3']="N/A";
                $input['product4']="N/A";
                $input['product5']="N/A";
                $input['product6']="N/A";
                $input['price1']="N/A";
                $input['price2']="N/A";
                $input['price3']="N/A";
                $input['price4']="N/A";
                $input['price5']="N/A";
                $input['price6']="N/A";
                }
                $dish_id=dish::where('dish_name','=',$input['dish_name'])->first();
                $addon_price=addonprice::create([
                    'dish_id'=>$dish_id->id,
                    'addon_name'=>$input['addon_name'],
                    'product1'=>$input['product1'],
                    'product2'=>$input['product2'],
                    'product3'=>$input['product3'],
                    'product4'=>$input['product4'],
                    'product5'=>$input['product5'],
                    'product6'=>$input['product6'],
                    'price1'=>$input['price1'],
                    'price2'=>$input['price2'],
                    'price3'=>$input['price3'],
                    'price4'=>$input['price4'],
                    'price5'=>$input['price5'],
                    'price6'=>$input['price6'],
                    'check2'=>$input['check2']  
                    ]);
            } catch(Exception $ex){
             $k=0;
            echo 'message : ' .$ex->getMessage();
            }
        }
        return redirect()->route('menu.index')->with('success','dish added successfully!!');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    { 
        $show_details=dish::join('dishprice','dishes.id','=','dishprice.dish_id')
                            ->join('categories','dishes.cat_id','=','categories.id')
                            ->join('restaurants','dishes.rest_id','=','restaurants.id')
                            ->join('addonprices','addonprices.dish_id','=','dishes.id')
                            ->select('dishes.*','addonprices.*','dishprice.*','categories.*','restaurants.*')
                            ->where('dishes.id','=',$id)->first();
        return view('pages.menu.show',compact('show_details'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $category_list=category::lists('category_name','id');
        $addon_list=addon::lists('addon_name','id');
        $product_list=productaddon::lists('product_name','product_name');
        $edit_dish=dish::find($id);
        $edit_dishprice=dishprice::where('dish_id','=',$id)->first();
        $edit_addonprice=addonprice::where('dish_id','=',$id)->first();   
        $restaurant_name=restaurant::lists('rest_name','id');                         
        return view('pages.menu.edit',compact('edit_dish',
                    'edit_dishprice','edit_addonprice','category_list','addon_list','product_list',
                    'restaurant_name'));                    
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    { 
        $i=0;
        while ($i==0){
            try{
                $i=1;
                //validation
                $this->validate($request,[
                'dish_name'=>'required|unique:dishes,dish_name,'.$id,
                'image'   =>'image|dimensions:min_width=400,min_height=300|max:1024',
                ]);
                //storing data
                $update=$request->except('image');
                $image=$request->image;
                if($image){
                    $imageName=$image->getClientOriginalName();
                    $image->move('images',$imageName);
                    $update['image']=$imageName;
                }else{
                    $update['image']=$request->file;
                }
                //update data
                    $dish_update=dish::where('id','=',$id)->update([
                    'dish_name'=>trim($update['dish_name']),
                    'description'=>trim($update['description']),
                    'image'=>$update['image'],
                    'cat_id'=>$update['cat_id'],
                    'foodtype'=>$update['foodtype'],
                    'rest_id'=>$update['rest_id'],
                    'status'=>$update['status'],
                    ]);
            } catch(Exception $ex){
             $i=0;
            echo 'message : ' .$ex->getMessage();
            }
        }
        $j=0;
        while ($j==0){
            try{
                $j=1;
                    if ($update['regular'] == null ) {
                    $update['regular']="N/A";
                    }

                    if ($update['small'] == null ) {
                        $update['small']="N/A";
                    }
                    
                    if ($update['medium'] == null ) {
                        $update['medium']="N/A";
                    }
                    
                    if ($update['large'] == null ) {
                        $update['large']="N/A";
                    }
                    
                    
                     dishprice::where('dish_id','=',$id)->update([
                    'small'=>$update['small'],
                    'medium'=>$update['medium'],
                    'large'=>$update['large'],
                    'regular'=>$update['regular'],
                    'check1'=>@$update['check1'],
                    ]);
            } catch(Exception $ex){
             $j=0;
            echo 'message : ' .$ex->getMessage();
            }
        }
        
        $k=0;
        while ($k==0){
            try{
                $k=1;
                if($update['product1']==null && $update['product2']==null && $update['product3']==null && $update['product4']==null &&
                $update['product5']==null && $update['product6']==null && $update['price1']==null && $update['price2']==null && $update['price3']==null && 
                $update['price4']==null && $update['price5']==null && $update['price6']==null ){
                $update['product1']="N/A";
                $update['product2']="N/A";
                $update['product3']="N/A";
                $update['product4']="N/A";
                $update['product5']="N/A";
                $update['product6']="N/A";
                $update['price1']="N/A";
                $update['price2']="N/A";
                $update['price3']="N/A";
                $update['price4']="N/A";
                $update['price5']="N/A";
                $update['price6']="N/A";
                }
                $addon_price=addonprice::where('dish_id','=',$id)->update([
                    'addon_name'=>$update['addon_name'],
                    'product1'=>$update['product1'],
                    'product2'=>$update['product2'],
                    'product3'=>$update['product3'],
                    'product4'=>$update['product4'],
                    'product5'=>$update['product5'],
                    'product6'=>$update['product6'],
                    'price1'=>$update['price1'],
                    'price2'=>$update['price2'],
                    'price3'=>$update['price3'],
                    'price4'=>$update['price4'],
                    'price5'=>$update['price5'],
                    'price6'=>$update['price6'],
                    'check2'=>@$update['check2'],
                    ]);
            } catch(Exception $ex){
             $k=0;
            echo 'message : ' .$ex->getMessage();
            }
        }
        return redirect()->route('menu.index')->with('updated','data updated successfully!!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function trial(Request $request)
    {
        $response['query']=$request->id;
        $response['status']="success";
        $response['check']=productaddon::select('product_name')
                        ->where('addon_id','=',$response['query'])->get();
        return Response()->json($response);
    }
}

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\dish;
use App\restaurant;
use App\OrderItem;
use App\Orderlist;
use App\User;
use Auth;

class LoginController extends Controller
{
    public function index()
    {
    	$dish_count = dish::where('status','=','active')->get();
    	$restaurant_count = restaurant::where('status','=','active')->get();
    	$pendingOrder_count = Orderlist::where('default_value','!=','Order Delivered')->get();
        $monthstatus = Orderlist::select('id')->get();
        $orderStatus = Orderlist::select('id')->where('default_value','!=','Order Delivered')->get();

    	if(Auth::user()->hasRole('admin')) {                           //auth check
    	$users_count = User::all();

    	return view('dashboard.dashboard',compact('dish_count','restaurant_count',
    				'users_count','pendingOrder_count','monthstatus','orderStatus'));
    	}

    	return view('dashboard.dashboard',compact('dish_count','restaurant_count','pendingOrder_count','orderStatus'));
    }
}

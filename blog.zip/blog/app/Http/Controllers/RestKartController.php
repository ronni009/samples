<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\cart;
use App\cartitem;
use App\clientlist;
use App\orderlist;
use App\offer;
use App\User;

class RestKartController extends Controller
{
    public function postIndex(Request $request)
    {
    	$response = array();
    	//validation
        $validator = \Validator::make($request->all(),[
            'cart_id' => 'required',
        ]);

        if ($validator->fails()) {
            $response['success'] = false;
            $response['errors'] = $validator->getMessageBag()->toArray();
        }else {
    		try {
    			$response['success'] = true;
                $input = $request->all();
                $cart = cart::findOrFail($input['cart_id']);
                $cartitem = cartitem::where('cart_id',$cart->id)->get();
                $response['cart'] = $cart;
                $response['cartitems'] = $cartitem;

    		} catch(Exception $ex) {
    		  $response['success'] = false;
              $response['error'] = $ex->getMessage();
    		}
    	}
    	
        return response()->json($response);
	}

     public function postAddToCart(Request $request)
    { 
        $response = array();
        //validation
        $validator = \Validator::make($request->all(),[
            'cart_id' => 'required',
            //'dish_id' => 'required',
            //'restaurant_id' => 'required',
            //'dish_name' => 'required',
            //'unit_price' => 'required',
            'quantity' => 'required',
        ]);

        if ($validator->fails()) {
            $response['success'] = false;
            $response['errors'] = $validator->getMessageBag()->toArray();
        }else {
            try {
                $response['success'] = true;
                $input = $request->all();
                $cart = cart::findOrFail($input['cart_id']);

                if ($input['dish_id'] == null) {
                    $input['dish_id'] = "N/A";
                }

                if ($input['restaurant_id'] == null) {
                    $input['restaurant_id'] = "N/A";
                }

                if ($input['offer_id'] == null) {
                    $input['offer_id'] = "N/A";
                }

                if ($input['dish_name'] == null) {
                    $input['dish_name'] = "N/A";
                }

                if ($input['offer_name'] == null) {
                    $input['offer_name'] = "N/A";
                }

                if ($input['special_request'] == null) {
                    $input['special_request'] = "N/A";
                }

                if ($input['unit_price'] != null) {          
                    $unit_price = $input['unit_price'];
                }

                if ($input['small'] == null) {             
                    $input['small'] = "N/A";
                }else {
                    $unit_price = $input['small'];
                }

                if ($input['medium'] == null) {
                    $input['medium'] = "N/A";
                }else {
                    $unit_price = $input['medium'];
                }

                if ($input['large'] == null) {
                    $input['large'] = "N/A";
                }else {
                    $unit_price = $input['large'];
                }

                if ($input['regular'] == null) {
                    $input['regular'] = "N/A";
                }else {
                    $unit_price = $input['regular'];
                }

                if ($input['image'] == null) {
                    $input['image'] = "N/A";
                } 

                if ($input['addon_name'] == null) {
                    $input['addon_name'] = "N/A";
                }

                if ($input['addon_price'] == null) {
                    $input['addon_price'] = "N/A";
                    $addon_price = $input['addon_price'];
                }else {
                    $addon_price = $input['addon_price'] * $input['quantity'];
                }

                $cartItemData = cartitem::create([
                    'cart_id' => $cart->id,
                    'dish_id' => $input['dish_id'],
                    'offer_id' => $input['offer_id'],
                    'restaurant_id' => $input['restaurant_id'],
                    'dish_name' => $input['dish_name'],
                    'offer_name' => $input['offer_name'],
                    'image' => @$input['image'],
                    'small' => $input['small'],
                    'medium' => $input['medium'],
                    'large' => $input['large'],
                    'regular' => $input['regular'],
                    'addon_name' => $input['addon_name'],
                    'addon_price' => $addon_price,
                    'special_request' => $input['special_request'],
                    'unit_price' => $unit_price,
                    'quantity' => $input['quantity'],
                    'final_price' => ($unit_price * $input['quantity'] + $addon_price ),
                ]);


                $cartitem = cartitem::where('cart_id',$cart->id);
                if ($cartitem->count()) {
                    $subtotal = 0;
                    $quantity_total = 0;
                    $cartitemData = $cartitem->get();
                    foreach ($cartitemData as $item) {
                       $subtotal = $subtotal + $item->final_price;                              
                       $quantity_total = $quantity_total + $item->quantity;
                    }
                }

                $cart->sub_total = $subtotal;
                $cart->total = $subtotal;
                $cart->save();

                $cart_items = cartitem::where('cart_id',$cart->id)->get();

                $response['cart'] = $cart;
                $response['total_items'] = $quantity_total;
                $response['cartitems'] = $cart_items;
                $response['msg'] = "Dish added to cart";
            } catch(Exception $ex) {
              $response['success'] = false;
              $response['error'] = $ex->getMessage();
            }
        }
        
        return response()->json($response);
    }

    public function postDelete(Request $request)
    {
        $response = array();
        //validation
        $validator = \Validator::make($request->all(),[
            'cartitem_id' => 'required',
        ]);

        if ($validator->fails()) {
            $response['success'] = false;
            $response['errors'] = $validator->getMessageBag()->toArray();
        }else {
            try {
                $response['success'] = true;
                $input = $request->all();
                $cartitemData = cartitem::findOrFail($input['cartitem_id']);
                $cartId = $cartitemData->cart_id;
                $cartitemData->delete();

                $cart = cart::findOrFail($cartId);

               

                $cartitems = cartitem::where('cart_id',$cart->id);
                if ($cartitems->count()) {
                    $subtotal = 0;
                    $quantity_total = 0;
                    $cartitemsData = $cartitems->get();
                    foreach ($cartitemsData as $item) {
                       $subtotal = $subtotal + $item->final_price;  
                       $quantity_total = $quantity_total + $item->quantity;                            
                    }
                }else{
                    $response['succes'] = true;
                    $cartDelete = cart::findOrFail($cart->id)->update([
                        'sub_total' => 0.00,
                        'total' => 0.00,
                        ]);
                    $response['msg'] = "Successfully removed items from cart";
                    return response()->json($response);
                }

                $cart->sub_total = $subtotal;
                $cart->total = $subtotal;
                $cart->save();
                
                $cart_items = cartitem::where('cart_id',$cart->id)->get();

                $response['cart'] = $cart;
                $response['total_items'] = $quantity_total;
                $response['cartitems'] = $cart_items;

                $response['msg'] = "Items removed Successfully";
            } catch(Exception $ex) {
              $response['success'] = false;
              $response['error'] = $ex->getMessage();
            }
        }
        
        return response()->json($response);
    }
}

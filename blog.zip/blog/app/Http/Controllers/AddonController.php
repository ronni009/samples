<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Http\Requests;
use App\addon;

class AddonController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $addon=addon::all();
        return view('pages.addon.index',compact('addon'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('pages.addon.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $i=0;
        while ($i==0){
            try{
                $i=1;
                //validation
                $this->validate($request,[
                'addon_name'=>'required|unique:addons,addon_name',
                ]);
                //store request
                $input=$request->all();
                addon::create($input);
                } catch(Exception $ex){
                    $i=0;
                    echo 'message : ' .$ex->getMessage();
                 }   
        }
        return redirect()->route('addon.index')->with('success','Addon added successfully!');        
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $addon_show=addon::find($id);
        return view('pages.addon.edit',compact('addon_show'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $i=0;
        while ($i==0){
            try{
                $i=1;
                //validation
                $this->validate($request,[
                'addon_name'=>'required|unique:addons,addon_name,'.$id, 
                ]);
                //store request
                $update=$request->all();
                addon::find($id)->update($update);
                } catch(Exception $ex){
                 $i=0;
                echo 'message : ' .$ex->getMessage();
                }
        }
        
        
        return redirect()->route('addon.index')->with('updated','addon successfully updated!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}

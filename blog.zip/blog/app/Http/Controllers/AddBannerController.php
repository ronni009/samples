<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Http\Requests;
use App\bannerimage;
use App\offer;
use App\dish;
use App\restaurant;
use App\category;

class AddBannerController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $image_detail=bannerimage::leftjoin('dishes','dishes.id','=','bannerimages.dish_id')
                                 ->leftjoin('offers','offers.id','=','bannerimages.offer_id')
                                 ->select('dishes.dish_name','offers.offer_name','bannerimages.*')
                                 ->get();
       // $image_detail=bannerimage::all()->take(3);
        return view('pages.banner.index',compact('image_detail'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $dish_detail=dish::lists('dish_name','id');
        $offer_detail=offer::lists('offer_name','id');
        return view('pages.banner.create',compact('dish_detail','offer_detail'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {   
        $i=0;
        while ($i==0){
            try{
                $i=1;
                //validation
                $this->validate($request,[
                    'image'   =>'required|image|dimensions:min_width=400,min_height=300|max:1024',
                    ]);
                //data storing
                $input=$request->except('image');
                $image=$request->image;
                if($image){
                    $imageName=$image->getClientOriginalName();
                    $image->move('images',$imageName);
                    $input['image']=$imageName;
                }
                //initialize
                bannerimage::create([
                    'image'=>$input['image'],
                    'dish_id'=>$input['dish_id'],
                    'offer_id'=>$input['offer_id'],
                    'status'=>'active',
                    'check1'=>$input['check1'],
                    'check2'=>$input['check2'],
                    ]);
            } catch(Exception $ex){
             $i=0;
            echo 'message : ' .$ex->getMessage();
            }
        }
        //redirect view
        return redirect()->route('banner.index')->with('success','image inserted successfully!!');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $image_detail=bannerimage::find($id);
        $dish_detail=dish::lists('dish_name','id');
        $offer_detail=offer::lists('offer_name','id');
        return view('pages.banner.edit',compact('image_detail','dish_detail','offer_detail'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $i=0;
        while ($i==0){
            try{
                $i=1;
                //validation
                $this->validate($request,[
                'image'   =>'image|dimensions:min_width=400,min_height=300|max:1024',
                 ]);
                //storing data 
                $update=$request->except('image');
                $image=$request->image;
                if($image){
                $imageName=$image->getClientOriginalName();
                $image->move('images',$imageName);
                $update['image']=$imageName;
                }else{
                    $update['image']=$request->file;
                }
                
                if ($update['dish_id'] != null && $update['offer_id'] != null) {
                    return redirect()->route('banner.index')->with('unsuccessfull','Please choose any one list');
                }

                if ($update['dish_id'] == null) {
                    $update['dish_id'] = 0;
                }

                if ($update['offer_id'] == null) {
                    $update['offer_id'] = 0;
                }

                //initialization
                bannerimage::find($id)->update([
                    'image'=>$update['image'],
                    'dish_id'=>$update['dish_id'],
                    'offer_id'=>$update['offer_id'],
                    'status'=>$update['status'],
                    //'check1'=>$update['check1'],
                    //'check2'=>$update['check2'],
                ]);
             } catch(Exception $ex){
             $i=0;
                echo 'message : ' .$ex->getMessage();
            }
        }
        return redirect()->route('banner.index')->with('updated','banner image updated successfully!!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\restaurant;

class AddRestaurantController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $restaurant=restaurant::all();
        return view('pages.restaurant.index',compact('restaurant'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('pages.restaurant.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $i=0;
        while ($i==0){
            try{
                $i=1;
                //validation
                $this->validate($request,[
                    'rest_name'=>'required|unique:restaurants,rest_name',
                    'address'=>'required',
                    'mobile'=>'required|unique:restaurants,mobile',
                    ]);
                //data storing
                $input=$request->all();
                //initialize
                restaurant::create([
                    'rest_name'=>$input['rest_name'],
                    'address'=>$input['address'],
                    'mobile'=>$input['mobile'],
                    'email'=>$input['email'],
                    'status'=>'active',
                    ]);
            } catch(Exception $ex){
             $i=0;
            echo 'message : ' .$ex->getMessage();
            }
        }
        //return redirect
        return redirect()->route('restaurant.index')->with('success','Restaurant added successfully!!');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $restaurant_detail=restaurant::find($id);
        return view('pages.restaurant.edit',compact('restaurant_detail'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $i=0;
        while ($i==0){
            try{
                $i=1;
                //validation
                $this->validate($request,[
                'rest_name'=>'required|unique:restaurants,rest_name,'.$id,
                'address'=>'required',
                'mobile'=>'required|unique:restaurants,mobile,'.$id,
                    ]);
                //data storing
                $update=$request->all();
                //initialize
                restaurant::find($id)->update([
                    'rest_name'=>$update['rest_name'],
                    'address'=>$update['address'],
                    'mobile'=>$update['mobile'],
                    'email'=>$update['email'],
                    'status'=>$update['status'],
                    ]);
            } catch(Exception $ex){
             $i=0;
            echo 'message : ' .$ex->getMessage();
            }
        }
        //return redirect
        return redirect()->route('restaurant.index')->with('updated','data updated successfully!!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}

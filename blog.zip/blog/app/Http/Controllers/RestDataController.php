<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\User;
use App\category;
use App\dish;
use App\dishprice;
use App\addonprice;
use App\offer;
use App\cart;
use Auth;
use Hash;

class RestDataController extends Controller
{
   public function postSign(Request $request){
        $response = array();

        $validator = \Validator::make($request->all(),[
            'email' => 'required',
            'password' => 'required',
        ]);

        if ($validator->fails()) {
            $response['success'] = false;
            $response['errors'] = $validator->getMessageBag()->toArray();
        }else{
            try {
                $input = $request->all();
                $user = User::where('email',$input['email']);
                if($user->count()){
                    $userData = $user->first();
                    if (Hash::check($input['password'], $userData->password)){
                        $response['success'] = true;
                        $response['data'] = $userData; 
                        
                        $cart = new cart();
                        $cart->user_id = $userData->id;
                        $cart->sub_total = 0.00;
                        $cart->total = 0.00;
                        $cart->save();
                        $response['cartId'] = $cart->id;
                    }else{
                        $response['success'] = false;
                        $response['error'] = 'Wrong password';    
                    }
                }else{
                    $response['success'] = false;
                    $response['error'] = 'User not found';
                }
            } catch (Exception $e) {
                $response['success'] = false;
                $response['error'] = $ex->getMessage();
            }
        }
        return \Response::json($response);
    }

    public function getCategory(Request $request){
        $response = array();        
        try {
            $response['success'] = true;
            $response['data'] = category::select('id','category_name')->where('status','active')->get();
        } catch (Exception $e) {
            $response['success'] = false;
            $response['error'] = $ex->getMessage();
        }
        
        return response()->json($response);
    }

    public function getDish($id)
    {
        $i=0;
        while ($i==0){
            $response = array();
            try{
                $i=1;
                $response['success'] = true;
               
              
                $response['data'] = dish::leftjoin('dishprice','dishes.id','=','dishprice.dish_id')
                                        ->leftjoin('addonprices','dishes.id','=','addonprices.dish_id')
                                        ->select('dishes.id','dishes.dish_name','dishes.description',
                                                  'dishes.image','dishes.rest_id','dishes.cat_id',
                                                  'dishes.foodtype','dishprice.small','dishprice.medium',
                                                  'dishprice.large','dishprice.regular','addonprices.product1',
                                                  'addonprices.product2','addonprices.product3','addonprices.product4',
                                                   'addonprices.product5','addonprices.product6','addonprices.price1',
                                                   'addonprices.price2','addonprices.price3','addonprices.price4',
                                                   'addonprices.price5','addonprices.price6' )
                                        ->where('cat_id',$id)
                                        ->where('status','active')->get();

            } catch(Exception $ex){
             $i=0;
                $response['success'] = false;
                $response['error'] = $ex->getMessage();
            }
        }
        
        //return response()->json(dd($response));
        return response()->json($response);
    }

    public function getOffers()
    {
        $i=0;
        while ($i==0){
            try{
                $i=1;
                $response = array();
                $response['success'] = true;
                $response['data'] = offer::where('status','active')->get();
            } catch(Exception $ex){
             $i=0;
             $response['success'] = false;
             $response['error'] = $ex->getMessage();
            }
        }
        return response()->json($response);
    }
}

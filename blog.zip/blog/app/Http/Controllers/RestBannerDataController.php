<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\bannerimage;
use App\dish;
use App\dishprice;
use App\addonprice;
use App\offer;

class RestBannerDataController extends Controller
{
    public function getDishBanner()
    {
    	$response = array();
    	$i=0;
    	while ($i==0){
    		try{
    			$i=1;
    			$response['success'] = true;
    			$response['data'] = bannerimage::rightjoin('dishes','dishes.id','=','bannerimages.dish_id')
                                                ->rightjoin('dishprice','dishes.id','=','dishprice.dish_id')
                                                ->rightjoin('addonprices','dishes.id','=','addonprices.dish_id')
                                                ->select('bannerimages.id','bannerimages.image','bannerimages.dish_id',
                                                'dishes.id','dishes.dish_name','dishes.description',
                                                'dishes.image','dishes.rest_id','dishes.cat_id',
                                                'dishes.foodtype','dishprice.small','dishprice.medium',
                                                'dishprice.large','dishprice.regular','addonprices.product1',
                                                'addonprices.product2','addonprices.product3','addonprices.product4',
                                                'addonprices.product5','addonprices.product6','addonprices.price1',
                                                'addonprices.price2','addonprices.price3','addonprices.price4',
                                                'addonprices.price5','addonprices.price6')    
                                                ->where('bannerimages.status','active')->get()->take(3);               
    		} catch(Exception $ex){
    		 $i=0;
    		 $response['success'] = false;
    		 $response['error'] = $ex->getMessage();
    		}
  	  	}
    	return response()->json($response);
    }

    public function getOfferBanner()
    {
            try{
                $response['success'] = true;
                $response['data'] = bannerimage::rightjoin('offers','offers.id','=','bannerimages.offer_id')
                                            ->select('bannerimages.id','bannerimages.image','bannerimages.offer_id',
                                                     'offers.id','offers.offer_name','offers.description','offers.dish1',
                                                     'offers.rest_name1','offers.type1','offers.dish2','offers.rest_name2',
                                                     'offers.type2','offers.dish3','offers.rest_name3','offers.type3','offers.price',
                                                     'offers.image')
                                            ->where('bannerimages.status','active')
                                            ->get();
            } catch(Exception $ex){
            $response['success'] = false;
            $response['msg'] = $ex->getMessage();
            }
        return response()->json($response);
    }
}




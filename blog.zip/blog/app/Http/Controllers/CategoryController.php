<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Http\Requests;
use App\category;
use DB;

class CategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $category=category::all();
        return view('pages.category.index',compact('category'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('pages.category.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $i=0;
        while ($i==0){
            try{
                $i=1;
                //validate request
                $this->validate($request,[
                'category_name'=>'required|unique:categories,category_name',
                ]);
                //store request
                $input=$request->all();
                category::create([
                    'category_name'=>$input['category_name'],
                    'status'=>'active',
                    ]);
            } catch(Exception $ex){
             $i=0;
            echo 'message : ' .$ex->getMessage();
            }
        }
        //return view
        return redirect()->route('category.index')->with('success','Category successfully added!');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        return $id;
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $category_edit=category::find($id);
        return view('pages.category.edit',compact('category_edit'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {

        $i=0;
        while ($i==0){
            try{
                $i=1;
                //validate
            $this->validate($request,[
            'category_name'=>'required|unique:categories,category_name,'.$id,    
            ]);
            $update=$request->all();
            $category_update=category::find($id)->update([
            'category_name'=>$update['category_name'],
            'status'=>$update['status'],
            ]);
            } catch(Exception $ex){
             $i=0;
            echo 'message : ' .$ex->getMessage();
            }
        }
        
        
        return redirect()->route('category.index')->with('updated','Category successfully updated!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        category::find($id)->delete();
        return redirect()->route('category.index')->with('deleted','Category successfully deleted!');
    }
}

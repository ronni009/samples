<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\status;
use App\dish;
use App\dishprice;
use App\OrderItem;
use App\OrderList;

class MonthlyStatus extends Controller
{
    public function index()
    {
		$status = status::lists('name','month_code');
    	return view('pages.status.index',compact('status'));
    }

    public function show(Request $request)
    {
        $input = $request->all();
        //print_r($input); die;
        $MonthName = status::where('month_code',$input['month_id'])->first(); 
    	$OrderCount = OrderList::select('id')->whereMonth('created_at','=',$input['month_id'])->count();
        $OrderSum = OrderList::select('id')->whereMonth('created_at','=',$input['month_id'])->sum('total');
    	/*print_r($order_items);die;
    	$order_items = OrderItem::whereMonth('created_at','=',$input['month_id'])->get();*/
    	return view('pages.status.show',compact('OrderCount','OrderSum','MonthName'));
    }
}

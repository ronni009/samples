<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\offer;
use App\dish;
use App\restaurant;

class OfferController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $offer_detail=offer::all();
        return view('pages.offer.index',compact('offer_detail'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $dish_name=dish::lists('dish_name','dish_name');
        $rest_name=restaurant::lists('rest_name','rest_name');
        return view('pages.offer.create',compact('dish_name','rest_name'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $i=0;
        while ($i==0){
            try{
                $i=1;
                //validation
                $this->validate($request,[
                    'offer_name'=>'required|unique:offers,offer_name',
                    'image'   =>'required|image|dimensions:min_width=400,min_height=300|max:1024',
                    ]);
                //data storing
                $input=$request->except('image');
                $image=$request->image;
                if($image){
                    $imageName=$image->getClientOriginalName();
                    $image->move('images',$imageName);
                    $input['image']=$imageName;
                }
                //initialize
                offer::create([
                    'offer_name'=>$input['offer_name'],
                    'description'=>$input['description'],
                    'dish1'=>$input['dish1'],
                    'rest_name1'=>$input['rest_name1'],
                    'dish2'=>$input['dish2'],
                    'rest_name2'=>$input['rest_name2'],
                    'dish3'=>$input['dish3'],
                    'rest_name3'=>$input['rest_name3'],
                    'type1'=>$input['type1'],
                    'type2'=>$input['type2'],
                    'type3'=>$input['type3'],
                    'price'=>$input['price'],
                    'image'=> $input['image'],
                    'status'=>'active',
                    ]);
            } catch(Exception $ex){
             $i=0;
            echo 'message : ' .$ex->getMessage();
            }
        }
        return redirect()->route('offers.index')->with('success','offer added successfully!!');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $offer_edit=offer::find($id);
        $dish_name=dish::lists('dish_name','dish_name');
        $rest_name=restaurant::lists('rest_name','rest_name');
        return view('pages.offer.edit',compact('offer_edit','dish_name','rest_name'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $i=0;
        while ($i==0){
            try{
                $i=1;
        //validation
        $this->validate($request,[
            'offer_name'=>'required|unique:offers,offer_name,'.$id,
            'image'   =>'image|dimensions:min_width=400,min_height=300|max:1024',
            ]);
        //data storing 
        $update=$request->except('image');
        $image=$request->image;
        if($image){
            $imageName=$image->getClientOriginalName();
            $image->move('images',$imageName);
            $update['image']=$imageName;
        }else{
            $update['image']=$request->file;
        }
        //initialization
        offer::find($id)->update([
                    'offer_name'=>$update['offer_name'],
                    'description'=>$update['description'],
                    'dish1'=>$update['dish1'],
                    'rest_name1'=>$update['rest_name1'],
                    'dish2'=>$update['dish2'],
                    'rest_name2'=>$update['rest_name2'],
                    'dish3'=>$update['dish3'],
                    'rest_name3'=>$update['rest_name3'],
                    'type1'=>$update['type1'],
                    'type2'=>$update['type2'],
                    'type3'=>$update['type3'],
                    'price'=>$update['price'],
                    'image'=> $update['image'],
                    'status'=>$update['status'],
            ]);
            } catch(Exception $ex){
             $i=0;
            echo 'message : ' .$ex->getMessage();
            }
        }
        //redirect route
        return redirect()->route('offers.index')->with('updated','Offer updated successfully!!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}

<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::get('/', function () { 
    return view('auth.login');             //login page
});

Route::auth();
Route::group(['middleware'=>'auth'],function() {
	Route::get('/dashboard', 'LoginController@index');  //login dashboard
	Route::resource('category','CategoryController'); //categories
	Route::resource('menu','MenuController');        //menus
	Route::resource('addon','AddonController');    //addons
	Route::resource('productadd','ProductAddonController');   //productaddon
	Route::resource('orders','OrdersController'); //orders
	Route::get('orderss',['uses'=>'OrdersController@index2','as'=>'orders.index2']);  //orders
	Route::get('orderss/show{id}',['uses'=>'OrdersController@show2','as'=>'orders.show2']);  //orders
	Route::get('orderbill/{id}',['uses'=>'OrdersController@billshow','as'=>'orders.bill']); //bill
	Route::resource('clients','ClientController');           //client
	Route::resource('banner','AddBannerController');        //banners
	Route::resource('offers','OfferController');           //offers
	Route::resource('restaurant','AddRestaurantController');  //restaurant
	Route::resource('taxes','TaxController');       //tax

	Route::resource('users','UserController');       //user
	Route::resource('roles','RoleController');      //role

	Route::resource('reports','ReportController');  //reports

	Route::get('status',['uses'=>'MonthlyStatus@index','as'=>'status.index']);     //status
	Route::post('statusresult',['uses'=>'MonthlyStatus@show','as'=>'status.show']);  //status result

	Route::resource('karts','DeleteKartController');		//delete cart		
});
	
Route::get('/error',function() {
	return view('error.404');
});	

Route::group(['prefix' => 'api'], function() {
	    Route::controller('/pmc','RestDataController'); //user,dish,offer
	    Route::controller('/banner','RestBannerDataController'); //banner
	    Route::controller('/cart','RestKartController'); //cart details
	    Route::controller('/order','RestOrderController'); //order details
	    Route::controller('/device','RestDeviceController'); //adding device
});


<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class OrderItem extends Model
{
	protected $table = "order_items";

	protected $fillable = [
						    'order_id',
							'dish_id',
						    'offer_id',
						    'restaurant_id',
						    'dish_name',
						    'offer_name',
						    'image',
						    'small',
						    'medium',
						    'large',
						    'addon_name',
						    'addon_price',
						    'special_request',
						    'unit_price',
						    'quantity',
						    'final_price',
						    'default_value',
    						];
}

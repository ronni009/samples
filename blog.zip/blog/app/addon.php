<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\productaddon;

class addon extends Model
{
	protected $table="addons";

    protected $fillable=['addon_name','status'];

    public function productaddon()
    {
    	return $this->hasMany('App\productaddon');
    }
}

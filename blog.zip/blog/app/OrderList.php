<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class OrderList extends Model
{
	protected $table = "orderlists";

    protected $fillable = [
	'client_id',
    'sub_total',
    'total',
    'default_value',
    ];
}

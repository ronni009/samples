<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\orderlist;

class clientlist extends Model
{
    protected $table="clientlists";

    protected $fillable=[
    'client_name',
    'seat_no',
    'mobile_no',
    ];

    public function orderlist()
    {
    	return $this->hasMany('App\orderlist');
    }
}

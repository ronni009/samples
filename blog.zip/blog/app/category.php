<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\dish;

class category extends Model
{
	protected $table="categories";

    protected $fillable=['category_name','status'];

    public function dish()
    {
    	return $this->hasMany('App\dish');
    }
}

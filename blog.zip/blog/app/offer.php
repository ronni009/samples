<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\bannerimage;

class offer extends Model
{
    protected $table="offers";

    protected $fillable=[
    'offer_name',
    'description',
    'dish1',
    'rest_name1',
    'dish2',
    'rest_name2',
    'dish3',
    'rest_name3',
    'type1',
    'type2',
    'type3',
    'price',
    'image',
    'status',	
    ];

    public function bannerimages()
    {
        return $this->hasMany('App\bannerimage');
    }
}

<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tax extends Model
{
    protected $fillable=[
    'tax_percent',
    ];
}

<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\dish;

class dishprice extends Model
{
    protected $table="dishprice";

    protected $fillable=[
    'dish_id',
    'small',
    'medium',
    'large',
    'regular',
    'tax',
    'check1',
    ];

    public function dish()
    {
    	return $this->hasMany('App\dish');
    }
}

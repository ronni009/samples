@extends('admin_template')
@section('content')
    <section class="content">

      <!-- SELECT2 EXAMPLE -->
        @if ($errors->has())
        <div class="alert alert-danger alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <h4><i class="icon fa fa-ban"></i> Alert!</h4>
            @foreach ($errors->all() as $error)
                {{ $error }}<br>        
            @endforeach
          </div>
        @endif
      <div class="box box-default">
        <div class="box-header with-border">
          <h3 class="box-title">Create New Product Addon</h3>

          <div class="box-tools pull-right">
           
          </div>
        </div>

	{!! Form::open(['route'=>'productadd.store','method'=>'POST']) !!}
       {!! csrf_field() !!}
    <div class="box-body">
             <div class="row">
              <div class="col-md-6"> 
              <div class="form-group">
                <label>Add on</label>
                {!! Form::select('addon_id',$addon_list,null,['class'=>'form-control','placeholder'=>'--Select Addon--']) !!}
                <span style="color:grey">(eg:Toppings,sauce,dips only one allowed.*)</span>
              </div>
            </div>
         </div>

          <div class="row">
            <div class="col-md-3">
              <div class="form-group">
                {!! Form::label('product_name','Product Add on') !!}
                {!! Form::text('product_name',null,['class'=>'form-control','placeholder'=>'Addon text']) !!}
              </div>

            </div>
          </div>
        
              <input type="hidden" name="_token" value="{{ csrf_token() }}">
               <div class="form-group">
                <button type="submit" class="btn btn-primary">Add Product Addon</button>
        </div>

              <!-- /.form-group -->
            </div>
        </div> 
    
</section>

	{!! Form::close() !!}
@endsection
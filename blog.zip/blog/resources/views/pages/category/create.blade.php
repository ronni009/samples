@extends('admin_template')
@section('content')
    <section class="content">

      <!-- SELECT2 EXAMPLE -->
        @if ($errors->has())
        <div class="alert alert-danger alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <h4><i class="icon fa fa-ban"></i> Alert!</h4>
            @foreach ($errors->all() as $error)
                {{ $error }}<br>        
            @endforeach
          </div>
        @endif
      <div class="box box-default">
        <div class="box-header with-border">
          <h3 class="box-title">Create New Category</h3>

          <div class="box-tools pull-right">
            
          </div>
        </div>

	{!! Form::open(['route'=>'category.store','method'=>'POST']) !!}
       {!! csrf_field() !!}
    <div class="box-body">
          <div class="row">
            <div class="col-md-6">
              <div class="form-group">
               {{--  <label for="name">Category Name</label>
                  <input type="text" class="form-control" name="name" id="name" placeholder="Name">
              </div> --}}
              {!! Form::label('category_name','Category Name') !!}
              {!! Form::text('category_name',null,['class'=>'form-control','id'=>'category_name','placeholder'=>'Enter here..','required'=>'required']) !!}
            </div>
              <!-- /.form-group -->
               <div class="form-group">
               <span style="color:grey">(eg: Snacks, Appetizer, Main Course, Beverages etc. Please add 1 at a time.*)</span>
              </div>
              <input type="hidden" name="_token" value="{{ csrf_token() }}">
               <div class="form-group">
                <button type="submit" class="btn btn-primary">Add Category</button>
        </div>

              <!-- /.form-group -->
            </div>
        </div>
    </div>
</div>
</section>

	{!! Form::close() !!}
@endsection
@extends('admin_template')
@section('content')
    <section class="content">

      <!-- SELECT2 EXAMPLE -->
        @if ($errors->has())
        <div class="alert alert-danger alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <h4><i class="icon fa fa-ban"></i> Alert!</h4>
            @foreach ($errors->all() as $error)
                {{ $error }}<br>        
            @endforeach
          </div>
        @endif
      <div class="box box-default">
        <div class="box-header with-border">
          <h3 class="box-title">Edit Restaurant</h3>

          <div class="box-tools pull-right">
           
          </div>
        </div>

	{!! Form::open(['route'=>['restaurant.update',$restaurant_detail->id],'method'=>'POST']) !!}
       {!! csrf_field() !!}
       {!! method_field('PUT') !!}
    <div class="box-body">
          <div class="row">
            <div class="col-md-6">
              <div class="form-group">
              {!! Form::label('rest_name','Restaurant Name') !!}
              {!! Form::text('rest_name',@$restaurant_detail->rest_name,['class'=>'form-control','id'=>'rest_name','placeholder'=>'Enter here..','required'=>'required']) !!}
            </div>
            <div class="form-group">
              {!! Form::label('address','Address') !!}
              <textarea name="address" placeholder="Enter here.." class="form-control">{{@$restaurant_detail->address}}</textarea>
            </div>
            <div class="form-group">
              {!! Form::label('mobile','Mobile Number') !!}
              {!! Form::text('mobile',@$restaurant_detail->mobile,['class'=>'form-control','id="mobile','placeholder'=>'Enter here..']) !!}
            </div>
            <div class="form-group">
              {!! Form::label('email','Email Address') !!}
              {!! Form::text('email',@$restaurant_detail->email,['class'=>'form-control','id="email','placeholder'=>'Enter here..']) !!}
            </div>
              <!-- /.form-group -->
               <div class="form-group">
             {{--   <span style="color:grey">(eg: Snacks, Appetizer, Main Course, Beverages etc. Please add 1 at a time.*)</span> --}}
              </div>
              <input type="hidden" name="_token" value="{{ csrf_token() }}">
               <div class="form-group">
                <button type="submit" class="btn btn-primary">Submit</button>
                <a class="btn btn-primary" href="{{ route('restaurant.index') }}">Close</a>
        </div>

              <!-- /.form-group -->
            </div>
            <div class="form-group">
              <div class="col-md-6">
                {!! Form::label('status','Select Status') !!}
                {!! Form::select('status',['active'=>'active','inactive'=>'inactive'],@$restaurant_detail->status,['class'=>'form-control']) !!}
              </div>
            </div>
    </div>
</div>
</section>

	{!! Form::close() !!}
@endsection
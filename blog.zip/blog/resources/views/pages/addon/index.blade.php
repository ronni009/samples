 @extends('admin_template')

@section('content')
        {{-- messages --}}
	@if ($message = Session::get('success'))
		<div class="alert alert-success">
       <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
			<p>{{ $message }}</p>
		</div>
	@endif
  @if ($message = Session::get('updated'))
    <div class="alert alert-success">
       <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
      <p>{{ $message }}</p>
    </div>
  @endif
   @if ($message = Session::get('deleted'))
    <div class="alert alert-success">
       <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
      <p>{{ $message }}</p>
    </div>
  @endif
  {{-- box begins --}}
	 <div class="box">
              <div class="box-header">
                    <h3 class="box-title">List of Addons</h3>
                  </div><!-- /.box-header -->
                  <div class="box-footer">
                <a  href="{{ route('addon.create') }}" button type = "button" class = "btn btn-primary" >Add Addon</button></a>
              </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example2" class="table table-bordered table-striped" cellspacing="0" width="100%" >
               <thead>
               <tr>
			<th>No</th>
			<th>Name</th>
      <th>Status</th>
      <th>Action</th>
		</tr>   
                </thead>
                <tbody>
                  @forelse($addon as $addons)
                  <tr class="odd gradeX">
                        <td>{{ $addons->id }}</td> 
                        <td>{{ $addons->addon_name }}</td>
                        <td>{{ $addons->status }}</td>
                  <td>
                     <a class="btn btn-primary" href="{{ route('addon.edit',$addons->id)}}">Edit</a>
                  </td>
                    </tr>
                  @empty
                  <tr class="odd gradeX">
                    <td colspan=13 class="text-center">No Records Found</td>
                    </tr>  
                  @endforelse
                    
                </tbody>
                <tfoot>
                 <tr>
			<th>No</th>
			<th>Name</th>
      <th>Status</th>
			<th>Action</th>
		</tr>
                </tfoot>
              </table>
           {{--   {!! $data->links() !!}  --}}  
            </div>  
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
 

   <!-- <script type="text/javascript">
      $(function () {
   $("#example2").DataTable();
    // $('#example2').DataTable({
    //   "paging": true,
    //   "lengthChange": false,
    //   "searching": false,
    //   "ordering": true,
    //   "info": true,
    //   "autoWidth": false
    "scrollX": true
    // });
  });
    </script>-->
    <script>
     $(document).ready(function() {
    $('#example2').DataTable( {
        "scrollX": true
    } );
} );  /*
    $(document).ready(function (){
    var table = $('#example2').dataTable({
       "aLengthMenu": [ [2, 5, 10, -1], [2, 5, 10, "All"] ],
       "iDisplayLength" : 4,        
    });
}); */
    </script>

   
@stop
@extends('admin_template')
 
@section('content')
	<div class="row">
	    <div class="col-lg-12 margin-tb">
	        <div class="pull-left">
	            <h2>Status Details</h2>
	        </div>
	        <div class="pull-right">
	            <a class="btn btn-primary" href="{{route('status.index')}}"> Back</a>
	        </div>
	    </div>
	</div>
      <div class="row">
          <div class="col-lg-12 margin-tb">
              <div class="pull-left">
                  <h3></h3>
              </div>
              <div class="pull-right">
                  {{-- <h3>Mobile Number-3380422603</h3> --}}
              </div>
          </div>
      </div>
      <table id="example2" class="table table-bordered table-striped" cellspacing="0" width="100%" >
      <tr>
        <th>Month</th>	
        <th>Total Orders</th>
        <th>Total Amount</th>
      </tr>
      <tr>
          <td>{{ $MonthName->name }}</td>
          <td>{{ $OrderCount }} </td>
          <td>{{ $OrderSum }}  </td>
      </tr>         
      </table>
  
@endsection
@extends('admin_template')
@section('content')
    <section class="content">

      <!-- SELECT2 EXAMPLE -->
        @if ($errors->has())
        <div class="alert alert-danger alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <h4><i class="icon fa fa-ban"></i> Alert!</h4>
            @foreach ($errors->all() as $error)
                {{ $error }}<br>        
            @endforeach
          </div>
        @endif
      <div class="box box-default">
        <div class="box-header with-border">
          <h3 class="box-title">Create New Dish</h3>

          <div class="box-tools pull-right">
            
          </div>
        </div>

	{!! Form::open(['route'=>'menu.store','method'=>'POST','enctype'=>'multipart/form-data']) !!}
       {!! csrf_field() !!}
      
    <div class="box-body">
          <div class="row">
            <div class="col-md-6">
              <!-- form-group -->
              <div class="form-group">
                {!! Form::label('dish_name','Dish Name') !!}
                {!! Form::text('dish_name',null,['class'=>'form-control','id'=>'dish_name','placeholder'=>'Enter here..','required'=>'required']) !!}
               
             </div>
               <div class="form-group">
               {!! Form::label('description','Short description') !!}
               <textarea name="description" class="form-control" placeholder="Enter here.." cols="20%"></textarea>
              </div>
              <div class="form-group">
                {!! Form::label('image','Add Image') !!}
                {!! Form::file('image',['class'=>'form-control']) !!}
                <span style="color:grey">(image must be 400px wide by 300px tall.*)</span>
              </div> 
              <div class="form-group">
                  {!! Form::label('rest_id','Select Restaurant') !!}
                  {!! Form::Select('rest_id',@$restaurant_name,null,['class'=>'form-control Select2','placeholder'=>'--Select Restaurant--']) !!}
              </div>
              <div class="form-group">
                  {!! Form::label('category','Select Category') !!}
                  {!! Form::Select('cat_id',@$category_list,null,['class'=>'form-control Select2','placeholder'=>'--Select category--']) !!}
              </div>
            </div>  
          </div>  
          <div class="row">                   <!-- size beginss -->
            <div class="col-md-3">
              <div class="form-group">
                {!! Form::hidden('check1',0) !!}
                {{ Form::checkbox('check1',1,false,['id'=>'check1']) }}Select Size
              </div>
              </div>
          <div id="autoUpdate">  <!-- /. auto -->
            <div class="col-md-3">
              <div class="form-group">
                <label>Small</label>
                <input type="text" name="small" class="form-control" placeholder="Enter price">
                </div>
              </div>
            <div class="col-md-3">  
              <div class="form-group">
                  <label>Medium</label>
                  <input type="text" name="medium" class="form-control" placeholder="Enter price">
                </div>
              </div>
            <div class="col-md-3">
              <div class="form-group">
                <label>Large</label>
                <input type="text" name="large" class="form-control" placeholder="Enter price">
              </div>
            </div>
          </div>    <!-- /.auto -->
        </div>  
          <div class="row">
            <div class="col-md-3">
              <div class="form-group">
                {!! Form::label('foodtype','Food Type') !!}
                {!! Form::select('foodtype',['veg'=>'veg','non-veg'=>'non-veg'],null,['class'=>'form-control']) !!}
                </div>
              </div>
          </div>
          <div class="row">   <!--  addonn begins -->
            <div class="col-md-2"> 
              <div class="form-group">
                {!! Form::hidden('check2',0) !!}
              {!! Form::checkbox('check2',1,false,['id'=>'check2']) !!}Select addon
              </div>
            </div>
           </div> 
        <div id="autoUpdate2">   <!-- /.auto -->
         <div class="row">
              <div class="col-md-6"> 
              <div class="form-group">
                <label>Add on</label>
               {!! Form::select('addon_name',@$addon_list,null,['class'=>'form-control Select2','id'=>'selected1','placeholder'=>'--Select addon--']) !!}
                <span style="color:grey">(eg:Toppings,sauce,dips only one allowed.*)</span>
              </div>
            </div>
         </div>

          <div class="row">
            <div class="col-md-3">
              <div class="form-group">
                {!! Form::label('product1','Product') !!}
                {!! Form::select('product1',@$product_list,null,['class'=>'form-control Select2','placeholder'=>'--Select product--']) !!}
              </div>

              <div class="form-group">
                 {!! Form::select('product2',@$product_list,null,['class'=>'form-control Select2','placeholder'=>'--Select product--']) !!}
              </div>

              <div class="form-group">
                 {!! Form::select('product3',@$product_list,null,['class'=>'form-control Select2','placeholder'=>'--Select product--']) !!}
              </div>
            </div>
            
            <div class="col-md-3">
              <div class="form-group">
                {!! Form::label('price1','Price') !!}
                {!! Form::text('price1',null,['class'=>'form-control','placeholder'=>'Enter Price']) !!}
              </div>

              <div class="form-group">
                {!! Form::text('price2',null,['class'=>'form-control','placeholder'=>'Enter Price']) !!}
              </div>

              <div class="form-group">
                {!! Form::text('price3',null,['class'=>'form-control','placeholder'=>'Enter Price']) !!}
              </div>
            </div>

            <div class="col-md-3">
              <div class="form-group">
                {!! Form::label('product4','Product') !!}
                 {!! Form::select('product4',@$product_list,null,['class'=>'form-control Select2','placeholder'=>'--Select product--']) !!}
              </div>

              <div class="form-group">
                 {!! Form::select('product5',@$product_list,null,['class'=>'form-control Select2','placeholder'=>'--Select product--']) !!}
              </div>

              <div class="form-group">
                {!! Form::select('product6',@$product_list,null,['class'=>'form-control Select2','placeholder'=>'--Select product--']) !!}
              </div>
            </div>

            <div class="col-md-3">
              <div class="form-group">
                {!! Form::label('price4','Price') !!}
                {!! Form::text('price4',null,['class'=>'form-control','placeholder'=>'Enter Price']) !!}
              </div>

              <div class="form-group">
                {!! Form::text('price5',null,['class'=>'form-control','placeholder'=>'Enter Price']) !!}
              </div>

              <div class="form-group">
                {!! Form::text('price6',null,['class'=>'form-control','placeholder'=>'Enter Price']) !!}
              </div>
            </div>
          </div>
        </div>  
          <div class="row">
            <div class="col-md-6">
              {{--  <div class="form-group">
                {!! Form::label('tax','Tax*') !!}
                {!! Form::text('tax',null,['class'=>'form-control','placeholder'=>'enter here']) !!}
              </div> --}}
              <div class="form-group" id="dp">
                {!! Form::label('regular','Dish Price') !!}
                {!! Form::text('regular',null,['class'=>'form-control','placeholder'=>'enter here']) !!}
              </div>
            </div>
          </div>

        <!-- /.row -->

          <div class="row">
            <div class="col-md-3">
            <div class="form-group">
               <input type="hidden" name="_token" value="{{ csrf_token() }}">
                <button type="submit" class="btn btn-primary">Add Dish</button>
             </div>
          </div> 
        </div>   
              <!-- /.form-group -->
            </div>
        
    </div>
</div>
</section>

	{!! Form::close() !!}
<script>
$(document).ready(function(){
    $('#check1').change(function(){
        if(this.checked)
            $('#autoUpdate').fadeIn('slow');
        else
            $('#autoUpdate').fadeOut('slow');

    }).change();
});
</script>

<script>
$(document).ready(function(){
    $('#check2').change(function(){
        if(this.checked)
            $('#autoUpdate2').fadeIn('slow');
        else
            $('#autoUpdate2').fadeOut('slow');

    }).change();
});
</script>

<script>
$(document).ready(function(){
    $('#check1').change(function(){
        if(this.checked)
            $('#dp').fadeOut('slow');
        else
            $('#dp').fadeIn('slow');

    }).change();
});
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>
<script>
$(document).ready(function(){
  $('#selected1').on('change', function(e) {
    e.preventDefault();
    var id=$(this).val();
    //alert(addon);die;
    data={id:id};
    $.ajax({
      type:'POST',
      contentType:'application/x-www-form-urlencoded',
      url:'{{ url("menu/trial") }}',
      data:data,
      dataType:'JSON',
      success:function(response){
          console.log(response);
        }
      }

    });
    return false;
  });
});

</script>

@endsection
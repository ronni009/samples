@extends('admin_template')
@section('content')
    <section class="content">

      <!-- SELECT2 EXAMPLE -->
        @if ($errors->has())
        <div class="alert alert-danger alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <h4><i class="icon fa fa-ban"></i> Alert!</h4>
            @foreach ($errors->all() as $error)
                {{ $error }}<br>        
            @endforeach
          </div>
        @endif
      <div class="box box-default">
        <div class="box-header with-border">
          <h3 class="box-title">
          Add Banner Image</h3>

          <div class="box-tools pull-right">
           
          </div>
        </div>

	{!! Form::open(['route'=>'banner.store','method'=>'POST','enctype'=>'multipart/form-data']) !!}
       {!! csrf_field() !!}
    <div class="box-body">
          <div class="row">
            <div class="col-md-6">     <!-- checkbox for dish -->
              <div class="form-group">
              {!! Form::label('check1','Dish Banner') !!}
              {!! Form::hidden('check1',0) !!}
              {!! Form::checkbox('check1',1,false,['id'=>'checkbox1']) !!}
              </div>

              <div class="form-group">       <!-- checkbox for offer -->
                {!! Form::label('check2','Offer Banner') !!}
                {!! Form::hidden('check2',0) !!}
                {!! Form::checkbox('check2',1,false,['id'=>'checkbox2']) !!}
              </div>

              <div class="form-group">     <!-- banner image -->
              {!! Form::label('image','Select Banner Image') !!}
              {!! Form::file('image',['class'=>'form-control']) !!}
              </div>
              <!-- /.form-group -->
               <div class="form-group">
               <span style="color:grey">(image must be 400px wide by 300px tall.*)</span>
              </div>
              <input type="hidden" name="_token" value="{{ csrf_token() }}">
               <div class="form-group">
                <button type="submit" class="btn btn-primary">Add Banner</button>
        </div>

            </div>         <!-- /.col-md-6 -->

          
            <div class="col-md-6">
              <div id="autoUpdate">
            <div class="form-group">
              {!! Form::label('dish_id','Select Dish') !!}       <!-- dish select box -->
              {!! Form::select('dish_id',@$dish_detail,null,['class'=>'form-control','placeholder'=>'--None--']) !!}
            </div>
          </div>

          <div id="autoUpdate2">                                <!-- offer select box -->
            <div class="form-group">
              {!! Form::label('offer_id','Select Offer') !!}
              {!! Form::select('offer_id',@$offer_detail,null,['class'=>'form-control','placeholder'=>'--None--']) !!}
            </div>
          </div>
            
          </div>        <!-- /.col-md-6 -->
        </div>      <!-- /.row -->
    </div>
</div>
</section>

	{!! Form::close() !!}

  <script>
$(document).ready(function(){
    $('#checkbox1').change(function(){
        if(this.checked)
            $('#autoUpdate').fadeIn('slow');
        else
            $('#autoUpdate').fadeOut('slow');

    }).change();
});
</script>

  <script>
$(document).ready(function(){
    $('#checkbox2').change(function(){
        if(this.checked)
            $('#autoUpdate2').fadeIn('slow');
        else
            $('#autoUpdate2').fadeOut('slow');

    }).change();
});
</script>
@endsection
@extends('admin_template')
@section('content')
<style type="text/css">
img.zoom {
    width: 60px;
    height: 60px;
    -webkit-transition: all .2s ease-in-out;
    -moz-transition: all .2s ease-in-out;
    -o-transition: all .2s ease-in-out;
    -ms-transition: all .2s ease-in-out;
}
 
.transition {
    -webkit-transform: scale(2.8); 
    -moz-transform: scale(2.8);
    -o-transform: scale(2.8);
    transform: scale(2.8);
}

</style>
    <section class="content">

      <!-- SELECT2 EXAMPLE -->
        @if ($errors->has())
        <div class="alert alert-danger alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <h4><i class="icon fa fa-ban"></i> Alert!</h4>
            @foreach ($errors->all() as $error)
                {{ $error }}<br>        
            @endforeach
          </div>
        @endif
      <div class="box box-default">
        <div class="box-header with-border">
          <h3 class="box-title">Edit Banner Image</h3>

          <div class="box-tools pull-right">
           
          </div>
        </div>

  {!! Form::open(['route'=>['banner.update',$image_detail->id],'method'=>'POST','enctype'=>'multipart/form-data','files'=>true ]) !!}
       {!! csrf_field() !!}
       {!! method_field('PATCH') !!}
    <div class="box-body">
          <div class="row">
            <div class="col-md-6">
              <div class="form-group">
              {!! Form::hidden('file',$image_detail->image,['class'=>'form-control']) !!}
              <img class="zoom" src="{{ URL::to('images',$image_detail->image) }}"/><br>
              {!! Form::label('image','Select Banner') !!}
              {!! Form::file('image',['class'=>'form-control']) !!}
            </div>
              <!-- /.form-group -->
               <div class="form-group">
               <span style="color:grey">(image must be 400px wide by 300px tall.*)</span>
              </div>
              <input type="hidden" name="_token" value="{{ csrf_token() }}">
               <div class="form-group">
                <button type="submit" class="btn btn-primary">Submit</button>
                <a href="{{ route('banner.index') }}" class="btn btn-primary">Close</a>
        </div>

              <!-- /.form-group -->
            </div>
            <div class="col-md-6">
              {!! Form::label('status','Select Status') !!}
              {!! Form::select('status',['active'=>'active','inactive'=>'inactive'],$image_detail->status,['class'=>'form-control Select2']) !!}
          </div>
    </div>
</div>
</section>

  {!! Form::close() !!}

   <script type="text/javascript" src="http://code.jquery.com/jquery-1.8.2.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/elevatezoom/3.0.8/jquery.elevatezoom.js" type="text/javascript"></script>
<script>

   $(document).ready(function(){
    $('.zoom').hover(function() {
        $(this).addClass('transition');
    }, function() {
        $(this).removeClass('transition');
    });
});
</script>

@endsection
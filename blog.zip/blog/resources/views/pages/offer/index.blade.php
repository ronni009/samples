 @extends('admin_template')

@section('content')
<style type="text/css">
img.zoom {
    width: 60px;
    height: 60px;
    -webkit-transition: all .2s ease-in-out;
    -moz-transition: all .2s ease-in-out;
    -o-transition: all .2s ease-in-out;
    -ms-transition: all .2s ease-in-out;
}
 
.transition {
    -webkit-transform: scale(2.8); 
    -moz-transform: scale(2.8);
    -o-transform: scale(2.8);
    transform: scale(2.8);
}

</style>
        {{-- messages --}}
	@if ($message = Session::get('success'))
		<div class="alert alert-success">
       <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
			<p>{{ $message }}</p>
		</div>
	@endif
  @if ($message = Session::get('updated'))
    <div class="alert alert-success">
       <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
      <p>{{ $message }}</p>
    </div>
  @endif
   @if ($message = Session::get('deleted'))
    <div class="alert alert-success">
       <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
      <p>{{ $message }}</p>
    </div>
  @endif
  {{-- box begins --}}
	 <div class="box">
              <div class="box-header">
                    <h3 class="box-title">List of Offers</h3>
                  </div><!-- /.box-header -->
                  <div class="box-footer">
                <a  href="{{ route('offers.create') }}" button type = "button" class = "btn btn-primary" >Add Offer</button></a>
              </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example2" class="table table-bordered table-striped" cellspacing="0" width="100%" >
               <thead>
               <tr>
			<th>No</th>
			<th>Name</th>
      <th>Description</th>
      <th>Dish1</th>
      <th>Restaurant</th>
      <th>Type</th>
      <th>Dish2</th>
      <th>Restaurant</th>
      <th>Type</th>
      <th>Dish3</th>
      <th>Restaurant</th>
      <th>Type</th>
      <th>Image</th>
      <th>Price</th>
      <th>Status</th>
      <th>Action</th>
		</tr>   
                </thead>
                <tbody>
                  @forelse($offer_detail as $offer_details)
                  <tr class="odd gradeX">
                        <td>{{ $offer_details->id }}</td> 
                        <td>{{ $offer_details->offer_name }}</td>
                        <td>{{ $offer_details->description }}</td>
                        <td>{{ $offer_details->dish1 }}</td>
                        <td>{{  $offer_details->rest_name1}}</td>
                        <td>{{ $offer_details->type1 }}</td>
                        <td>{{ $offer_details->dish2 }}</td>
                        <td>{{  $offer_details->rest_name2}}</td>
                        <td>{{ $offer_details->type2 }}</td>
                        <td>{{ $offer_details->dish3 }}</td>
                        <td>{{  $offer_details->rest_name3}}</td>
                       <td>{{ $offer_details->type3 }}</td>
                        <td><img class="zoom" src="{{ URL::to('images',$offer_details->image) }}"/></td>
                         <td>{{  $offer_details->price}}</td>
                        <td>{{ $offer_details->status }}</td>
                  <td>
                     <a class="btn btn-primary" href="{{ route('offers.edit',$offer_details->id)}}">Edit</a>
                  </td>
                    </tr>
                  @empty
                  <tr class="odd gradeX">
                    <td colspan=13 class="text-center">No Records Found</td>
                    </tr>  
                  @endforelse
                    
                </tbody>
                <tfoot>
                 <tr>
			<th>No</th>
      <th>Name</th>
      <th>Description</th>
      <th>Dish1</th>
      <th>Restaurant</th>
      <th>Type</th>
      <th>Dish2</th>
      <th>Restaurant</th>
      <th>Type</th>
      <th>Dish3</th>
      <th>Restaurant</th>
      <th>Type</th>
      <th>Image</th>
      <th>Price</th>
      <th>Status</th>
      <th>Action</th>
		</tr>
                </tfoot>
              </table>
           {{--   {!! $data->links() !!}  --}}  
            </div>  
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
 
    <script>
     $(document).ready(function() {
    $('#example2').DataTable( {
        "scrollX": true
    } );
} );  
    </script>

   
    <script type="text/javascript" src="http://code.jquery.com/jquery-1.8.2.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/elevatezoom/3.0.8/jquery.elevatezoom.js" type="text/javascript"></script>
<script>

   $(document).ready(function(){
    $('.zoom').hover(function() {
        $(this).addClass('transition');
    }, function() {
        $(this).removeClass('transition');
    });
});
</script>

@stop
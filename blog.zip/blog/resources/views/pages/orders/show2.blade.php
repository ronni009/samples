@extends('admin_template')

 

@section('content')

  <div class="row">

      <div class="col-lg-12 margin-tb">

          <div class="pull-left">

              <h2>Order Details</h2>

          </div>

          <div class="pull-right">

              <a class="btn btn-primary" href="{{ route('orders.index2') }}"> Back</a>

          </div>

      </div>

  </div>

      <div class="row">



              <div class="col-md-4">

                  <h3>Order Id-{{ @$orderList->id }}</h3>

              </div>

              <div class="col-md-4">

                  <h3>Mobile Number-{{@$clientData->mobile_no}}</h3>

              </div>

              <div class="col-md-4">

                  <h3>Seat Number-{{@$clientData->seat_no}}</h3>

              </div>

      </div>

      <table id="example2" class="table table-bordered table-striped" cellspacing="0" width="100%" >

      <tr>

        <th>Order Description</th>  

        <th>Addon Name</th>

        <th>Addon Price (QAR)</th>

        <th>Restaurant Name</th>

        <th>Special Request</th>

        <th>Small (QAR)</th>

        <th>Medium (QAR)</th>

        <th>Large (QAR)</th>

        <th>Quantity</th>

        <th>Net Price (QAR)</th>

        <th>Subtotal (QAR)</th>

      </tr>

      <tr>

          @forelse($orderItem as $orderItems)

          <td>{{ $orderItems->dish_name }} </td>

          <td> {{ $orderItems->addon_name }} </td>

          <td> {{ $orderItems->addon_price }} </td>

          <td> {{ $orderItems->rest_name }} </td>

          <td> {{ $orderItems->special_request }} </td>

          <td> {{ $orderItems->small }} </td>

          <td> {{ $orderItems->medium }} </td>

          <td> {{ $orderItems->large }} </td>

          <td> {{ $orderItems->quantity }} </td>

          <td> {{ $orderItems->unit_price }} </td> 

          <td> {{ $orderItems->final_price }} </td>

          <td></td>

      </tr>         

                   @empty

                  <tr class="odd gradeX">

                    <td colspan=13 class="text-center">No Records Found</td>

                    </tr>  

                  @endforelse

      </table>

        <div class="row">

          <div class="pull-right">

            <h2>Total- QAR {{ $orderList->total }}</h2>

           <a href="{{ route('orders.bill',$orderList->id) }}" class="btn btn-primary">Print Bill</a>

          </div>

        </div>

@endsection


<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">

		<html xmlns="http://www.w3.org/1999/xhtml">

		<head>

      <title>Bill Invoice</title>

    

<script type="text/javascript">

  function printlayer(layer){

    var generator=window.open(",'name,");

    var layetext=document.getElementById(layer);

    generator.document.write(layetext.innerHTML.replace("Print Me"));



    generator.document.close();

    generator.print();

    generator.close();

  }

</script>

</head>

<body>

  <h3><a href="#" id="print" onclick="javasript:printlayer('div-id-name')">Print Report</a></h3>

<div class="containter" id="div-id-name">

  <div class="order-receipt" style="width: 500px;">   

    <div class="clr"></div>

    <table class="receipt-table">

      <tbody><tr><td style="font-weight: bold;">Bill Details</td></tr>

        <tr>

        <td class="receipt-table-details">Order ID</td>

        <td class="receipt-table-details">{{ $orderList->id }}</td>

      </tr>

      <tr>

        <td class="receipt-table-details">Name</td>

        <td class="receipt-table-details">{{ ucfirst($clientData->client_name) }}</td>

      </tr>

      <tr>

        <td class="receipt-table-details">Mobile Number</td>

        <td class="receipt-table-details">{{ $clientData->mobile_no }}</td>

      </tr>

       <tr>

        <td class="receipt-table-details">Seat Number</td>

        <td class="receipt-table-details">{{ $clientData->seat_no }}</td>

      </tr>

            <tr>
        <td class="receipt-table-details">Quantity</td>      
        <td class="receipt-table-details">Order Description</td>
        <td class="receipt-table-details">with</td>
        <td class="receipt-table-details">Total(QAR)</td>
          </tr>

          

    @foreach ($orderItem as $orderItems)
    @if ($orderItems->addon_name == "N/A")
    <tr>
        <td class="receipt-table-details">{{ $orderItems->quantity }}</td>
        <td class="receipt-table-details">{{ $orderItems->dish_name }}</td>
        <td class="receipt-table-details">-</td>
        <td class="receipt-table-details">{{ $orderItems->final_price }}</td>
     </tr>    
     @else
     <tr>
        <td class="receipt-table-details">{{ $orderItems->quantity }}</td>
        <td class="receipt-table-details">{{ $orderItems->dish_name }}</td>
        <td class="receipt-table-details">{{ $orderItems->addon_name }}</td>
        <td class="receipt-table-details">{{ $orderItems->final_price }}</td>
     </tr>  
     @endif
    @endforeach    

      

      <tr><td colspan="2"><hr></td></tr>

      <tr>

   {{--  @foreach ($orderItem as $orderItems)

        <td class="receipt-table-details">{{ $orderItems->addon_name }}</td>

    @endforeach     --}}

      </tr> 

     {{--  <tr>

        <td class="receipt-table-details">Restaurant Address</td>

        <td class="receipt-table-details">Ground Floor, Shop No. 1, Vaishali CHS LTD, Near Rai Height, M.G. Road, Kandivali West, MUMBAI, MAHARASHTRA - 400067 PH NO : 022 28644011</td>

      </tr>  --}}
      
      @foreach($orderItem as $orderItems)
      @if($orderItems->special_request == "N/A")
      <tr><td class="receipt-table-details"></td> <td class="receipt-table-details"></td></tr>
      @else
      <tr><td class="receipt-table-details">{{$orderItems->special_request}}</td> <td class="receipt-table-details"></td></tr>
      @endif
      @endforeach

      <tr><td colspan="2"><hr></td></tr>

      <tr><td class="receipt-table-details">Order Date/Time</td> <td class="receipt-table-details">{{$orderList->updated_at }}</td></tr>
      


           {{--  <tr><td class="receipt-table-details">Form of Payment</td> <td class="receipt-table-details">cash</td></tr> --}}





     {{--  <tr><td colspan="2"><hr></td></tr>

                <tr><td class="receipt-table-details">

              <b>1</b>              <b>&nbsp;</b>..              </td><td class="receipt-table-details"><b>*coming soon</b></td>            </tr>

                      <tr><td colspan="2"><hr></td></tr>

                    <tr><td class="receipt-table-details"><b>Sub Total</b></td> <td class="receipt-table-details"><b>*coming soon</b></td></tr> 

                    <tr><td colspan="2"><hr></td></tr> --}}

                 {{--  <tr><td class="receipt-table-details"><b>All TAX Inclusive</b> </td> <td class="receipt-table-details"><b></b></td></tr> --}}

          <tr><td colspan="2"><hr></td></tr>

                <tr><td class="receipt-table-details"><b>TOTAL:(QAR)</b></td> <td class="receipt-table-details"><b>{{$orderList->total }}</b></td></tr>

                      

           

      <tr><td colspan="2"><hr></td></tr> 

    </tbody></table>

    <div style="clear: both;"></div> 

  </div>   

</div>   

</body></html>


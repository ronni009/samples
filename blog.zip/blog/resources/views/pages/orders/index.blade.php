 @extends('admin_template')

@section('content')
        {{-- messages --}}
  @if ($message = Session::get('success'))
    <div class="alert alert-success">
       <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
      <p>{{ $message }}</p>
    </div>
  @endif
  @if ($message = Session::get('updated'))
    <div class="alert alert-success">
       <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
      <p>{{ $message }}</p>
    </div>
  @endif
   @if ($message = Session::get('deleted'))
    <div class="alert alert-success">
       <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
      <p>{{ $message }}</p>
    </div>
  @endif
  {{-- box begins --}}
   <div class="box">
              <div class="box-header">
                    <h3 class="box-title">List Orders</h3>
                  </div><!-- /.box-header -->
                  <div class="box-footer">
              {{--   <a  href="{{ route('orders.index') }}" button type = "button" method="POST" class = "btn btn-primary pull-left" id="bck" value="delivered">Back</button></a> --}}
                <a  href="{{ route('orders.index2') }}" button type = "button" method="POST" class = "btn btn-success pull-right" id="deliver" value="delivered">Delivered Orders</button></a>
              </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example2" class="table table-bordered table-striped" cellspacing="0" width="100%" >
               <thead>
    <tr>
      <th>Order ID</th>
      <th>Client ID</th>
      <th>Order Details</th>
      <th>Default Value</th>
      <th>Action</th>
    </tr>   
                </thead>
                <tbody>
                  @forelse($orderList as $orderLists)
                  <tr class="odd gradeX">
                        <td>{{ $orderLists->id }}</td> 
                        <td>{{ $orderLists->client_id }}</td>
                        <td><a title="View Details" data-toggle="tooltip"  class="badge bg-blue" href="{{ route('orders.show',$orderLists->id) }}" ><i class="fa fa-eye"></i></a></td>
                  <td>
                    <div class="form-group">
                   {!! Form::open(['route'=>['orders.update',$orderLists->id],'method'=>'POST']) !!}  
                   {{ method_field('PUT') }}
                     {!! Form::select('default_value',['Order in Process'=>'Order in Process','Partial Order Delivered'=>'Partial Order Delivered','Order Delivered'=>'Order Delivered'],@$orderLists->default_value,['class'=>'form-control select2']) !!}
                   </div>
                  </td>
                  {{-- <td><a title="Update" data-toggle="tooltip"  class="btn btn-default" href="{{ route('orders.show',$orderLists->id) }}" >Update</a></td> --}}
                <td><input type="submit" value="update" class="btn btn-default"></td>
                {!! Form::close() !!}
                    </tr>
                  @empty
                  <tr class="odd gradeX">
                    <td colspan=13 class="text-center">No Records Found</td>
                    </tr>  
                  @endforelse
                    
                </tbody>
                <tfoot>
     <tr>
       <th>Order ID</th>
      <th>Client ID</th>
      <th>Order Details</th>
      <th>Default Value</th>
      <th>Action</th>
    </tr>
                </tfoot>
              </table>
           {{--   {!! $data->links() !!}  --}}  
            </div>  
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
 
    <script>
     $(document).ready(function() {
    $('#example2').DataTable( {
        "scrollX": true
    } );
} );  
    </script>
   
@stop
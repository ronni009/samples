 @extends('admin_template')

@section('content')
        {{-- messages --}}
  @if ($message = Session::get('success'))
    <div class="alert alert-success">
       <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
      <p>{{ $message }}</p>
    </div>
  @endif
  @if ($message = Session::get('updated'))
    <div class="alert alert-success">
       <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
      <p>{{ $message }}</p>
    </div>
  @endif
   @if ($message = Session::get('deleted'))
    <div class="alert alert-success">
       <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
      <p>{{ $message }}</p>
    </div>
  @endif
  {{-- box begins --}}
   <div class="box">
              <div class="box-header">
                    <h3 class="box-title">List of Clients</h3>
                  </div><!-- /.box-header -->
                  <div class="box-footer">
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example2" class="table table-bordered table-striped" cellspacing="0" width="100%" >
               <thead>
               <tr>
      <th>Client ID</th>
      <th>Name</th>
      <th>Seat Number</th>
      <th>Mobile Number</th>
    </tr>   
                </thead>
                <tbody>
                  @forelse($client_detail as $client_details)
                  <tr class="odd gradeX">
                        <td>{{ $client_details->id }}</td> 
                        <td>{{ $client_details->client_name }}</td>
                        <td>{{ $client_details->seat_no }}</td>
                        <td>{{ $client_details->mobile_no }}</td>
                    </tr>
                  @empty
                  <tr class="odd gradeX">
                    <td colspan=13 class="text-center">No Records Found</td>
                    </tr>  
                  @endforelse
                    
                </tbody>
                <tfoot>
                 <tr>
      <th>Client ID</th>
      <th>Name</th>
      <th>Seat Number</th>
      <th>Mobile Number</th>
    </tr>
                </tfoot>
              </table>
           {{--   {!! $data->links() !!}  --}}  
            </div>  
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
 

    <script>
     $(document).ready(function() {
    $('#example2').DataTable( {
        "scrollX": true
    } );
} );  
    </script>

   
@stop
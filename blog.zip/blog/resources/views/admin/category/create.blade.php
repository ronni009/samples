 @extends('admin_template')

@section('content')

<h3>Add Category</h3>
   <div class="row">
        <div class="col-md-8 col-md-offset-2">
            {!! Form::open(['route' => 'category.store', 'method' => 'POST', 'files' => true, 'data-parsley-validate'=>'','enctype'=>'multipart/form-data']) !!}

            <div class="form-group">
                {{ Form::label('name', 'Name') }}
                {{ Form::text('name', null, array('class' => 'form-control','required'=>'','minlength'=>'5','placeholder'=>'Enter Category Name')) }}
            </div>

            <div class="form-group">
                {{ Form::label('description', 'Description') }}
                <textarea cols="10" class="form-control" name="description" placeholder="Enter Category Name"></textarea>
            </div>
            <div class="form-group">
                {{ Form::label('price', 'Price') }}
                {{ Form::text('price', null, array('class' => 'form-control' , 'placeholder'=>'Enter Category price')) }}
            </div>

            <div class="form-group">
                {{ Form::label('size', 'Size') }}
                {{ Form::select('size', [ 'small' => 'Small', 'medium' => 'Medium','large'=>'Large'], null, ['class' => 'form-control', 'placeholder'=>'Select Category size']) }}
            </div>

            <div class="form-group">
                {{ Form::label('subcategory_id', 'Category') }}
                {{ Form::select('subcategory_id',$subcat, null, ['class' => 'form-control','placeholder'=>'Select Category']) }}
            </div>

            <div class="form-group">
                {{ Form::label('image', 'Image') }}
                {{ Form::file('image',array('class' => 'form-control','placeholder'=>'Enter Category Image')) }}
            </div>

             {{ Form::submit('Create', array('class' => 'btn btn-default')) }}
            {!! Form::close() !!}
            </div>
            </div>
@stop
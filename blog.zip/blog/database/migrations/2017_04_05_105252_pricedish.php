<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Pricedish extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('pricedishes', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('dish_id');
            $table->string('small');
            $table->string('medium');
            $table->string('large');
            $table->string('regular');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('pricedishes');
    }
}

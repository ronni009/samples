<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateAddonpricesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('addonprices', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('dish_id');
            $table->string('addon_name');
            $table->string('product1');
            $table->string('product2');
            $table->string('product3');
            $table->string('product4');
            $table->string('product5');
            $table->string('product6');
            $table->string('price1');
            $table->string('price2');
            $table->string('price3');
            $table->string('price4');
            $table->string('price5');
            $table->string('price6');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('addonprices');
    }
}

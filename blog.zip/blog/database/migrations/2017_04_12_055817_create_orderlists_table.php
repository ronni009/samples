<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateOrderlistsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('orderlists', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('client_id');
            $table->string('order_description');
            $table->string('addon_name');
            $table->string('special_request');
            $table->string('net_price');
            $table->string('quantity');
            $table->string('taxes');
            $table->string('sub_total');
            $table->string('default_value');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('orderlists');
    }
}

<?php $__env->startSection('content'); ?>
    <section class="content">
<style type="text/css">
img.zoom {
    width: 60px;
    height: 60px;
    -webkit-transition: all .2s ease-in-out;
    -moz-transition: all .2s ease-in-out;
    -o-transition: all .2s ease-in-out;
    -ms-transition: all .2s ease-in-out;
}
 
.transition {
    -webkit-transform: scale(2.8); 
    -moz-transform: scale(2.8);
    -o-transform: scale(2.8);
    transform: scale(2.8);
}

</style>
      <!-- SELECT2 EXAMPLE -->
        <?php if($errors->has()): ?>
        <div class="alert alert-danger alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <h4><i class="icon fa fa-ban"></i> Alert!</h4>
            <?php foreach($errors->all() as $error): ?>
                <?php echo e($error); ?><br>        
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
      <div class="box box-default">
        <div class="box-header with-border">
          <h3 class="box-title">Edit Offer</h3>

          <div class="box-tools pull-right">
            
          </div>
        </div>

  <?php echo Form::open(['route'=>['offers.update',$offer_edit->id],'method'=>'POST','enctype'=>'multipart/form-data']); ?>

       <?php echo csrf_field(); ?>

       <?php echo method_field('PUT'); ?>

    <div class="box-body">
          <div class="row">
            <div class="col-md-6">
              <div class="form-group">
              <?php echo Form::label('offer_name','Offer Name'); ?>

              <?php echo Form::text('offer_name',@$offer_edit->offer_name,['class'=>'form-control','id'=>'offer_name','placeholder'=>'Enter here..','required'=>'required']); ?>

            </div>
              <!-- /.form-group -->
               <div class="form-group">
             <?php /*   <span style="color:grey">(eg: Snacks, Appetizer, Main Course, Beverages etc. Please add 1 at a time.*)</span> */ ?>
              </div>
              <div class="form-group">
                <?php echo Form::label('description','Description'); ?>

                <textarea name="description" class="form-control" placeholder="Enter here.."><?php echo e(@$offer_edit->description); ?></textarea>
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <?php echo Form::label('status','Select Status'); ?>

                <?php echo Form::select('status',['active'=>'active','inactive'=>'inactive'],@$offer_edit->status,['class'=>'form-control']); ?>

              </div>
            </div>
         </div>
         <div class="row">
          <div class="col-md-4">
              <div class="form-group">
                <?php echo Form::label('dish1','Select Dish1'); ?>

                <?php echo Form::select('dish1',@$dish_name,@$offer_edit->dish1,['class'=>'form-control','placeholder'=>'--Select dish--','id'=>'select1']); ?>

              </div>
            </div>
            <div class="col-md-4">
              <div class="form-group">
                <?php echo Form::label('rest_name1','Restaurant'); ?>

                <?php echo Form::select('rest_name1',@$rest_name,@$offer_edit->rest_name1,['class'=>'form-control','placeholder'=>'--Restaurant--','id'=>'select2']); ?>

              </div>
            </div>
            <div class="col-md-4">
              <div class="form-group">
                  <?php echo Form::label('type','Type'); ?><br>
                  <?php echo Form::select('type1',['small'=>'small','medium'=>'medium','large'=>'large','standard'=>'standard'],@$offer_edit->type1,['class'=>'form-control','placeholder'=>'--select type--']); ?>

                </div>
              </div>
          </div> 
          <div class="row">
            <div class="col-md-4">
              <div class="form-group">
                <?php echo Form::label('dish2','Select Dish2'); ?>

                <?php echo Form::select('dish2',@$dish_name,@$offer_edit->dish2,['class'=>'form-control','placeholder'=>'--Select dish--','id'=>'select3']); ?>

              </div>
            </div>
            <div class="col-md-4">
              <div class="form-group">
                <?php echo Form::label('rest_name2','Restaurant'); ?>

                <?php echo Form::select('rest_name2',@$rest_name,@$offer_edit->rest_name2,['class'=>'form-control','placeholder'=>'--Restaurant--','id'=>'select4']); ?>

              </div>
            </div>
            <div class="col-md-4">
              <div class="form-group">
                  <?php echo Form::label('type','Type'); ?><br>
                  <?php echo Form::select('type2',['small'=>'small','medium'=>'medium','large'=>'large','standard'=>'standard'],@$offer_edit->type2,['class'=>'form-control','placeholder'=>'--select type--']); ?>

                </div>
              </div>
          </div>
          <div class="row">
             <div class="col-md-4">
              <div class="form-group">
                <?php echo Form::label('dish3','Select Dish3'); ?>

                <?php echo Form::select('dish3',@$dish_name,@$offer_edit->dish3,['class'=>'form-control','placeholder'=>'--Select dish--','id'=>'select1']); ?>

              </div>
            </div>
            <div class="col-md-4">
              <div class="form-group">
                <?php echo Form::label('rest_name3','Restaurant'); ?>

                <?php echo Form::select('rest_name3',@$rest_name,@$offer_edit->rest_name3,['class'=>'form-control','placeholder'=>'--Restaurant--','id'=>'select2']); ?>

              </div>
            </div>
            <div class="col-md-4">
              <div class="form-group">
                  <?php echo Form::label('type','Type'); ?><br>
                  <?php echo Form::select('type3',['small'=>'small','medium'=>'medium','large'=>'large','standard'=>'standard'],@$offer_edit->type3,['class'=>'form-control','placeholder'=>'--select type--']); ?>

                </div>
              </div>
          </div>
            <div class="row">
              <div class="col-md-6">
               <div class="form-group">
                <?php echo Form::label('price','Enter Price'); ?>

                <?php echo Form::text('price',@$offer_edit->price,['class'=>'form-control','placeholder'=>'Enter here..']); ?>

              </div>
              <div class="form-group">
                <?php echo Form::label('image','Select Image'); ?><br>
                <img class="zoom" src="<?php echo e(URL::to('images',@$offer_edit->image)); ?>" />
                 <?php echo Form::hidden('file',@$offer_edit->image,['class'=>'form-control']); ?>

                <?php echo Form::file('image',['class'=>'form-control']); ?>

                <span style="color:grey">(image must be 400px wide by 300px tall.*)</span>
              </div>
              <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
               <div class="form-group">
                <button type="submit" class="btn btn-primary">Submit</button>
                <a class="btn btn-primary" href="<?php echo e(route('offers.index')); ?>">Close</a>
              </div>
            </div>
          </div>
              <!-- /.form-group -->
            
    </div>
</div>
</section>

  <?php echo Form::close(); ?>

<script>
 /* $("#select1").change(function() {
  if ($(this).data('options') == undefined) {
    /*Taking an array of all options-2 and kind of embedding it on the select1*/
 /*   $(this).data('options', $('#select2 option').clone());
  }
  var id = $(this).val();
  var options = $(this).data('options').filter('[value=' + id + ']');
  $('#select2').html(options);*/
});
  </script>
  <script>
  /*$("#select3").change(function() {
  if ($(this).data('options') == undefined) {
    /*Taking an array of all options-2 and kind of embedding it on the select1*/
  /*  $(this).data('options', $('#select4 option').clone());
  }
  var id = $(this).val();
  var options = $(this).data('options').filter('[value=' + id + ']');
  $('#select4').html(options);*/
});
  </script>
<script>
  $('input.example').on('change', function() {
    $('input.example').not(this).prop('checked', false);  
});
</script>
<script>
  $('input.example2').on('change', function() {
    $('input.example2').not(this).prop('checked', false);  
});
</script>
<script>
  $('input.example3').on('change', function() {
    $('input.example3').not(this).prop('checked', false);  
});
</script>

   <script type="text/javascript" src="http://code.jquery.com/jquery-1.8.2.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/elevatezoom/3.0.8/jquery.elevatezoom.js" type="text/javascript"></script>
<script>

   $(document).ready(function(){
    $('.zoom').hover(function() {
        $(this).addClass('transition');
    }, function() {
        $(this).removeClass('transition');
    });
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
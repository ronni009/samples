 
<?php $__env->startSection('content'); ?>
  <div class="row">
      <div class="col-lg-12 margin-tb">
          <div class="pull-left">
              <h2>Dish Details</h2>
          </div>
          <div class="pull-right">
              <a class="btn btn-primary" href="<?php echo e(route('menu.index')); ?>"> Back</a>
          </div>
      </div>
  </div>


      <section class="content">

      <div class="box box-default">
        <div class="box-header with-border">
          <h3 class="box-title">Dish Details</h3>

          <div class="box-tools pull-right">
            
          </div>
        </div>

      
    <div class="box-body">
          <div class="row">
            <div class="col-md-10">
              <div class="form-group">
                  <table id="example2" class="table table-bordered table-striped" cellspacing="0" width="100%" >
                    <tr>
                  <th>Name:</th>
                        <td> <?php echo e($show_details->dish_name); ?></td>
                  </tr>
                  <tr>
                  <th>Description:</th>
                        <td> <?php echo e($show_details->description); ?></td>
                  </tr>
                  <th>Food Type:</th>
                        <td> <?php echo e($show_details->foodtype); ?></td>
                  </tr>
                  <th>Category:</th>
                        <td> <?php echo e($show_details->category_name); ?></td>
                  </tr>
                  <th>Restaurant:</th>
                        <td> <?php echo e($show_details->rest_name); ?></td>
                  </tr>
            </table>
            </div>
             

              <!-- /.form-group -->
            </div>
        </div>
    </div>
</div>
<?php /* </section>

<section class="content"> */ ?>

      <div class="box box-default">
        <div class="box-header with-border">
          <h3 class="box-title">Price Details</h3>

          <div class="box-tools pull-right">
            
          </div>
        </div>

      
    <div class="box-body">
          <div class="row">
            <div class="col-md-10">
              <div class="form-group">
                  <table id="example2" class="table table-bordered table-striped" cellspacing="0" width="100%" >
                <tr>
            <th>Small Price (QAR):</th>
            <td> <?php echo e($show_details->small); ?></td>
      </tr>
      <tr>  
            <th>Medium Price (QAR):</th>
            <td> <?php echo e($show_details->medium); ?></td>
      </tr>
      <tr>  
            <th>Large Price (QAR): </th>
            <td> <?php echo e($show_details->large); ?></td>
      </tr>
      <tr>  
            <th>Regular Price (QAR): </th>
            <td> <?php echo e($show_details->regular); ?></td>
      </tr>
            </table>
            </div>
             

              <!-- /.form-group -->
            </div>
        </div>
    </div>
</div>



<div class="box box-default">
        <div class="box-header with-border">
          <h3 class="box-title">Addon Details</h3>

          <div class="box-tools pull-right">
            
          </div>
        </div>

      
    <div class="box-body">
          <div class="row">
            <div class="col-md-10">
              <div class="form-group">
                  <table id="example2" class="table table-bordered table-striped" cellspacing="0" width="100%" >
               <tr> 
        <th>Product1:</th>
        <td> <?php echo e($show_details->product1); ?></td>
      </tr>
      <tr>  
        <th>Price1 (QAR):</th>
        <td> <?php echo e($show_details->price1); ?></td>
      </tr>
      <tr>  
        <th>Product2:</th>
        <td> <?php echo e($show_details->product2); ?></td>
      </tr>
      <tr>  
        <th>Price2 (QAR):</th>
        <td> <?php echo e($show_details->price2); ?></td>
      </tr>
      <tr>  
        <th>Product3:</th>
        <td> <?php echo e($show_details->product3); ?></td>
      </tr>
      <tr>  
        <th>Price3 (QAR):</th>
        <td> <?php echo e($show_details->price3); ?></td>
      </tr>
      <tr>  
        <th>Product4:</th>
        <td> <?php echo e($show_details->product4); ?></td>
      </tr>
      <tr>  
        <th>Price4 (QAR):</th>
        <td> <?php echo e($show_details->price4); ?></td>
      </tr>
      <tr>  
        <th>Product5:</th>
        <td> <?php echo e($show_details->product5); ?></td>
      </tr>
      <tr>
        <th>Price5 (QAR):</th>
        <td> <?php echo e($show_details->price5); ?></td>
      </tr>
      <tr>
        <th>Product6:</th>
        <td> <?php echo e($show_details->product6); ?></td>
      </tr> 
        <th>Price6 (QAR):</th>
        <td> <?php echo e($show_details->price6); ?></td>
      </tr>
            </table>
            </div>
             

              <!-- /.form-group -->
            </div>
        </div>
    </div>
</div>

</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 

<?php $__env->startSection('content'); ?>
        <?php /* messages */ ?>
	<?php if($message = Session::get('success')): ?>
		<div class="alert alert-success">
       <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
			<p><?php echo e($message); ?></p>
		</div>
	<?php endif; ?>
  <?php if($message = Session::get('updated')): ?>
    <div class="alert alert-success">
       <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
      <p><?php echo e($message); ?></p>
    </div>
  <?php endif; ?>
   <?php if($message = Session::get('deleted')): ?>
    <div class="alert alert-success">
       <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
      <p><?php echo e($message); ?></p>
    </div>
  <?php endif; ?>
  <?php /* box begins */ ?>
	 <div class="box">
              <div class="box-header">
                    <h3 class="box-title">List of Users</h3>
                  </div><!-- /.box-header -->
                  <div class="box-footer">
                <a  href="<?php echo e(route('appuser.create')); ?>" button type = "button" class = "btn btn-primary" >Add User</button></a>
              </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example2" class="table table-bordered table-striped" cellspacing="0" width="100%" >
               <thead>
               <tr>
			<th>No</th>
			<th>Name</th>
      <th>Password</th>
      <th>Action</th>
		</tr>   
                </thead>
                <tbody>
                  <?php $__empty_1 = true; foreach($userdetail as $userdetails): $__empty_1 = false; ?>
                  <tr class="odd gradeX">
                        <td><?php echo e($userdetails->id); ?></td> 
                        <td><?php echo e($userdetails->username); ?></td>
                        <td><?php echo e($userdetails->password); ?></td>
                  <td>
                     <a class="btn btn-primary" href="<?php echo e(route('appuser.edit',$userdetails->id)); ?>">Edit</a>
                  </td>
                    </tr>
                  <?php endforeach; if ($__empty_1): ?>
                  <tr class="odd gradeX">
                    <td colspan=13 class="text-center">No Records Found</td>
                    </tr>  
                  <?php endif; ?>
                    
                </tbody>
                <tfoot>
                 <tr>
			<th>No</th>
      <th>Name</th>
      <th>Password</th>
      <th>Action</th>
		</tr>
                </tfoot>
              </table>
           <?php /*   <?php echo $data->links(); ?>  */ ?>  
            </div>  
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
 

   <!-- <script type="text/javascript">
      $(function () {
   $("#example2").DataTable();
    // $('#example2').DataTable({
    //   "paging": true,
    //   "lengthChange": false,
    //   "searching": false,
    //   "ordering": true,
    //   "info": true,
    //   "autoWidth": false
    "scrollX": true
    // });
  });
    </script>-->
    <script>
     $(document).ready(function() {
    $('#example2').DataTable( {
        "scrollX": true
    } );
} );  /*
    $(document).ready(function (){
    var table = $('#example2').dataTable({
       "aLengthMenu": [ [2, 5, 10, -1], [2, 5, 10, "All"] ],
       "iDisplayLength" : 4,        
    });
}); */
    </script>

   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 

<?php $__env->startSection('content'); ?>

 <section class="content-header">
            <ol class="breadcrumb">
        <li><a href="<?php echo e(url('')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?php echo e(url('')); ?>"><i class="fa fa-sitemap"></i> Users</a></li>
        <li class="active">Manage Users</li>
      </ol>
  </section>


<!--<div class="row">
	    <div class="col-lg-12 margin-tb">
	        <div class="pull-left">
	            <h2>Users Management</h2>
	        </div>
	        <div class="pull-right">
	            <a class="btn btn-success" href="<?php echo e(route('users.create')); ?>"> Create New User</a>
	        </div>
	    </div>
	</div>-->
	<?php if($message = Session::get('success')): ?>
		<div class="alert alert-success">
			<p><?php echo e($message); ?></p>
		</div>
	<?php endif; ?>
	 <div class="box">
              <div class="box-header">
                    <h3 class="box-title">List of Users</h3>
                  </div><!-- /.box-header -->
                  <div class="box-footer">
                <a  href="<?php echo e(route('users.create')); ?>" button type = "button" class = "btn btn-primary" >Add User</button></a>
              </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example2" class="table table-bordered table-striped" cellspacing="0" width="100%" >
               <thead>
               <tr>
			<th>No</th>
			<th>Name</th>
			<th>Email</th>
			<th>Roles</th>
			<th >Action</th>
		</tr>
                </thead>
                <tbody>
                   <?php if(!count($data )): ?>
                        
                    <tr class="odd gradeX">
                    <td colspan=13 class="text-center">No Records Found</td>
                    </tr>    
                        
                <?php else: ?>
               <?php foreach($data as $key => $user): ?>
                    <tr class="odd gradeX">
                        <td><?php echo e(++$i); ?></td> 
						<td><?php echo e($user->name); ?></td>
						<td><?php echo e($user->email); ?></td>
						<td>
							<?php if(!empty($user->roles)): ?>
							<?php foreach($user->roles as $v): ?>
							<label class="label label-success"><?php echo e($v->display_name); ?></label>
				<?php endforeach; ?>
				<?php endif; ?>
						</td>
                     <!--   <td><a title="View Users" data-toggle="tooltip"  class="badge bg-blue" href="<?php echo e(route('users.show',$user->id)); ?>"><i class="fa fa-eye"></i></a>&nbsp;&nbsp;<a title="Edit" data-toggle="tooltip"  class="badge bg-yellow" href="<?php echo e(route('users.edit',$user->id)); ?>"><i class="fa fa-edit"></i></a>&nbsp;&nbsp;
                          <a data-toggle="tooltip" title="Delete" class="badge bg-red" <?php echo Form::open(['method' => 'DELETE','route' => ['users.destroy', $user->id],'style'=>'display:inline']); ?>><i class="fa fa-close"></i></a></td>
                    </tr>-->
                    	<td>
			<a class="btn btn-info" href="<?php echo e(route('users.show',$user->id)); ?>">Show</a>
			<a class="btn btn-primary" href="<?php echo e(route('users.edit',$user->id)); ?>">Edit</a>
      <?php if (\Entrust::can('role-delete')) : ?>
			<?php echo Form::open(['method' => 'DELETE','route' => ['users.destroy', $user->id],'style'=>'display:inline']); ?>

            <?php echo Form::submit('Delete', ['class' => 'btn btn-danger','onclick'=>'return confirm("Are you sure?")']); ?>

        	<?php echo Form::close(); ?>

          <?php endif; // Entrust::can ?>
		</td>
                <?php endforeach; ?> 

                <?php endif; ?>   


                </tbody>
                <tfoot>
                 <tr>
			<th>No</th>
			<th>Name</th>
			<th>Email</th>
			<th>Roles</th>
			<th>Action</th>
		</tr>
                </tfoot>
              </table>
             <?php echo $data->links(); ?>   
            </div>  
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
 

   <!-- <script type="text/javascript">
      $(function () {
   $("#example2").DataTable();
    // $('#example2').DataTable({
    //   "paging": true,
    //   "lengthChange": false,
    //   "searching": false,
    //   "ordering": true,
    //   "info": true,
    //   "autoWidth": false
    "scrollX": true
    // });
  });
    </script>-->
    <script>
     $(document).ready(function() {
    $('#example2').DataTable( {
        "scrollX": true
    } );
} );  /*
    $(document).ready(function (){
    var table = $('#example2').dataTable({
       "aLengthMenu": [ [2, 5, 10, -1], [2, 5, 10, "All"] ],
       "iDisplayLength" : 4,        
    });
}); */
    </script>

   
<?php $__env->stopSection(); ?>
	<!--<table class="table table-bordered">
		<tr>
			<th>No</th>
			<th>Name</th>
			<th>Email</th>
			<th>Roles</th>
			<th width="280px">Action</th>
		</tr>
	<?php foreach($data as $key => $user): ?>
	<tr>
		<td><?php echo e(++$i); ?></td>
		<td><?php echo e($user->name); ?></td>
		<td><?php echo e($user->email); ?></td>
		<td>
			<?php if(!empty($user->roles)): ?>
				<?php foreach($user->roles as $v): ?>
					<label class="label label-success"><?php echo e($v->display_name); ?></label>
				<?php endforeach; ?>
			<?php endif; ?>
		</td>
		<td>
			<a class="btn btn-info" href="<?php echo e(route('users.show',$user->id)); ?>">Show</a>
			<a class="btn btn-primary" href="<?php echo e(route('users.edit',$user->id)); ?>">Edit</a>
			<?php echo Form::open(['method' => 'DELETE','route' => ['users.destroy', $user->id],'style'=>'display:inline']); ?>

            <?php echo Form::submit('Delete', ['class' => 'btn btn-danger']); ?>

        	<?php echo Form::close(); ?>

		</td>
	</tr>
	<?php endforeach; ?>
	</table>
	<?php echo $data->render(); ?>-->

<?php echo $__env->make('admin_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
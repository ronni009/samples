 

<?php $__env->startSection('content'); ?>
<style type="text/css">
img.zoom {
    width: 60px;
    height: 60px;
    -webkit-transition: all .2s ease-in-out;
    -moz-transition: all .2s ease-in-out;
    -o-transition: all .2s ease-in-out;
    -ms-transition: all .2s ease-in-out;
}
 
.transition {
    -webkit-transform: scale(2.8); 
    -moz-transform: scale(2.8);
    -o-transform: scale(2.8);
    transform: scale(2.8);
}

</style>
        <?php /* messages */ ?>
  <?php if($message = Session::get('unsuccessfull')): ?>
    <div class="alert alert-danger">
       <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
      <p><?php echo e($message); ?></p>
    </div>
  <?php endif; ?>
	<?php if($message = Session::get('success')): ?>
		<div class="alert alert-success">
       <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
			<p><?php echo e($message); ?></p>
		</div>
	<?php endif; ?>
  <?php if($message = Session::get('updated')): ?>
    <div class="alert alert-success">
       <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
      <p><?php echo e($message); ?></p>
    </div>
  <?php endif; ?>
   <?php if($message = Session::get('deleted')): ?>
    <div class="alert alert-success">
       <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
      <p><?php echo e($message); ?></p>
    </div>
  <?php endif; ?>
  <?php /* box begins */ ?>
	 <div class="box">
              <div class="box-header">
                    <h3 class="box-title">List of Banner Image</h3>
                  </div><!-- /.box-header -->
                  <div class="box-footer">
                <?php /* <a  href="<?php echo e(route('banner.create')); ?>" button type = "button" class = "btn btn-primary" >Add Banner</button></a> */ ?>
              </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example2" class="table table-bordered table-striped" cellspacing="0" width="100%" >
               <thead>
               <tr>
			<th>No</th>
			<th>Image</th>
      <th>Dish Name</th>
      <th>Offer Name</th>
      <th>Status</th>
      <th>Action</th>
		</tr>   
                </thead>
                <tbody>
                  <?php $__empty_1 = true; foreach($image_detail as $image_details): $__empty_1 = false; ?>
                  <tr class="odd gradeX">
                        <td><?php echo e($image_details->id); ?></td> 
                        <td><img class="zoom" src="<?php echo e(URL::to('images',$image_details->image)); ?>"/></td>
                        <td><?php echo e($image_details->dish_name); ?></td>
                        <td><?php echo e($image_details->offer_name); ?></td>
                        <td><?php echo e($image_details->status); ?></td>
                  <td>
                     <a class="btn btn-primary" href="<?php echo e(route('banner.edit',$image_details->id)); ?>">Edit</a>
                  </td>
                    </tr>
                  <?php endforeach; if ($__empty_1): ?>
                  <tr class="odd gradeX">
                    <td colspan=13 class="text-center">No Records Found</td>
                    </tr>  
                  <?php endif; ?>
                    
                </tbody>
                <tfoot>
                 <tr>
			<th>No</th>
      <th>Image</th>
      <th>Dish Name</th>
      <th>Offer Name</th>
      <th>Status</th>
      <th>Action</th>
		</tr>
                </tfoot>
              </table>
      
           </div>  
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
 
    <script type="text/javascript" src="http://code.jquery.com/jquery-1.8.2.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/elevatezoom/3.0.8/jquery.elevatezoom.js" type="text/javascript"></script>
<script>

   $(document).ready(function(){
    $('.zoom').hover(function() {
        $(this).addClass('transition');
    }, function() {
        $(this).removeClass('transition');
    });
});
</script>


    <script>
     $(document).ready(function() {
    $('#example2').DataTable( {
        "scrollX": true
    } );
} );  
    </script>

   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
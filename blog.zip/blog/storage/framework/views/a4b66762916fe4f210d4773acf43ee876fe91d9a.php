<?php $__env->startSection('content'); ?>
    <section class="content">

      <!-- SELECT2 EXAMPLE -->
        <?php if($errors->has()): ?>
        <div class="alert alert-danger alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <h4><i class="icon fa fa-ban"></i> Alert!</h4>
            <?php foreach($errors->all() as $error): ?>
                <?php echo e($error); ?><br>        
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
      <div class="box box-default">
        <div class="box-header with-border">
          <h3 class="box-title">Edit Addon</h3>

          <div class="box-tools pull-right">
            
          </div>
        </div>

	<?php echo Form::open(['route'=>['addon.update',$addon_show->id],'method'=>'PATCH']); ?>

       <?php echo csrf_field(); ?>

    <div class="box-body">
          <div class="row">
            <div class="col-md-6">
              <div class="form-group">
               <?php /*  <label for="name">Category Name</label>
                  <input type="text" class="form-control" name="name" id="name" placeholder="Name">
              </div> */ ?>
              <?php echo Form::label('addon_name','Addon Name'); ?>

              <?php echo Form::text('addon_name',$addon_show->addon_name,['class'=>'form-control','id'=>'category_name','placeholder'=>'Enter here..','required'=>'required']); ?>

            </div>
              <!-- /.form-group -->
               <div class="form-group">
               <span style="color:grey">(eg: Toppings, sauce, dips only one allowed.*)</span>
              </div>
              <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <?php echo Form::label('status','Status'); ?>

                  <?php echo Form::select('status',['active'=>'active','inactive'=>'inactive'],$addon_show->status,['class'=>'form-control']); ?>

              </div>
            </div>
              <!-- /.row -->
            </div>
            <div class="form-group">
                <button type="submit" class="btn btn-primary">Submit</button>
                <a href="<?php echo e(route('addon.index')); ?>" class="btn btn-primary">Close</a>
           </div>
           <!-- /.form-group -->
        </div>
    </div>
</div>
</section>

	<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
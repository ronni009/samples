 
<?php $__env->startSection('content'); ?>
	<div class="row">
	    <div class="col-lg-12 margin-tb">
	        <div class="pull-left">
	            <h2>Dish Details</h2>
	        </div>
	        <div class="pull-right">
	            <a class="btn btn-primary" href="<?php echo e(route('menu.index')); ?>"> Back</a>
	        </div>
	    </div>
	</div>
      <table id="example2" class="table table-bordered table-striped" cellspacing="0" width="100%" >
      <tr>
      	<th>Name:</th>
      	<td> <?php echo e($show_details->dish_name); ?></td>
      </tr>
      <tr>
      	<th>Description:</th>
      	<td> <?php echo e($show_details->description); ?></td>
      </tr>
      <tr>
      	<th>Small Price:</th>
      	<td> <?php echo e($show_details->small); ?></td>
      </tr>
      <tr>	
      	<th>Medium Price:</th>
      	<td> <?php echo e($show_details->medium); ?></td>
      </tr>
      <tr>	
      	<th>Large Price: </th>
      	<td> <?php echo e($show_details->large); ?></td>
      </tr>
      <tr>	
      	<th>Product1:</th>
      	<td> <?php echo e($show_details->product1); ?></td>
      </tr>
      <tr>	
      	<th>Price1:</th>
      	<td> <?php echo e($show_details->price1); ?></td>
      </tr>
      <tr>	
      	<th>Product2:</th>
      	<td> <?php echo e($show_details->product2); ?></td>
      </tr>
      <tr>	
      	<th>Price2:</th>
      	<td> <?php echo e($show_details->price2); ?></td>
      </tr>
      <tr>	
      	<th>Product3:</th>
      	<td> <?php echo e($show_details->product3); ?></td>
      </tr>
      <tr>	
      	<th>Price3:</th>
      	<td> <?php echo e($show_details->price3); ?></td>
      </tr>
      <tr>	
      	<th>Product4:</th>
      	<td> <?php echo e($show_details->product4); ?></td>
      </tr>
      <tr>	
      	<th>Price4:</th>
      	<td> <?php echo e($show_details->price4); ?></td>
      </tr>
      <tr>	
      	<th>Product5:</th>
      	<td> <?php echo e($show_details->product5); ?></td>
      </tr>
      <tr>
      	<th>Price5:</th>
      	<td> <?php echo e($show_details->price5); ?></td>
      </tr>
      <tr>
      	<th>Product6:</th>
      	<td> <?php echo e($show_details->product6); ?></td>
      </tr>	
      	<th>Price6:</th>
      	<td> <?php echo e($show_details->price6); ?></td>
      </tr>
      
      </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
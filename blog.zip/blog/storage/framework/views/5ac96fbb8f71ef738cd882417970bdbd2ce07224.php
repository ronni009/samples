<?php $__env->startSection('content'); ?>
    <section class="content">

      <!-- SELECT2 EXAMPLE -->
        <?php if($errors->has()): ?>
        <div class="alert alert-danger alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <h4><i class="icon fa fa-ban"></i> Alert!</h4>
            <?php foreach($errors->all() as $error): ?>
                <?php echo e($error); ?><br>        
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
      <div class="box box-default">
        <div class="box-header with-border">
          <h3 class="box-title">Edit User</h3>
        </div>

	<?php echo Form::open(['route'=>['appuser.update',$useredit->id],'method'=>'POST']); ?>

       <?php echo csrf_field(); ?>

       <?php echo method_field('PUT'); ?>

    <div class="box-body">
          <div class="row">
            <div class="col-md-6">
              <div class="form-group">
               <?php /*  <label for="name">Category Name</label>
                  <input type="text" class="form-control" name="name" id="name" placeholder="Name">
              </div> */ ?>
              <?php echo Form::label('username','User Name'); ?>

              <?php echo Form::text('username',@$useredit->username,['class'=>'form-control','placeholder'=>'Enter here..','required'=>'required']); ?>

            </div>
            <div class="form-group">
              <?php echo Form::label('password','Enter Password'); ?>

             <input type="password" name="password" class="form-control" value="<?php echo e(@$useredit->password); ?>" placeholder="Enter here..">
            </div>
              <!-- /.form-group -->
               
              <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
               <div class="form-group">
                <button type="submit" class="btn btn-primary">Submit</button>
                <a class="btn btn-primary" href="<?php echo e(route('appuser.index')); ?>">Close</a>
        </div>

              <!-- /.form-group -->
            </div>
        </div>
    </div>
</div>
</section>

	<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
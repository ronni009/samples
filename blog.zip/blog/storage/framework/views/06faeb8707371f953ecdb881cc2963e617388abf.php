<?php $__env->startSection('content'); ?>
    <section class="content">

      <!-- SELECT2 EXAMPLE -->
        <?php if($errors->has()): ?>
        <div class="alert alert-danger alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <h4><i class="icon fa fa-ban"></i> Alert!</h4>
            <?php foreach($errors->all() as $error): ?>
                <?php echo e($error); ?><br>        
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
      <div class="box box-default">
        <div class="box-header with-border">
          <h3 class="box-title">Add New Offer</h3>

          <div class="box-tools pull-right">
           
          </div>
        </div>

	<?php echo Form::open(['route'=>'offers.store','method'=>'POST','enctype'=>'multipart/form-data']); ?>

       <?php echo csrf_field(); ?>

    <div class="box-body">
          <div class="row">
            <div class="col-md-6">
              <div class="form-group">
              <?php echo Form::label('offer_name','Offer Name'); ?>

              <?php echo Form::text('offer_name',null,['class'=>'form-control','id'=>'offer_name','placeholder'=>'Enter here..','required'=>'required']); ?>

            </div>
              <!-- /.form-group -->
               <div class="form-group">
             <?php /*   <span style="color:grey">(eg: Snacks, Appetizer, Main Course, Beverages etc. Please add 1 at a time.*)</span> */ ?>
              </div>
              <div class="form-group">
                <?php echo Form::label('description','Description'); ?>

                <textarea name="description" class="form-control" placeholder="Enter here.."></textarea>
              </div>
            </div>
         </div>
         <div class="row">
          <div class="col-md-4">
              <div class="form-group">
                <?php echo Form::label('dish1','Select Dish1'); ?>

                <?php echo Form::select('dish1',@$dish_name,null,['class'=>'form-control','placeholder'=>'--Select dish--','id'=>'select1']); ?>

              </div>
            </div>
            <div class="col-md-4">
              <div class="form-group">
                <?php echo Form::label('rest_id1','Restaurant'); ?>

                <?php echo Form::select('rest_id1',@$rest_name,null,['class'=>'form-control','placeholder'=>'--Restaurant--','id'=>'select2']); ?>

              </div>
            </div>
            <div class="col-md-4">
              <div class="form-group">
                  <?php echo Form::label('type','Type'); ?><br>
                  <?php echo Form::select('type1',['small'=>'small','medium'=>'medium','large'=>'large','standard'=>'standard'],null,['class'=>'form-control','placeholder'=>'--select type--']); ?>

                </div>
              </div>
          </div> 
          <div class="row">
            <div class="col-md-4">
              <div class="form-group">
                <?php echo Form::label('dish2','Select Dish2'); ?>

                <?php echo Form::select('dish2',@$dish_name,null,['class'=>'form-control','placeholder'=>'--Select dish--','id'=>'select3']); ?>

              </div>
            </div>
            <div class="col-md-4">
              <div class="form-group">
                <?php echo Form::label('rest_id2','Restaurant'); ?>

                <?php echo Form::select('rest_id2',@$rest_name,null,['class'=>'form-control','placeholder'=>'--Restaurant--','id'=>'select4']); ?>

              </div>
            </div>
            <div class="col-md-4">
              <div class="form-group">
                  <?php echo Form::label('type','Type'); ?><br>
                  <?php echo Form::select('type2',['small'=>'small','medium'=>'medium','large'=>'large','standard'=>'standard'],null,['class'=>'form-control','placeholder'=>'--select type--']); ?>

                </div>
              </div>
          </div>
          <div class="row">
             <div class="col-md-4">
              <div class="form-group">
                <?php echo Form::label('dish3','Select Dish3'); ?>

                <?php echo Form::select('dish3',@$dish_name,null,['class'=>'form-control','placeholder'=>'--Select dish--','id'=>'select1']); ?>

              </div>
            </div>
            <div class="col-md-4">
              <div class="form-group">
                <?php echo Form::label('rest_id3','Restaurant'); ?>

                <?php echo Form::select('rest_id3',@$rest_name,null,['class'=>'form-control','placeholder'=>'--Restaurant--','id'=>'select2']); ?>

              </div>
            </div>
            <div class="col-md-4">
              <div class="form-group">
                  <?php echo Form::label('type','Type'); ?><br>
                  <?php echo Form::select('type3',['small'=>'small','medium'=>'medium','large'=>'large','standard'=>'standard'],null,['class'=>'form-control','placeholder'=>'--select type--']); ?>

                </div>
              </div>
          </div>
            <div class="row">
              <div class="col-md-6">
               <div class="form-group">
                <?php echo Form::label('price','Enter Price'); ?>

                <?php echo Form::text('price',null,['class'=>'form-control','placeholder'=>'Enter here..']); ?>

              </div>
              <div class="form-group">
                <?php echo Form::label('image','Select Image'); ?>

                <?php echo Form::file('image',['class'=>'form-control']); ?>

                <span style="color:grey">(image must be 400px wide by 300px tall.*)</span>
              </div>
              <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
               <div class="form-group">
                <button type="submit" class="btn btn-primary">Add Offer</button>
              </div>
            </div>
          </div>
              <!-- /.form-group -->
            
    </div>
</div>
</section>

	<?php echo Form::close(); ?>

<script>
 /* $("#select1").change(function() {
  if ($(this).data('options') == undefined) {
    /*Taking an array of all options-2 and kind of embedding it on the select1*/
 /*   $(this).data('options', $('#select2 option').clone());
  }
  var id = $(this).val();
  var options = $(this).data('options').filter('[value=' + id + ']');
  $('#select2').html(options);*/
});
  </script>
  <script>
  /*$("#select3").change(function() {
  if ($(this).data('options') == undefined) {
    /*Taking an array of all options-2 and kind of embedding it on the select1*/
  /*  $(this).data('options', $('#select4 option').clone());
  }
  var id = $(this).val();
  var options = $(this).data('options').filter('[value=' + id + ']');
  $('#select4').html(options);*/
});
  </script>
<script>
  $('input.example').on('change', function() {
    $('input.example').not(this).prop('checked', false);  
});
</script>
<script>
  $('input.example2').on('change', function() {
    $('input.example2').not(this).prop('checked', false);  
});
</script>
<script>
  $('input.example3').on('change', function() {
    $('input.example3').not(this).prop('checked', false);  
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
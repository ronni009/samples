<?php $__env->startSection('content'); ?>
    <section class="content">

      <!-- SELECT2 EXAMPLE -->
        <?php if($errors->has()): ?>
        <div class="alert alert-danger alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <h4><i class="icon fa fa-ban"></i> Alert!</h4>
            <?php foreach($errors->all() as $error): ?>
                <?php echo e($error); ?><br>        
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
      <div class="box box-default">
        <div class="box-header with-border">
          <h3 class="box-title">Create New Dish</h3>

          <div class="box-tools pull-right">
            
          </div>
        </div>

	<?php echo Form::open(['route'=>'menu.store','method'=>'POST','enctype'=>'multipart/form-data']); ?>

       <?php echo csrf_field(); ?>

      
    <div class="box-body">
          <div class="row">
            <div class="col-md-6">
              <!-- form-group -->
              <div class="form-group">
                <?php echo Form::label('dish_name','Dish Name'); ?>

                <?php echo Form::text('dish_name',null,['class'=>'form-control','id'=>'dish_name','placeholder'=>'Enter here..','required'=>'required']); ?>

               
             </div>
               <div class="form-group">
               <?php echo Form::label('description','Short description'); ?>

               <textarea name="description" class="form-control" placeholder="Enter here.." cols="20%"></textarea>
              </div>
              <div class="form-group">
                <?php echo Form::label('image','Add Image'); ?>

                <?php echo Form::file('image',['class'=>'form-control']); ?>

                <span style="color:grey">(image must be 400px wide by 300px tall.*)</span>
              </div> 
              <div class="form-group">
                  <?php echo Form::label('rest_id','Select Restaurant'); ?>

                  <?php echo Form::Select('rest_id',@$restaurant_name,null,['class'=>'form-control Select2','placeholder'=>'--Select Restaurant--']); ?>

              </div>
              <div class="form-group">
                  <?php echo Form::label('category','Select Category'); ?>

                  <?php echo Form::Select('cat_id',@$category_list,null,['class'=>'form-control Select2','placeholder'=>'--Select category--']); ?>

              </div>
            </div>  
          </div>  
          <div class="row">                   <!-- size beginss -->
            <div class="col-md-3">
              <div class="form-group">
                <?php echo Form::hidden('check1',0); ?>

                <?php echo e(Form::checkbox('check1',1,false,['id'=>'check1'])); ?>Select Size
              </div>
              </div>
          <div id="autoUpdate">  <!-- /. auto -->
            <div class="col-md-3">
              <div class="form-group">
                <label>Small</label>
                <input type="text" name="small" class="form-control" placeholder="Enter price">
                </div>
              </div>
            <div class="col-md-3">  
              <div class="form-group">
                  <label>Medium</label>
                  <input type="text" name="medium" class="form-control" placeholder="Enter price">
                </div>
              </div>
            <div class="col-md-3">
              <div class="form-group">
                <label>Large</label>
                <input type="text" name="large" class="form-control" placeholder="Enter price">
              </div>
            </div>
          </div>    <!-- /.auto -->
        </div>  
          <div class="row">
            <div class="col-md-3">
              <div class="form-group">
                <?php echo Form::label('foodtype','Food Type'); ?>

                <?php echo Form::select('foodtype',['veg'=>'veg','non-veg'=>'non-veg'],null,['class'=>'form-control']); ?>

                </div>
              </div>
          </div>
          <div class="row">   <!--  addonn begins -->
            <div class="col-md-2"> 
              <div class="form-group">
                <?php echo Form::hidden('check2',0); ?>

              <?php echo Form::checkbox('check2',1,false,['id'=>'check2']); ?>Select addon
              </div>
            </div>
           </div> 
        <div id="autoUpdate2">   <!-- /.auto -->
         <div class="row">
              <div class="col-md-6"> 
              <div class="form-group">
                <label>Add on</label>
               <?php echo Form::select('addon_name',@$addon_list,null,['class'=>'form-control Select2','id'=>'selected1','placeholder'=>'--Select addon--']); ?>

                <span style="color:grey">(eg:Toppings,sauce,dips only one allowed.*)</span>
              </div>
            </div>
         </div>

          <div class="row">
            <div class="col-md-3">
              <div class="form-group">
                <?php echo Form::label('product1','Product'); ?>

                <?php echo Form::select('product1',@$product_list,null,['class'=>'form-control Select2','placeholder'=>'--Select product--']); ?>

              </div>

              <div class="form-group">
                 <?php echo Form::select('product2',@$product_list,null,['class'=>'form-control Select2','placeholder'=>'--Select product--']); ?>

              </div>

              <div class="form-group">
                 <?php echo Form::select('product3',@$product_list,null,['class'=>'form-control Select2','placeholder'=>'--Select product--']); ?>

              </div>
            </div>
            
            <div class="col-md-3">
              <div class="form-group">
                <?php echo Form::label('price1','Price'); ?>

                <?php echo Form::text('price1',null,['class'=>'form-control','placeholder'=>'Enter Price']); ?>

              </div>

              <div class="form-group">
                <?php echo Form::text('price2',null,['class'=>'form-control','placeholder'=>'Enter Price']); ?>

              </div>

              <div class="form-group">
                <?php echo Form::text('price3',null,['class'=>'form-control','placeholder'=>'Enter Price']); ?>

              </div>
            </div>

            <div class="col-md-3">
              <div class="form-group">
                <?php echo Form::label('product4','Product'); ?>

                 <?php echo Form::select('product4',@$product_list,null,['class'=>'form-control Select2','placeholder'=>'--Select product--']); ?>

              </div>

              <div class="form-group">
                 <?php echo Form::select('product5',@$product_list,null,['class'=>'form-control Select2','placeholder'=>'--Select product--']); ?>

              </div>

              <div class="form-group">
                <?php echo Form::select('product6',@$product_list,null,['class'=>'form-control Select2','placeholder'=>'--Select product--']); ?>

              </div>
            </div>

            <div class="col-md-3">
              <div class="form-group">
                <?php echo Form::label('price4','Price'); ?>

                <?php echo Form::text('price4',null,['class'=>'form-control','placeholder'=>'Enter Price']); ?>

              </div>

              <div class="form-group">
                <?php echo Form::text('price5',null,['class'=>'form-control','placeholder'=>'Enter Price']); ?>

              </div>

              <div class="form-group">
                <?php echo Form::text('price6',null,['class'=>'form-control','placeholder'=>'Enter Price']); ?>

              </div>
            </div>
          </div>
        </div>  
          <div class="row">
            <div class="col-md-6">
              <?php /*  <div class="form-group">
                <?php echo Form::label('tax','Tax*'); ?>

                <?php echo Form::text('tax',null,['class'=>'form-control','placeholder'=>'enter here']); ?>

              </div> */ ?>
              <div class="form-group" id="dp">
                <?php echo Form::label('regular','Dish Price'); ?>

                <?php echo Form::text('regular',null,['class'=>'form-control','placeholder'=>'enter here']); ?>

              </div>
            </div>
          </div>

        <!-- /.row -->

          <div class="row">
            <div class="col-md-3">
            <div class="form-group">
               <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                <button type="submit" class="btn btn-primary">Add Dish</button>
             </div>
          </div> 
        </div>   
              <!-- /.form-group -->
            </div>
        
    </div>
</div>
</section>

	<?php echo Form::close(); ?>

<script>
$(document).ready(function(){
    $('#check1').change(function(){
        if(this.checked)
            $('#autoUpdate').fadeIn('slow');
        else
            $('#autoUpdate').fadeOut('slow');

    }).change();
});
</script>

<script>
$(document).ready(function(){
    $('#check2').change(function(){
        if(this.checked)
            $('#autoUpdate2').fadeIn('slow');
        else
            $('#autoUpdate2').fadeOut('slow');

    }).change();
});
</script>

<script>
$(document).ready(function(){
    $('#check1').change(function(){
        if(this.checked)
            $('#dp').fadeOut('slow');
        else
            $('#dp').fadeIn('slow');

    }).change();
});
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>
<script>
$(document).ready(function(){
  $('#selected1').on('change', function(e) {
    e.preventDefault();
    var id=$(this).val();
    //alert(addon);die;
    data={id:id};
    $.ajax({
      type:'POST',
      contentType:'application/x-www-form-urlencoded',
      url:'<?php echo e(url("menu/trial")); ?>',
      data:data,
      dataType:'JSON',
      success:function(response){
          console.log(response);
        }
      }

    });
    return false;
  });
});

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
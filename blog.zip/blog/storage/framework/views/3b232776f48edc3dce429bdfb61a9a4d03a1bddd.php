<?php foreach($check as $checks): ?>

<?php echo e($checks); ?>

<?php endforeach; ?>
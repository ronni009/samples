<?php $__env->startSection('content'); ?>
<!--	<div class="row">
	    <div class="col-lg-12 margin-tb">
	        <div class="pull-left">
	            <h2>Create New User</h2>
	        </div>
	        <div class="pull-right">
	            <a class="btn btn-primary" href="<?php echo e(route('users.index')); ?>"> Back</a>
	        </div>
	    </div>
	</div>-->
    <section class="content">

      <!-- SELECT2 EXAMPLE -->
      <div class="box box-default">
        <div class="box-header with-border">
          <h3 class="box-title">Create New User</h3>

          <div class="box-tools pull-right">
            <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
            <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-remove"></i></button>
          </div>
        </div>
	<?php if(count($errors) > 0): ?>
		<div class="alert alert-danger">
			<strong>Whoops!</strong> There were some problems with your input.<br><br>
			<ul>
				<?php foreach($errors->all() as $error): ?>
					<li><?php echo e($error); ?></li>
				<?php endforeach; ?>
			</ul>
		</div>
	<?php endif; ?>
	<?php echo Form::open(array('route' => 'users.store','method'=>'POST')); ?>

    <div class="box-body">
          <div class="row">
            <div class="col-md-6">
              <div class="form-group">
                <label for="name">Name</label>
                  <input type="text" class="form-control" name="name" id="name" placeholder="Name">
              </div>
              <!-- /.form-group -->
               <div class="form-group">
               <label for="exampleInputPassword1">E-mail</label>
                  <input type="email" class="form-control" name="email" id="email" placeholder="E-mail" >
              </div>
              <div class="form-group">
               <label for="password">Password</label>
                  <input type="password" class="form-control" name="password" id="password" placeholder="Password" >
              </div>
              <div class="form-group">
               <label for="confirmpasw">Confirm Password</label>
                  <input type="password" class="form-control" name="confirm-password" id="confirm-password" placeholder="Confirm Password" >
              </div>
              <div class="form-group">
                 <?php echo Form::label('role','Select Role'); ?>

                 <?php echo Form::select('roles[]', $roles, ['class' => 'form-control select2', 'multiple' => 'multiple' , 'name' =>'role','data-placeholder' => 'Select a Country']); ?>

              </div>
               <div class="form-group">
                <button type="submit" class="btn btn-primary">Add User</button>
        </div>

              <!-- /.form-group -->
            </div>
        </div>
    </div>
</div>
</section>

	<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
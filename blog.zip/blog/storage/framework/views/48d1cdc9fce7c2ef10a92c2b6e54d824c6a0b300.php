<?php $__env->startSection('content'); ?>
    <section class="content">

      <!-- SELECT2 EXAMPLE -->
        <?php if($errors->has()): ?>
        <div class="alert alert-danger alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <h4><i class="icon fa fa-ban"></i> Alert!</h4>
            <?php foreach($errors->all() as $error): ?>
                <?php echo e($error); ?><br>        
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
      <div class="box box-default">
        <div class="box-header with-border">
          <h3 class="box-title">Select Report</h3>

          <div class="box-tools pull-right">
            
          </div>
        </div>

	<?php echo Form::open(['route'=>'reports.store','method'=>'POST']); ?>

       <?php echo csrf_field(); ?>

    <div class="box-body">
          <div class="row">
            <div class="col-md-6">
              <div class="form-group">
               <?php /*  <label for="name">Category Name</label>
                  <input type="text" class="form-control" name="name" id="name" placeholder="Name">
              </div> */ ?>
              <?php echo Form::label('report_id','Select content'); ?>

              <?php echo Form::select('report_id',[1=>'Dishes',2=>'Offers',3=>'Clients&Orders'],null,['class'=>'form-control','id'=>'report_id','placeholder'=>'--Select--','required'=>'required']); ?>

            </div>


              <!-- /.form-group -->
               
              <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
               <div class="form-group"> 
                <button type="submit" class="btn btn-success">Download Report</button>
        </div>

              <!-- /.form-group -->
            </div>
          <div class = "col-md-3">
            <div class="form-group">
                <label> To</label></br>
                  <input type="text" class="form-control" name="date_to" id="date_to" value="<?php echo e(@$company_detail->date_to); ?>">
              </div>
          </div>    

          <div class = "col-md-3">
            <div class="form-group">
               <label> From</label></br>
                 <input type="text" class="form-control" name="date_from" id="date_from" value="<?php echo e(@$company_detail->date_from); ?>">
              </div>
            </div>  

        </div>
    </div>
</div>
</section>

	<?php echo Form::close(); ?>



<script>
  $( function() {
    $( "#date_to" ).datepicker();
    $( "#date_from" ).datepicker();
  } );
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>
    <section class="content">

      <!-- SELECT2 EXAMPLE -->
        <?php if($errors->has()): ?>
        <div class="alert alert-danger alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <h4><i class="icon fa fa-ban"></i> Alert!</h4>
            <?php foreach($errors->all() as $error): ?>
                <?php echo e($error); ?><br>        
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
      <div class="box box-default">
        <div class="box-header with-border">
          <h3 class="box-title">Create New Restaurant</h3>

          <div class="box-tools pull-right">
           
          </div>
        </div>

	<?php echo Form::open(['route'=>'restaurant.store','method'=>'POST']); ?>

       <?php echo csrf_field(); ?>

    <div class="box-body">
          <div class="row">
            <div class="col-md-6">
              <div class="form-group">
              <?php echo Form::label('rest_name','Restaurant Name'); ?>

              <?php echo Form::text('rest_name',null,['class'=>'form-control','id'=>'rest_name','placeholder'=>'Enter here..','required'=>'required']); ?>

            </div>
            <div class="form-group">
              <?php echo Form::label('address','Address'); ?>

              <textarea name="address" placeholder="Enter here.." class="form-control"></textarea>
            </div>
            <div class="form-group">
              <?php echo Form::label('mobile','Mobile Number'); ?>

              <?php echo Form::text('mobile',null,['class'=>'form-control','id="mobile','placeholder'=>'Enter here..']); ?>

            </div>
            <div class="form-group">
              <?php echo Form::label('email','Email Address'); ?>

              <?php echo Form::text('email',null,['class'=>'form-control','id="email','placeholder'=>'Enter here..']); ?>

            </div>
              <!-- /.form-group -->
               <div class="form-group">
             <?php /*   <span style="color:grey">(eg: Snacks, Appetizer, Main Course, Beverages etc. Please add 1 at a time.*)</span> */ ?>
              </div>
              <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
               <div class="form-group">
                <button type="submit" class="btn btn-primary">Add Restaurant</button>
        </div>

              <!-- /.form-group -->
            </div>
        </div>
    </div>
</div>
</section>

	<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
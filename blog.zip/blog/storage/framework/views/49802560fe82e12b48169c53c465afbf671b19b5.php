 
<?php $__env->startSection('content'); ?>
	<div class="row">
	    <div class="col-lg-12 margin-tb">
	        <div class="pull-left">
	            <h2>Status Details</h2>
	        </div>
	        <div class="pull-right">
	            <a class="btn btn-primary" href="<?php echo e(route('status.index')); ?>"> Back</a>
	        </div>
	    </div>
	</div>
      <div class="row">
          <div class="col-lg-12 margin-tb">
              <div class="pull-left">
                  <h3></h3>
              </div>
              <div class="pull-right">
                  <?php /* <h3>Mobile Number-3380422603</h3> */ ?>
              </div>
          </div>
      </div>
      <table id="example2" class="table table-bordered table-striped" cellspacing="0" width="100%" >
      <tr>
        <th>Month</th>	
        <th>Total Orders</th>
        <th>Total Amount</th>
      </tr>
      <tr>
          <td><?php echo e($MonthName->name); ?></td>
          <td><?php echo e($OrderCount); ?> </td>
          <td><?php echo e($OrderSum); ?>  </td>
      </tr>         
      </table>
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
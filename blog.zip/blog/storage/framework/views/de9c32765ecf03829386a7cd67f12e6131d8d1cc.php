 

<?php $__env->startSection('content'); ?>

  <div class="row">

      <div class="col-lg-12 margin-tb">

          <div class="pull-left">

              <h2>Order Details</h2>

          </div>

          <div class="pull-right">

              <a class="btn btn-primary" href="<?php echo e(route('orders.index2')); ?>"> Back</a>

          </div>

      </div>

  </div>

      <div class="row">



              <div class="col-md-4">

                  <h3>Order Id-<?php echo e(@$orderList->id); ?></h3>

              </div>

              <div class="col-md-4">

                  <h3>Mobile Number-<?php echo e(@$clientData->mobile_no); ?></h3>

              </div>

              <div class="col-md-4">

                  <h3>Seat Number-<?php echo e(@$clientData->seat_no); ?></h3>

              </div>

      </div>

      <table id="example2" class="table table-bordered table-striped" cellspacing="0" width="100%" >

      <tr>

        <th>Order Description</th>  

        <th>Addon Name</th>

        <th>Addon Price (QAR)</th>

        <th>Restaurant Name</th>

        <th>Special Request</th>

        <th>Small (QAR)</th>

        <th>Medium (QAR)</th>

        <th>Large (QAR)</th>

        <th>Quantity</th>

        <th>Net Price (QAR)</th>

        <th>Subtotal (QAR)</th>

      </tr>

      <tr>

          <?php $__empty_1 = true; foreach($orderItem as $orderItems): $__empty_1 = false; ?>

          <td><?php echo e($orderItems->dish_name); ?> </td>

          <td> <?php echo e($orderItems->addon_name); ?> </td>

          <td> <?php echo e($orderItems->addon_price); ?> </td>

          <td> <?php echo e($orderItems->rest_name); ?> </td>

          <td> <?php echo e($orderItems->special_request); ?> </td>

          <td> <?php echo e($orderItems->small); ?> </td>

          <td> <?php echo e($orderItems->medium); ?> </td>

          <td> <?php echo e($orderItems->large); ?> </td>

          <td> <?php echo e($orderItems->quantity); ?> </td>

          <td> <?php echo e($orderItems->unit_price); ?> </td> 

          <td> <?php echo e($orderItems->final_price); ?> </td>

          <td></td>

      </tr>         

                   <?php endforeach; if ($__empty_1): ?>

                  <tr class="odd gradeX">

                    <td colspan=13 class="text-center">No Records Found</td>

                    </tr>  

                  <?php endif; ?>

      </table>

        <div class="row">

          <div class="pull-right">

            <h2>Total- QAR <?php echo e($orderList->total); ?></h2>

           <a href="<?php echo e(route('orders.bill',$orderList->id)); ?>" class="btn btn-primary">Print Bill</a>

          </div>

        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
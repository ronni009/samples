 

<?php $__env->startSection('content'); ?>
        <?php /* messages */ ?>
	<?php if($message = Session::get('success')): ?>
		<div class="alert alert-success">
       <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
			<p><?php echo e($message); ?></p>
		</div>
	<?php endif; ?>
  <?php if($message = Session::get('updated')): ?>
    <div class="alert alert-success">
       <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
      <p><?php echo e($message); ?></p>
    </div>
  <?php endif; ?>
   <?php if($message = Session::get('deleted')): ?>
    <div class="alert alert-success">
       <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
      <p><?php echo e($message); ?></p>
    </div>
  <?php endif; ?>
  <?php /* box begins */ ?>
	 <div class="box">
              <div class="box-header">
                    <h3 class="box-title">List of Restaurants</h3>
                  </div><!-- /.box-header -->
                  <div class="box-footer">
                <a  href="<?php echo e(route('restaurant.create')); ?>" button type = "button" class = "btn btn-primary" >Add Restaurant</button></a>
              </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example2" class="table table-bordered table-striped" cellspacing="0" width="100%" >
               <thead>
               <tr>
			<th>No</th>
			<th>Name</th>
      <th>Address</th>
      <th>Mobile Number</th>
      <th>Email</th>
      <th>Status</th>
      <th>Action</th>
		</tr>   
                </thead>
                <tbody>
                  <?php $__empty_1 = true; foreach($restaurant as $restaurants): $__empty_1 = false; ?>
                  <tr class="odd gradeX">
                        <td><?php echo e($restaurants->id); ?></td> 
                        <td><?php echo e($restaurants->rest_name); ?></td>
                        <td><?php echo e($restaurants->address); ?></td>
                        <td><?php echo e($restaurants->mobile); ?></td>
                        <td><?php echo e($restaurants->email); ?></td>
                        <td><?php echo e($restaurants->status); ?></td>
                  <td>
                     <a class="btn btn-primary" href="<?php echo e(route('restaurant.edit',$restaurants->id)); ?>">Edit</a>
                  </td>
                    </tr>
                  <?php endforeach; if ($__empty_1): ?>
                  <tr class="odd gradeX">
                    <td colspan=13 class="text-center">No Records Found</td>
                    </tr>  
                  <?php endif; ?>
                    
                </tbody>
                <tfoot>
                 <tr>
			<th>No</th>
      <th>Name</th>
      <th>Address</th>
      <th>Mobile Number</th>
      <th>Email</th>
      <th>Status</th>
      <th>Action</th>
		</tr>
                </tfoot>
              </table>
           <?php /*   <?php echo $data->links(); ?>  */ ?>  
            </div>  
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
 
    <script>
     $(document).ready(function() {
    $('#example2').DataTable( {
        "scrollX": true
    } );
} );  
    </script>

   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
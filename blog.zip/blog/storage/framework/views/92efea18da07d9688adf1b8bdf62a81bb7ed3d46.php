<?php $__env->startSection('content'); ?>
    <section class="content">

      <!-- SELECT2 EXAMPLE -->
        <?php if($errors->has()): ?>
        <div class="alert alert-danger alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <h4><i class="icon fa fa-ban"></i> Alert!</h4>
            <?php foreach($errors->all() as $error): ?>
                <?php echo e($error); ?><br>        
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
      <div class="box box-default">
        <div class="box-header with-border">
          <h3 class="box-title">Edit Tax</h3>

          <div class="box-tools pull-right">
            
          </div>
        </div>

	<?php echo Form::open(['route'=>['taxes.update',@$tax_edit->id],'method'=>'POST']); ?>

       <?php echo csrf_field(); ?>

       <?php echo method_field('PUT'); ?>

    <div class="box-body">
          <div class="row">
            <div class="col-md-6">
              <div class="form-group">
               <?php /*  <label for="name">Category Name</label>
                  <input type="text" class="form-control" name="name" id="name" placeholder="Name">
              </div> */ ?>
              <?php echo Form::label('tax_percent','Tax Percent'); ?>

              <?php echo Form::text('tax_percent',@$tax_edit->tax_percent,['class'=>'form-control','id'=>'tax_percent','placeholder'=>'Enter here..','required'=>'required']); ?>

            </div>
              <!-- /.form-group -->
               
              <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
               <div class="form-group">
                <button type="submit" class="btn btn-primary">Submit</button>
                <a class="btn btn-primary" href="<?php echo e(route('taxes.index')); ?>">Close</a>
        </div>

              <!-- /.form-group -->
            </div>
        </div>
    </div>
</div>
</section>

	<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
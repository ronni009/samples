<?php $__env->startSection('content'); ?>
<style type="text/css">
img.zoom {
    width: 60px;
    height: 60px;
    -webkit-transition: all .2s ease-in-out;
    -moz-transition: all .2s ease-in-out;
    -o-transition: all .2s ease-in-out;
    -ms-transition: all .2s ease-in-out;
}
 
.transition {
    -webkit-transform: scale(2.8); 
    -moz-transform: scale(2.8);
    -o-transform: scale(2.8);
    transform: scale(2.8);
}

</style>
    <section class="content">

      <!-- SELECT2 EXAMPLE -->
     
        <?php if($errors->has()): ?>
        <div class="alert alert-danger alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <h4><i class="icon fa fa-ban"></i> Alert!</h4>
            <?php foreach($errors->all() as $error): ?>
                <?php echo e($error); ?><br>        
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
      <div class="box box-default">
        <div class="box-header with-border">
          <h3 class="box-title">
          Edit Banner</h3>

          <div class="box-tools pull-right">
           
          </div>
        </div>

	<?php echo Form::open(['route'=>['banner.update',$image_detail->id],'method'=>'POST','enctype'=>'multipart/form-data','files'=>true]); ?>

       <?php echo csrf_field(); ?>

       <?php echo method_field('PUT'); ?>

    <div class="box-body">
          <div class="row">
            <div class="col-md-6">     <!-- checkbox for dish -->
             <?php /*  <div class="form-group">
              <?php echo Form::label('check1','Dish Banner'); ?>

              <?php echo Form::hidden('check1',0); ?>

              <?php echo Form::checkbox('check1',1,@$image_detail->check1,['id'=>'checkbox1']); ?>

              </div>

              <div class="form-group">       <!-- checkbox for offer -->
                <?php echo Form::label('check2','Offer Banner'); ?>

                <?php echo Form::hidden('check2',0); ?>

                <?php echo Form::checkbox('check2',1,@$image_detail->check2,['id'=>'checkbox2']); ?>

              </div> */ ?>

              <div class="form-group">     <!-- banner image -->
              <?php echo Form::hidden('file',$image_detail->image,['class'=>'form-control']); ?>

              <img class="zoom" src="<?php echo e(URL::to('images',$image_detail->image)); ?>"/><br>
              <?php echo Form::label('image','Select Banner Image'); ?>

              <?php echo Form::file('image',['class'=>'form-control']); ?>

              </div>
              <!-- /.form-group -->
               <div class="form-group">
               <span style="color:grey">(image must be 400px wide by 300px tall.*)</span><br>
               <span style="color:grey">(please choose any one list.*)</span>
              </div>
              <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
               <div class="form-group">
                <button type="submit" class="btn btn-primary">Submit</button>
                <a href="<?php echo e(route('banner.index')); ?>" class="btn btn-primary">Close</a>
        </div>

            </div>         <!-- /.col-md-6 -->

            <div class="col-md-6">
          <div id="autoUpdate">
            <div class="form-group">
              <?php echo Form::label('dish_id','Select Dish'); ?>       <!-- dish select box -->
              <?php echo Form::select('dish_id',@$dish_detail,@$image_detail->dish_id,['class'=>'form-control','placeholder'=>'--None--']); ?>

            </div>
          </div>

          <div id="autoUpdate2">                                <!-- offer select box -->
            <div class="form-group">
              <?php echo Form::label('offer_id','Select Offer'); ?>

              <?php echo Form::select('offer_id',@$offer_detail,@$image_detail->offer_id,['class'=>'form-control','placeholder'=>'--None--']); ?>

            </div>
          </div>
            
            <div class="form-group">
              <?php echo Form::label('status','Select Status'); ?>

              <?php echo Form::select('status',['active'=>'active','inactive'=>'inactive'],$image_detail->status,['class'=>'form-control Select2']); ?>

          </div>

          </div>        <!-- /.col-md-6 -->
        </div>      <!-- /.row -->
    </div>
</div>
</section>

	<?php echo Form::close(); ?>


  
<script type="text/javascript" src="http://code.jquery.com/jquery-1.8.2.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/elevatezoom/3.0.8/jquery.elevatezoom.js" type="text/javascript"></script>
<script>

   $(document).ready(function(){
    $('.zoom').hover(function() {
        $(this).addClass('transition');
    }, function() {
        $(this).removeClass('transition');
    });
});
</script>

 <script>
/*$(document).ready(function(){
    $('#checkbox1').change(function(){
        if(this.checked)
            $('#autoUpdate').fadeIn('slow');
        else
            $('#autoUpdate').fadeOut('slow');

    }).change();
});*/
</script>

  <script>
/*$(document).ready(function(){
    $('#checkbox2').change(function(){
        if(this.checked)
            $('#autoUpdate2').fadeIn('slow');
        else
            $('#autoUpdate2').fadeOut('slow');

    }).change();
});*/
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
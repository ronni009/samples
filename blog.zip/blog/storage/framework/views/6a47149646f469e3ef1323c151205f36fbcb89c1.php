 

<?php $__env->startSection('content'); ?>

<style type="text/css">
img.zoom {
    width: 60px;
    height: 60px;
    -webkit-transition: all .2s ease-in-out;
    -moz-transition: all .2s ease-in-out;
    -o-transition: all .2s ease-in-out;
    -ms-transition: all .2s ease-in-out;
}
 
.transition {
    -webkit-transform: scale(2.8); 
    -moz-transform: scale(2.8);
    -o-transform: scale(2.8);
    transform: scale(2.8);
}

</style>
           <?php /* messages */ ?>
  <?php if($message = Session::get('success')): ?>
    <div class="alert alert-success">
       <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
      <p><?php echo e($message); ?></p>
    </div>
  <?php endif; ?>
  <?php if($message = Session::get('updated')): ?>
    <div class="alert alert-success">
       <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
      <p><?php echo e($message); ?></p>
    </div>
  <?php endif; ?>
   <?php if($message = Session::get('deleted')): ?>
    <div class="alert alert-success">
       <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
      <p><?php echo e($message); ?></p>
    </div>
  <?php endif; ?>
  <?php /* box begins */ ?>
	 <div class="box">
              <div class="box-header">
                    <h3 class="box-title">List of Dishes</h3>
                  </div><!-- /.box-header -->
                  <div class="box-footer">
                <a  href="<?php echo e(route('menu.create')); ?>" button type = "button" class = "btn btn-primary" >Add Dishes</button></a>
              </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example2" class="table table-bordered table-striped" cellspacing="0" width="100%" >
               <thead>
               <tr>
			<th>No</th>
			<th>Name</th>
     <?php /*  <th>Description</th> */ ?>
      <th>Image</th>
      <th>Restaurant Name</th>
      <th>Category</th>
      <th>Foodtype</th>
      <th>Regular Price</th>
      <th>Status</th>
      <th>Action</th>
		</tr>   
                </thead>
                <tbody>
                  <?php $__empty_1 = true; foreach($dish_list as $dish_lists): $__empty_1 = false; ?>
                  <tr class="odd gradeX">
                        <td><?php echo e($dish_lists->id); ?></td> 
                        <td><?php echo e($dish_lists->dish_name); ?></td>
                      <?php /*   <td><?php echo e($dish_lists->description); ?></td> */ ?>
                        <td><img class="zoom" src="<?php echo e(url('images',$dish_lists->image)); ?>"/></td>
                        <td><?php echo e($dish_lists->rest_name); ?></td>
                        <td><?php echo e($dish_lists->category_name); ?></td>
                        <td><?php echo e($dish_lists->foodtype); ?></td>
                        <td><?php echo e($dish_lists->regular); ?></td>
                        <td><?php echo e($dish_lists->status); ?></td>
                        <?php /* show */ ?>
                        <td><a title="View Details" data-toggle="tooltip"  class="badge bg-blue" href="<?php echo e(route('menu.show',$dish_lists->id)); ?>" ><i class="fa fa-eye"></i></a>
                                <?php /* edit */ ?>
                          <a title="Edit" data-toggle="tooltip"  class="badge bg-yellow" href="<?php echo e(route('menu.edit',$dish_lists->id)); ?>"><i class="fa fa-edit"></i></a>
                          <?php /* pop up */ ?>
                          <?php /* <a href="#" class="badge bg-blue my_popup_open"><i class="fa fa-eye"></i></a> */ ?>
                          </td>
                    </tr>
                  <?php endforeach; if ($__empty_1): ?>
                  <tr class="odd gradeX">
                    <td colspan=13 class="text-center">No Records Found</td>
                    </tr>  
                  <?php endif; ?>
                  
                </tbody>
                <tfoot>
                 <tr>
			<th>No</th>
      <th>Name</th>
     <?php /*  <th>Description</th> */ ?>
      <th>Image</th>
      <th>Restaurant Name</th>
      <th>Category</th>
      <th>Foodtype</th>
      <th>Regular Price</th>
      <th>Status</th>
      <th>Action</th>
		</tr>
                </tfoot>
              </table>
              
                    <?php /* end pop up */ ?>
           <?php /*   <?php echo $data->links(); ?>  */ ?>  
            </div>  
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
 

   <!-- <script type="text/javascript">
      $(function () {
   $("#example2").DataTable();
    // $('#example2').DataTable({
    //   "paging": true,
    //   "lengthChange": false,
    //   "searching": false,
    //   "ordering": true,
    //   "info": true,
    //   "autoWidth": false
    "scrollX": true
    // });
  });
    </script>-->
    <script>
     $(document).ready(function() {
    $('#example2').DataTable( {
        "scrollX": true
    } );
} );  
    </script>
    <script type="text/javascript" src="http://code.jquery.com/jquery-1.8.2.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/elevatezoom/3.0.8/jquery.elevatezoom.js" type="text/javascript"></script>
<script>
/*$(function() {
$("#zoomimg").elevateZoom();
});*/

   $(document).ready(function(){
    $('.zoom').hover(function() {
        $(this).addClass('transition');
    }, function() {
        $(this).removeClass('transition');
    });
});
</script>

 <!-- Include jQuery Popup Overlay -->
  <script src="https://cdn.rawgit.com/vast-engineering/jquery-popup-overlay/1.7.13/jquery.popupoverlay.js"></script>

  <script>
    $(document).ready(function() {

      // Initialize the plugin
      $('#my_popup').popup();

    });

  </script>
    <script type="text/javascript">
      jQuery(document).ready(function(){
        jQuery('#btn').click(function(){
        var name=jQuery('#name').val();
        var pass=jQuery('#pass').val();
        data1={name:name,pass:pass};
        jQuery.ajax({
          type:'post',
          url:'action.php',
          datatype:'json',
          data:data1, 
          success:function(data2){
            //console.log(data2);
            if(data2) {
              window.location.href="action.php";
            }
            },
          });

        
        return false;
        });
      });
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <aside class="main-sidebar">

    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">

      <!-- Sidebar user panel (optional) -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="<?php echo e(asset("/bower_components/AdminLTE/dist/img/user2-160x160.jpg")); ?>" class="img-circle" alt="User Image" />
          <span style="color:white ">Welcome! <?php echo e(ucfirst(Auth::user()->name)); ?></span>
        </div>
        </div>
      <!-- Sidebar Menu -->
      <ul class="sidebar-menu">
        
         <li class="treeview">
          <a href="#">
            <i class="fa fa-user"></i>
            <span>Category</span>
            <i class="fa fa-angle-left pull-right"></i>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php /* <?php echo e(route('category.create')); ?> */ ?>"><i class="fa fa-user-plus"></i>Add Categories</a></li>
             <li><a href=""><i class="fa fa-users"></i>List Categories</a></li>
           
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-check"></i>
            <span>Activation</span>
            <i class="fa fa-angle-left pull-right"></i>
          </a>
          <ul class="treeview-menu">
            <li><a href=""><i class="fa fa-check-square-o"></i>Activate</a></li>
             
           
          </ul>
        </li>
       
        <li class="treeview">
          <a href="#">
            <i class="fa fa-database"></i>
            <span>Reports</span>
            <i class="fa fa-angle-left pull-right"></i>
          </a>
          <ul class="treeview-menu">
            <li><a href="pages/charts/chartjs.html"><i class="fa fa-group"></i>User Report</a></li>
             <li><a href="pages/charts/chartjs.html"><i class="fa fa-user"></i>Role Report</a></li>
           
          </ul>
        </li>
      </ul>
      <!-- /.sidebar-menu -->
    </section>
    <!-- /.sidebar -->
</aside>

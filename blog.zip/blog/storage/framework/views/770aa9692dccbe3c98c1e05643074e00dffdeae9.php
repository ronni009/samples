  <aside class="main-sidebar">

    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">

      <!-- Sidebar user panel (optional) -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="<?php echo e(asset("/bower_components/AdminLTE/dist/img/user2-160x160.jpg")); ?>" class="img-circle" alt="User Image" />
         <?php /*  <span style="color:white ">Welcome! <?php echo e(ucfirst(Auth::user()->name)); ?></span>
            <span style="color:white ">(<?php echo e(Auth::user()->roles->first()->name); ?>)</span> */ ?>
        </div>
        <div class="pull-left info">
          <p><?php echo e(ucfirst(Auth::user()->name)); ?>(<?php echo e(Auth::user()->roles->first()->name); ?>)</p>
          <!-- Status -->
          <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
        </div>
        </div>
      <!-- Sidebar Menu -->
      <ul class="sidebar-menu">
         <li><a href="/dashboard"><i class="fa fa-dashboard"></i><span>Dashboard</span></a></li>
         
         <li class="treeview">
          <a href="#">
            <i class="fa fa-database"></i>
            <span>Master</span>
            <i class="fa fa-angle-left pull-right"></i>
          </a>
          
          
          <ul class="treeview-menu">
            
            <li class="treeview">
          <a href="#">
            <i class="fa fa-tags"></i>
            <span>Category</span>
            <i class="fa fa-angle-left pull-right"></i>
          </a>
          
          
          <ul class="treeview-menu">
            
            <li><a href="<?php echo e(route('category.create')); ?>"><i class="fa fa-plus"></i>Add Categories</a></li>
             <li><a href="<?php echo e(route('category.index')); ?>"><i class="fa fa-list"></i>List Categories</a></li>
          </ul>
          </li>
          
          </ul>
          <ul class="treeview-menu">
            
            <li class="treeview">
          <a href="#">
            <i class="fa fa-plus-circle"></i>
            <span>Add On</span>
            <i class="fa fa-angle-left pull-right"></i>
          </a>
          
          
          <ul class="treeview-menu">
             <li><a href="<?php echo e(route('addon.create')); ?>"><i class="fa fa-plus"></i>Add Addon</a></li>
             <li><a href="<?php echo e(route('addon.index')); ?>"><i class="fa fa-list"></i>List Addon</a></li>
          
          </ul>
          </li>
          
          </ul>
          <ul class="treeview-menu">
            
            <li class="treeview">
          <a href="#">
            <i class="fa fa-product-hunt"></i>
            <span>Product AddOn</span>
            <i class="fa fa-angle-left pull-right"></i>
          </a>
          
          
          <ul class="treeview-menu">
             <li><a href="<?php echo e(route('productadd.create')); ?>"><i class="fa fa-plus"></i>Add Product Addon</a></li>
             <li><a href="<?php echo e(route('productadd.index')); ?>"><i class="fa fa-list"></i>List Product Addon</a></li>
          
          </ul>
          </li>
          
          </ul>

           <ul class="treeview-menu">
            
            <li class="treeview">
          <a href="#">
            <i class="fa fa-picture-o"></i>
            <span>Head Banners</span>
            <i class="fa fa-angle-left pull-right"></i>
          </a>
          
          
          <ul class="treeview-menu">
             <?php /* <li><a href="<?php echo e(route('banner.create')); ?>"><i class="fa fa-plus"></i>Add Banner Image</a></li> */ ?>
             <li><a href="<?php echo e(route('banner.index')); ?>"><i class="fa fa-list"></i>List Banner Image</a></li>
          
          </ul>
          </li>
          
          </ul>

          </li>
          
          <li class="treeview">
          <a href="#">
            <i class="fa fa-bars"></i>
            <span>Restaurant</span>
            <i class="fa fa-angle-left pull-right"></i>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo e(route('restaurant.create')); ?>"><i class="fa fa-plus"></i>Add Restaurant</a></li>
             <li><a href="<?php echo e(route('restaurant.index')); ?>"><i class="fa fa-cutlery"></i>List Restaurant</a></li>
          </ul>
        </li>

       <?php /*   <li class="treeview">
          <a href="#">
            <i class="fa fa-percent"></i>
            <span>Taxes</span>
            <i class="fa fa-angle-left pull-right"></i>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo e(route('taxes.create')); ?>"><i class="fa fa-plus"></i>Add Tax</a></li>
            <li><a href="<?php echo e(route('taxes.index')); ?>"><i class="fa fa-list"></i>List Tax</a></li>
          </ul>
        </li>
       */ ?>

        <?php if(Auth::check()): ?>
          <?php if (\Entrust::hasRole('admin')) : ?>
         <li class="treeview">
          <a href="#">
            <i class="fa fa-user"></i>
            <span>User</span>
            <i class="fa fa-angle-left pull-right"></i>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo e(route('users.create')); ?>"><i class="fa fa-user-plus"></i>Add User</a></li>
             <li><a href="<?php echo e(asset('users')); ?>"><i class="fa fa-users"></i>Manage User</a></li>
           
          </ul>
        </li>
        <?php endif; // Entrust::hasRole ?>
      <?php endif; ?>
        
        <?php if(Auth::check()): ?>
          <?php if (\Entrust::hasRole('admin')) : ?>
         <li class="treeview">
          <a href="#">
            <i class="fa fa-users "></i>
            <span>Role</span>
            <i class="fa fa-angle-left pull-right"></i>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo e(route('roles.create')); ?>"><i class="fa fa-user-plus"></i>Add Role</a></li>
             <li><a href="<?php echo e(asset('roles')); ?>"><i class="fa fa-users"></i>Manage Role</a></li>
           
          </ul>
        </li>
          <?php endif; // Entrust::hasRole ?>
        <?php endif; ?>
     
        <li class="treeview">
          <a href="#">
            <i class="fa fa-bars"></i>
            <span>Menu</span>
            <i class="fa fa-angle-left pull-right"></i>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo e(route('menu.create')); ?>"><i class="fa fa-plus"></i>Add Dishes</a></li>
             <li><a href="<?php echo e(route('menu.index')); ?>"><i class="fa fa-cutlery"></i>List Dishes</a></li>
          </ul>
        </li>

        <li class="treeview">
          <a href="#">
            <i class="fa fa-first-order"></i>
            <span>Orders</span>
            <i class="fa fa-angle-left pull-right"></i>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo e(route('orders.index')); ?>"><i class="fa fa-list"></i>List Order</a></li>
          </ul>
        </li>
       
        <li class="treeview">
          <a href="#">
            <i class="fa fa-users"></i>
            <span>Client Details</span>
            <i class="fa fa-angle-left pull-right"></i>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo e(route('clients.index')); ?>"><i class="fa fa-user"></i>List Client</a></li>
          </ul>
        </li>

        <li class="treeview">
          <a href="#">
            <i class="fa fa-book"></i>
            <span>Offer/Combo</span>
            <i class="fa fa-angle-left pull-right"></i>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo e(route('offers.create')); ?>"><i class="fa fa-plus"></i>Add Offers</a></li>
            <li><a href="<?php echo e(route('offers.index')); ?>"><i class="fa fa-list"></i>List Offers</a></li>
          </ul>
        </li>



        <li><a href="<?php echo e(route('reports.index')); ?>"><i class="fa fa-database"></i><span>Reports</span></a></li>

      </ul>
      <!-- /.sidebar-menu -->
    </section>
    <!-- /.sidebar -->
</aside>

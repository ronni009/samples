<!DOCTYPE html>
<html>

  <head>
  
  <?php echo $__env->make('head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 
  </head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">
 <?php echo $__env->make('header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 
    <?php echo $__env->make('sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="content-wrapper">
      <section class="content-header">
      <h1>Dashboard</h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo e(url('dashboard/')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li><p bgcolor="blue">
      </ol>
    </section>
    <section class="content">
      <div class="row">
          <div class="col-lg-3 col-xs-6">
            <div class="small-box bg-maroon">
              <div class="inner">
                <h3>Orders</h3>
                <p>Orders Pending (<i><?php echo e(@count($pendingOrder_count)); ?></i>)</p>
              </div>
              <div class="icon">
                <i class="fa fa-list"></i>
              </div>
              <a href="<?php echo e(route('orders.index')); ?>" class="small-box-footer">view orders pending <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
      
         <div class="col-lg-3 col-xs-6">
            <div class="small-box bg-green">
              <div class="inner">
                <h3>Dishes</h3>
                <p>Total Dishes (<i><?php echo e(@count($dish_count)); ?></i>)</p>
              </div>
              <div class="icon">
                <i class="fa fa-cutlery"></i>
              </div>
              <a href="<?php echo e(route('menu.index')); ?>" class="small-box-footer">view dishes list <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
         
        <div class="col-lg-3 col-xs-6">
            <div class="small-box bg-purple">
              <div class="inner">
                <h3>Restaurant</h3>
                <p>Total Restaurant (<i><?php echo e(@count($restaurant_count)); ?></i>)</p>
              </div>
              <div class="icon">
                <i class="fa fa-building-o"></i>
              </div>
              <a href="<?php echo e(route('restaurant.index')); ?>" class="small-box-footer">view restaurant list <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>

        <?php if(Auth::check()): ?>
          <?php if (\Entrust::hasRole('admin')) : ?>
        <div class="col-lg-3 col-xs-6">
            <div class="small-box bg-teal">
              <div class="inner">
                <h3>Users</h3>
                <p>Total Users (<i><?php echo e(@count($users_count)); ?></i>)</p>
              </div>
              <div class="icon">
                <i class="fa fa-user"></i>
              </div>
              <a href="<?php echo e(route('users.index')); ?>" class="small-box-footer">view users list <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
          <?php endif; // Entrust::hasRole ?>
        <?php endif; ?>
      

      <?php /* month wise orders and total bill inserted here */ ?>
     <div class="col-lg-3 col-xs-6">
            <div class="small-box bg-yellow">
              <div class="inner">
                <h3>Status</h3>
                <p>Total Status (<i><?php echo e(@count($monthstatus)); ?></i>)</p>
              </div>
              <div class="icon">
                <i class="fa fa-check"></i>
              </div>
              <a href="<?php echo e(route('status.index')); ?>" class="small-box-footer">view monthly status <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
    </section>
    </div>
    <!-- /.content -->
  </div>
  

  
</div>
<!-- ./wrapper -->

 <?php echo $__env->make('includes.admin.js', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>
</html>

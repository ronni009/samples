-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 29, 2017 at 09:50 AM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `foodiekartt`
--

-- --------------------------------------------------------

--
-- Table structure for table `addonprices`
--

CREATE TABLE IF NOT EXISTS `addonprices` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `dish_id` int(11) NOT NULL,
  `addon_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `product1` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N/A',
  `product2` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N/A',
  `product3` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N/A',
  `product4` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N/A',
  `product5` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N/A',
  `product6` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N/A',
  `price1` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `price2` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `price3` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `price4` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `price5` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `price6` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `check2` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6 ;

--
-- Dumping data for table `addonprices`
--

INSERT INTO `addonprices` (`id`, `dish_id`, `addon_name`, `product1`, `product2`, `product3`, `product4`, `product5`, `product6`, `price1`, `price2`, `price3`, `price4`, `price5`, `price6`, `check2`, `created_at`, `updated_at`) VALUES
(1, 1, '1', 'cheese', 'paneer', 'mushroom', '', '', '', '10', '20', '30', 'N/A', 'N/A', 'N/A', '1', '2017-04-18 01:57:20', '2017-04-21 06:18:18'),
(2, 2, '2', 'soya', 'cheese', '', '', '', '', '20', '30', 'N/A', 'N/A', 'N/A', 'N/A', '1', '2017-04-18 05:14:52', '2017-05-16 03:52:43'),
(3, 3, '', '', '', '', '', '', '', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', '0', '2017-04-18 05:16:38', '2017-04-21 00:42:41'),
(4, 4, '', '', '', '', '', '', '', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', '0', '2017-04-18 05:19:41', '2017-05-03 04:09:42'),
(5, 5, '', '', '', '', '', '', '', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', '0', '2017-05-11 08:34:36', '2017-05-15 04:40:41');

-- --------------------------------------------------------

--
-- Table structure for table `addons`
--

CREATE TABLE IF NOT EXISTS `addons` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `addon_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `addons`
--

INSERT INTO `addons` (`id`, `addon_name`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Toppings', 'active', '2017-04-04 08:25:31', '2017-04-04 08:47:34'),
(2, 'Sauce', 'inactive', '2017-04-04 08:26:12', '2017-04-04 08:49:27'),
(3, 'Dips ', 'active', '2017-04-04 08:26:30', '2017-04-04 08:48:38'),
(4, 'Desert', 'active', '2017-04-04 08:48:15', '2017-04-04 08:48:15');

-- --------------------------------------------------------

--
-- Table structure for table `app_users`
--

CREATE TABLE IF NOT EXISTS `app_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `app_users`
--

INSERT INTO `app_users` (`id`, `username`, `password`, `created_at`, `updated_at`) VALUES
(1, 'admin', '$2y$10$YSn5wq2uLPUfeYXZ6VPwT.rETsXxwTVvmZwjtSQHqo6pWt0aKGaZm', '2017-04-19 02:38:51', '2017-04-21 01:10:54');

-- --------------------------------------------------------

--
-- Table structure for table `bannerimages`
--

CREATE TABLE IF NOT EXISTS `bannerimages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `dish_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `offer_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `bannerimages`
--

INSERT INTO `bannerimages` (`id`, `image`, `dish_id`, `offer_id`, `status`, `created_at`, `updated_at`) VALUES
(1, 'burger.jpg', '3', '0', 'active', '2017-05-05 02:40:43', '2017-05-05 04:14:51'),
(2, 'cokefloat.jpg', '0', '1', 'active', '2017-05-05 02:41:01', '2017-05-05 04:15:44'),
(3, 'pizza.jpg', '1', '0', 'active', '2017-05-05 02:41:18', '2017-05-05 04:16:03');

-- --------------------------------------------------------

--
-- Table structure for table `cartitems`
--

CREATE TABLE IF NOT EXISTS `cartitems` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cart_id` int(11) NOT NULL,
  `dish_id` int(11) NOT NULL,
  `offer_id` int(11) NOT NULL,
  `restaurant_id` int(11) NOT NULL,
  `dish_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `offer_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `addon_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `addon_price` decimal(10,2) NOT NULL,
  `small` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `medium` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `large` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `special_request` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unit_price` decimal(10,2) NOT NULL,
  `quantity` int(11) NOT NULL,
  `final_price` decimal(10,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=12 ;

--
-- Dumping data for table `cartitems`
--

INSERT INTO `cartitems` (`id`, `cart_id`, `dish_id`, `offer_id`, `restaurant_id`, `dish_name`, `offer_name`, `image`, `addon_name`, `addon_price`, `small`, `medium`, `large`, `special_request`, `unit_price`, `quantity`, `final_price`, `created_at`, `updated_at`) VALUES
(3, 1, 1, 0, 0, 'pizza', 'N/A', 'N/A', 'mushroom', '60.00', '50', 'N/A', 'N/A', 'N/A', '50.00', 2, '160.00', '2017-05-13 05:58:20', '2017-05-13 05:58:20'),
(4, 1, 1, 0, 0, 'pizza', 'N/A', 'N/A', 'mushroom', '60.00', '50', 'N/A', 'N/A', 'N/A', '50.00', 2, '160.00', '2017-05-13 05:58:22', '2017-05-13 05:58:22'),
(5, 1, 1, 0, 0, 'pizza', 'N/A', 'N/A', 'mushroom', '60.00', '50', 'N/A', 'N/A', 'N/A', '50.00', 2, '160.00', '2017-05-15 01:16:36', '2017-05-15 01:16:36'),
(6, 1, 1, 0, 0, 'pizza', 'N/A', 'N/A', 'mushroom', '60.00', '50', 'N/A', 'N/A', 'N/A', '50.00', 2, '160.00', '2017-05-15 01:16:38', '2017-05-15 01:16:38'),
(7, 1, 1, 0, 0, 'pizza', 'N/A', 'N/A', 'mushroom', '60.00', '50', 'N/A', 'N/A', 'N/A', '50.00', 2, '160.00', '2017-05-15 04:50:32', '2017-05-15 04:50:32'),
(8, 1, 1, 0, 0, 'pizza', 'N/A', 'N/A', 'mushroom', '60.00', '50', 'N/A', 'N/A', 'N/A', '50.00', 2, '160.00', '2017-05-15 04:50:34', '2017-05-15 05:24:48'),
(9, 1, 1, 0, 0, 'pizza', 'N/A', 'N/A', 'mushroom', '60.00', '50', 'N/A', 'N/A', 'N/A', '50.00', 2, '160.00', '2017-05-16 01:15:18', '2017-05-16 01:15:18'),
(10, 1, 1, 0, 0, 'pizza', 'N/A', 'N/A', 'mushroom', '60.00', '50', 'N/A', 'N/A', 'N/A', '50.00', 2, '160.00', '2017-05-16 01:15:20', '2017-05-16 01:15:20'),
(11, 1, 1, 0, 0, 'pizza', 'N/A', 'N/A', 'mushroom', '60.00', '50', 'N/A', 'N/A', 'N/A', '50.00', 2, '160.00', '2017-05-16 05:15:35', '2017-05-16 05:15:35');

-- --------------------------------------------------------

--
-- Table structure for table `carts`
--

CREATE TABLE IF NOT EXISTS `carts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `sub_total` decimal(10,2) NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `carts`
--

INSERT INTO `carts` (`id`, `user_id`, `sub_total`, `total`, `created_at`, `updated_at`) VALUES
(1, 1, '1440.00', '1440.00', '2017-05-04 02:25:14', '2017-05-16 05:15:35');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `category_name`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Snacks', 'active', '2017-04-04 02:27:04', '2017-04-06 07:59:21'),
(2, 'Main Course', 'active', '2017-04-04 03:59:06', '2017-04-26 04:33:01');

-- --------------------------------------------------------

--
-- Table structure for table `clientlists`
--

CREATE TABLE IF NOT EXISTS `clientlists` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `client_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `seat_no` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `mobile_no` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `payment_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `clientlists`
--

INSERT INTO `clientlists` (`id`, `client_name`, `seat_no`, `mobile_no`, `payment_type`, `created_at`, `updated_at`) VALUES
(1, 'rohan', '007', '9920488609', '', '2017-04-27 07:06:36', '2017-04-27 07:06:36'),
(2, 'rohan', '007', '9920488609', '', '2017-04-29 06:08:34', '2017-04-29 06:08:34');

-- --------------------------------------------------------

--
-- Table structure for table `device_details`
--

CREATE TABLE IF NOT EXISTS `device_details` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(50) NOT NULL,
  `device_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `gcm_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `device_details`
--

INSERT INTO `device_details` (`id`, `user_id`, `device_id`, `gcm_id`, `created_at`, `updated_at`) VALUES
(1, 1, '1234', '1234', NULL, '2017-05-17 06:54:13');

-- --------------------------------------------------------

--
-- Table structure for table `dishes`
--

CREATE TABLE IF NOT EXISTS `dishes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `dish_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `rest_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `cat_id` int(11) NOT NULL,
  `foodtype` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6 ;

--
-- Dumping data for table `dishes`
--

INSERT INTO `dishes` (`id`, `dish_name`, `description`, `image`, `rest_id`, `cat_id`, `foodtype`, `status`, `created_at`, `updated_at`) VALUES
(1, 'pizza', 'tasty healthy delicious!!', 'pizza.jpg', '1', 1, 'veg', 'active', '2017-04-18 01:57:20', '2017-04-21 06:18:18'),
(2, 'french fries', 'tasty healthy delicious!!', 'frenchfries.jpg', '2', 1, 'veg', 'active', '2017-04-18 05:14:52', '2017-05-16 03:52:43'),
(3, 'burger', 'tasty healthy delicious!!', 'burger.jpg', '2', 1, 'non-veg', 'active', '2017-04-18 05:16:38', '2017-04-21 00:42:41'),
(4, 'coke float', 'tasty healthy delicious!!', 'cokefloat.jpg', '2', 1, 'veg', 'active', '2017-04-18 05:19:41', '2017-05-03 04:09:42'),
(5, 'popcorn-salted', 'adsf', 'burger.jpg', '2', 1, 'veg', 'active', '2017-05-11 08:34:36', '2017-05-15 04:40:40');

-- --------------------------------------------------------

--
-- Table structure for table `dishprice`
--

CREATE TABLE IF NOT EXISTS `dishprice` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `dish_id` int(11) NOT NULL,
  `small` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `medium` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `large` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `regular` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N/A',
  `check1` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6 ;

--
-- Dumping data for table `dishprice`
--

INSERT INTO `dishprice` (`id`, `dish_id`, `small`, `medium`, `large`, `regular`, `check1`, `created_at`, `updated_at`) VALUES
(1, 1, '50', '60', '70', 'N/A', '1', '2017-04-18 01:57:20', '2017-04-21 06:18:18'),
(2, 2, '50', '60', '70', 'N/A', '1', '2017-04-18 05:14:52', '2017-05-16 03:52:43'),
(3, 3, 'N/A', 'N/A', 'N/A', '55', '0', '2017-04-18 05:16:38', '2017-04-21 00:42:41'),
(4, 4, '50', '60', '70', 'N/A', '1', '2017-04-18 05:19:41', '2017-05-03 04:09:42'),
(5, 5, '50', '80', '100', 'N/A', '1', '2017-05-11 08:34:36', '2017-05-15 04:40:41');

-- --------------------------------------------------------

--
-- Table structure for table `karts`
--

CREATE TABLE IF NOT EXISTS `karts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `dish_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `order_description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `addon_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `special_request` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `net_price` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `quantity` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sub_total` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `total` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE IF NOT EXISTS `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`migration`, `batch`) VALUES
('2014_10_12_000000_create_users_table', 1),
('2014_10_12_100000_create_password_resets_table', 1),
('2017_04_04_055027_create_categories_table', 2),
('2017_04_04_134731_create_addons_table', 3),
('2017_04_05_065325_create_productaddons_table', 4),
('2017_04_05_103936_create_dishes_table', 5),
('2017_04_05_105252_pricedish', 6),
('2017_04_05_111221_create_addonprices_table', 7),
('2017_04_11_101055_create_bannerimages_table', 8),
('2017_04_12_055817_create_orderlists_table', 9),
('2017_04_12_055851_create_clientlists_table', 9),
('2017_04_12_095015_create_offers_table', 10),
('2017_04_17_070647_create_restaurants_table', 11),
('2017_04_19_073225_create_app_users_table', 12),
('2017_04_19_093747_create_karts_table', 13),
('2017_04_20_055527_create_taxes_table', 14),
('2017_04_22_044403_entrust_setup_tables', 15),
('2017_04_22_104739_create_carts_table', 16),
('2017_04_22_104750_create_cartitems_table', 17),
('2017_04_24_115005_create_order_lists_table', 18),
('2017_04_24_115034_create_order_items_table', 18),
('2017_04_26_115710_create_device_details_table', 19);

-- --------------------------------------------------------

--
-- Table structure for table `offers`
--

CREATE TABLE IF NOT EXISTS `offers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `offer_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `dish1` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `rest_name1` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `type1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dish2` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `rest_name2` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `type2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dish3` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `rest_name3` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `type3` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `price` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `offers`
--

INSERT INTO `offers` (`id`, `offer_name`, `description`, `dish1`, `rest_name1`, `type1`, `dish2`, `rest_name2`, `type2`, `dish3`, `rest_name3`, `type3`, `price`, `image`, `status`, `created_at`, `updated_at`) VALUES
(1, 'pizza combo', 'combo offers', 'pizza', 'pizza hut', 'small', 'french fries', 'mc donalds', 'medium', 'burger', 'mc donalds', 'standard', '200', 'frenchfries.jpg', 'active', '2017-04-18 01:34:53', '2017-04-21 06:12:55');

-- --------------------------------------------------------

--
-- Table structure for table `orderlists`
--

CREATE TABLE IF NOT EXISTS `orderlists` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `client_id` int(11) NOT NULL,
  `sub_total` decimal(10,2) NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `default_value` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `orderlists`
--

INSERT INTO `orderlists` (`id`, `client_id`, `sub_total`, `total`, `default_value`, `created_at`, `updated_at`) VALUES
(1, 1, '480.00', '480.00', 'Order Delivered', '2017-05-04 07:53:42', '2017-05-15 00:20:18');

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE IF NOT EXISTS `order_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `dish_id` int(11) NOT NULL,
  `offer_id` int(11) NOT NULL,
  `restaurant_id` int(11) NOT NULL,
  `dish_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `offer_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `small` decimal(10,2) NOT NULL,
  `medium` decimal(10,2) NOT NULL,
  `large` decimal(10,2) NOT NULL,
  `addon_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `addon_price` decimal(10,2) NOT NULL,
  `special_request` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `unit_price` decimal(10,2) NOT NULL,
  `quantity` int(11) NOT NULL,
  `final_price` decimal(10,2) NOT NULL,
  `default_value` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`id`, `order_id`, `dish_id`, `offer_id`, `restaurant_id`, `dish_name`, `offer_name`, `image`, `small`, `medium`, `large`, `addon_name`, `addon_price`, `special_request`, `unit_price`, `quantity`, `final_price`, `default_value`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 0, 0, 'pizza', 'N/A', 'N/A', '50.00', '0.00', '0.00', 'N/A', '60.00', 'more cheese', '50.00', 2, '160.00', 'N/A', '2017-05-04 07:53:42', '2017-05-04 07:53:42'),
(2, 1, 1, 0, 0, 'pizza', 'N/A', 'N/A', '50.00', '0.00', '0.00', 'mushroom', '60.00', 'N/A', '50.00', 2, '160.00', 'N/A', '2017-05-04 07:53:42', '2017-05-04 07:53:42'),
(3, 1, 1, 0, 0, 'pizza', 'N/A', 'N/A', '50.00', '0.00', '0.00', 'mushroom', '60.00', 'chutney', '50.00', 2, '160.00', 'N/A', '2017-05-04 07:53:42', '2017-05-04 07:53:42');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY `password_resets_email_index` (`email`),
  KEY `password_resets_token_index` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE IF NOT EXISTS `permissions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `display_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_unique` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=9 ;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `name`, `display_name`, `description`, `created_at`, `updated_at`) VALUES
(1, 'role-list', 'Display Role Listing', 'See only Listing Of Role', '2017-04-21 23:36:05', '2017-04-21 23:36:05'),
(2, 'role-create', 'Create Role', 'Create New Role', '2017-04-21 23:36:05', '2017-04-21 23:36:05'),
(3, 'role-edit', 'Edit Role', 'Edit Role', '2017-04-21 23:36:05', '2017-04-21 23:36:05'),
(4, 'role-delete', 'Delete Role', 'Delete Role', '2017-04-21 23:36:06', '2017-04-21 23:36:06'),
(5, 'item-list', 'Display Item Listing', 'See only Listing Of Item', '2017-04-21 23:36:06', '2017-04-21 23:36:06'),
(6, 'item-create', 'Create Item', 'Create New Item', '2017-04-21 23:36:06', '2017-04-21 23:36:06'),
(7, 'item-edit', 'Edit Item', 'Edit Item', '2017-04-21 23:36:06', '2017-04-21 23:36:06'),
(8, 'item-delete', 'Delete Item', 'Delete Item', '2017-04-21 23:36:06', '2017-04-21 23:36:06');

-- --------------------------------------------------------

--
-- Table structure for table `permission_role`
--

CREATE TABLE IF NOT EXISTS `permission_role` (
  `permission_id` int(10) unsigned NOT NULL,
  `role_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `permission_role_role_id_foreign` (`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `permission_role`
--

INSERT INTO `permission_role` (`permission_id`, `role_id`) VALUES
(1, 1),
(2, 1),
(3, 1),
(5, 1),
(6, 1),
(7, 1),
(8, 1),
(5, 2);

-- --------------------------------------------------------

--
-- Table structure for table `productaddons`
--

CREATE TABLE IF NOT EXISTS `productaddons` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `addon_id` int(11) NOT NULL,
  `product_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=9 ;

--
-- Dumping data for table `productaddons`
--

INSERT INTO `productaddons` (`id`, `addon_id`, `product_name`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, 'cheese', 'active', '2017-04-05 01:44:16', '2017-04-05 02:09:23'),
(2, 1, 'paneer', 'active', '2017-04-05 02:09:46', '2017-04-05 02:09:46'),
(3, 1, 'mushroom', 'active', '2017-04-05 02:10:27', '2017-04-05 02:10:27'),
(4, 3, 'mayoneese', 'active', '2017-04-05 02:10:45', '2017-04-05 02:11:56'),
(5, 3, 'perry perry', 'active', '2017-04-05 02:11:03', '2017-04-05 02:12:09'),
(6, 2, 'tomato', 'active', '2017-04-05 02:11:25', '2017-04-05 02:11:25'),
(7, 2, 'vinegar', 'active', '2017-04-05 02:13:08', '2017-04-05 02:13:08'),
(8, 2, 'soya', 'active', '2017-04-05 02:13:20', '2017-04-05 02:34:33');

-- --------------------------------------------------------

--
-- Table structure for table `restaurants`
--

CREATE TABLE IF NOT EXISTS `restaurants` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rest_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `mobile` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `restaurants_rest_name_unique` (`rest_name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `restaurants`
--

INSERT INTO `restaurants` (`id`, `rest_name`, `address`, `mobile`, `email`, `status`, `created_at`, `updated_at`) VALUES
(1, 'pizza hut', 'phoenix  market city,\r\nkurla west.', '3320422603', 'rohan@promediacamp.in', 'active', '2017-04-17 01:53:01', '2017-04-19 04:28:04'),
(2, 'mc donalds', 'phoenix  market city,kurla west.', '3320422444', 'rohan@promediacamp.in', 'active', '2017-04-17 02:52:34', '2017-04-17 02:52:34');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE IF NOT EXISTS `roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `display_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_unique` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `display_name`, `description`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'admin', 'Can perform CRUD', '2017-04-21 23:38:11', '2017-04-21 23:38:11'),
(2, 'executive', 'executive', 'Cannot create Users', '2017-04-27 00:30:26', '2017-04-27 00:37:26');

-- --------------------------------------------------------

--
-- Table structure for table `role_user`
--

CREATE TABLE IF NOT EXISTS `role_user` (
  `user_id` int(10) unsigned NOT NULL,
  `role_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`user_id`,`role_id`),
  KEY `role_user_role_id_foreign` (`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `role_user`
--

INSERT INTO `role_user` (`user_id`, `role_id`) VALUES
(1, 1),
(2, 2);

-- --------------------------------------------------------

--
-- Table structure for table `status`
--

CREATE TABLE IF NOT EXISTS `status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `month_code` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `status`
--

INSERT INTO `status` (`id`, `name`, `month_code`) VALUES
(1, 'January', '01'),
(2, 'February', '02'),
(3, 'March', '03'),
(4, 'April', '04'),
(5, 'May', '05'),
(6, 'June', '06'),
(7, 'July', '07'),
(8, 'August', '08'),
(9, 'September', '09'),
(10, 'October', '10'),
(11, 'November', '11'),
(12, 'December', '12');

-- --------------------------------------------------------

--
-- Table structure for table `taxes`
--

CREATE TABLE IF NOT EXISTS `taxes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tax_percent` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `taxes`
--

INSERT INTO `taxes` (`id`, `tax_percent`, `created_at`, `updated_at`) VALUES
(1, '20.2', '2017-04-20 01:02:37', '2017-04-20 01:02:37'),
(2, '19.5', '2017-04-20 01:09:44', '2017-04-20 01:09:44'),
(3, '55.12', '2017-04-20 01:10:03', '2017-04-20 01:23:36');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `status`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'rohan', 'rohan@promediacamp.in', '$2y$10$EDDG8MAbX3D/nYPnSgytMuQDXraGuL/yn.olx7xaIykVHiGvLzaP.', 'inactive', 'RyWvQ26iMvz4bzSXkCeBsUyMCQrCYrAgXJ3CfEFVPC1oysLi78koB3q3CMwr', '2017-04-03 10:50:45', '2017-05-17 06:45:45'),
(2, 'Executive', 'executive@promediacamp.in', '$2y$10$0PtjCqwMLWp.ca0ql03q7eNBwzWe1JB5oq.8UuC0mqJlearzxmEOC', 'active', 'ATtQrZ2Tnhp0aJrHyM4dpOpamGSb9gYUxggg0URM4lMuFBsftyCVaIEsWKTG', '2017-04-27 00:42:35', '2017-05-16 06:25:56');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `permission_role`
--
ALTER TABLE `permission_role`
  ADD CONSTRAINT `permission_role_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `permission_role_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `role_user`
--
ALTER TABLE `role_user`
  ADD CONSTRAINT `role_user_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `role_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<!DOCTYPE html>
<html>

  <head>
  
  <?php echo $__env->make('head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 
  </head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">
 <?php echo $__env->make('header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 
    <?php echo $__env->make('sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 
    <div class="content-wrapper">

    <section class="content">

      <!-- Your Page Content Here -->
       <?php echo $__env->yieldContent('content'); ?>

    </section>
    <!-- /.content -->
  </div>
  

  
</div>
<!-- ./wrapper -->

 <?php echo $__env->make('includes.admin.js', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- REQUIRED JS SCRIPTS -->

<!-- jQuery 2.2.0 -->
<!-- <script src="<?php echo e(asset ("/bower_components/AdminLTE/plugins/jQuery/jQuery-2.2.0.min.js")); ?>"></script>
<!-- Bootstrap 3.3.6 -->
<!--<script src="<?php echo e(asset ("/bower_components/AdminLTE/bootstrap/js/bootstrap.min.js")); ?>" type="text/javascript">
  </script>
<!-- AdminLTE App -->
<!-- <script src="<?php echo e(asset ("/bower_components/AdminLTE/dist/js/app.min.js")); ?>" type="text/javascript"></script>

-->
</body>
</html>

<?php

namespace App;
use App\User;
use App\Permission;
use Zizaco\Entrust\EntrustRole;

class Role extends EntrustRole
{
   				public function user()
   			 	{
        			return $this->belongsToMany('App\User');
        			//return $this->belongsToMany('User', 'role_user');
    			} 

 		       public function permission()
    			 {
        			return $this->belongsToMany('App\Permission');
   				 } 
}
<footer class="main-footer non-print">
         
        <strong>Copyright &copy; 2016 <a href="#" target="_blank">Education</a>.</strong> All rights reserved.
      </footer>
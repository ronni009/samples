<?php

$server = "localhost"; $username = "root"; $password = "";

$con = mysql_connect($server, $username, $password);

$db = mysql_select_db( "cmp_mgmt_sys", $con);


$query = mysql_query("SELECT * FROM cmp_complaint_transaction") or die(mysql_error());

while ($row = mysql_fetch_array($query)) {
    
    foreach ($row as $key => $value) {
        
        echo $key ."=>". $value ."<br/>";
    }
    
    echo "<br/><br/>++++++++++++++++++++++++++++<br/><br/>";
}


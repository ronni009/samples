$(document).ready(function () {

    //this will trigger to load the chapter in subject load
    //$('#bronze, #silver').hide();
    $("#inputPackage").change(function(){
        var subjectId = $("#inputPackage").val();
        if(subjectId == 'B'){
            $('#bronze').show();
            $('#silver').hide();
            $('#gold').hide();
        }else if(subjectId == 'S'){
            $('#bronze').show();
            $('#silver').show();
            $('#gold').hide();
        }else if(subjectId == 'G'){
            $('#bronze').show();
            $('#silver').show();
            $('#gold').show();
        }else{
           $('#bronze, #silver').hide(); 
        }

    });
});

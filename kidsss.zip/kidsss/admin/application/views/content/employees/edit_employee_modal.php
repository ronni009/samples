<div class="modal-header">
    <button type="button" class="close" data-dismiss="modal"><span class="glyphicon glyphicon-remove-sign"></span></button>
    <h4 class="modal-title text-primary"><b>Edit User Details</b></h4>
</div>
<div class="modal-body bg-primary">

    <?php echo form_open_multipart('submit-edit-user','class="form-horizontal" id="editEmployeeform"'); ?>
    <!-- <form method="post" action="submit-edit-user" enctype="multipart/form-data" class="form-horizontal" id="editEmployeeform" > -->

    <div class="scrollable-body">

        <div class="form-group">
            <label for="inputContact" class="col-sm-4 control-label center">Profile Pic</label>
            <div class="col-sm-5">
                  <img class="img-responsive img-thumbnail" src="<?php echo base_url().'assets/images/profile_pic/'.$userDetail['profilPic']; ?>" alt="Profile Picture">
            </div>
        </div>
        <div class="form-group">
            <label for="inputFirstName" class="col-sm-4 control-label">First Name</label>
            <div class="col-sm-6">
                <input type="text" class="form-control" id="inputFirstName" name="inputFirstName" value="<?php echo $userDetail['fName']; ?>">
            </div>
        </div>
        <div class="form-group">
            <label for="inputLastName" class="col-sm-4 control-label">Last Name</label>
            <div class="col-sm-6">
                <input type="text" class="form-control" id="inputLastName" name="inputLastName" value="<?php echo $userDetail['lName']; ?>">
            </div>
        </div>
        <div class="form-group">
            <label for="inputEmail" class="col-sm-4 control-label">Email</label>
            <div class="col-sm-6">
                <input type="text" class="form-control" disabled id="inputEmail" name="inputEmail" value="<?php echo $userDetail['emailID']; ?>">
            </div>
        </div>
        <div class="form-group">
            <label for="inputContact" class="col-sm-4 control-label">Contact</label>
            <div class="col-sm-6">
                <input type="text" class="form-control" id="inputContact" name="inputContact" value="<?php echo $userDetail['contactNumber']; ?>">
            </div>
        </div>
        <div class="form-group">
            <label for="inputParentName" class="col-sm-4 control-label">Parent's Name</label>
            <div class="col-sm-6">
                <input type="text" class="form-control" id="inputParentName" name="inputParentName" value="<?php echo $userDetail['parentName']; ?>">
            </div>
        </div>
        <div class="form-group">
            <label for="inputProfilePic" class="col-sm-4 control-label">Upload Profile Pic</label>
            <div class="col-sm-6">
                <input type="file" name="inputProfilePic" id="inputProfilePic" accept="image/*">
            </div>
        </div>
        <div class="form-group">
            <label for="inputAddress" class="col-sm-4 control-label">Address</label>
            <div class="col-sm-6">
                <textarea id="inputAddress" name="inputAddress" class="form-control" rows="3"><?php echo $userDetail['residenceAdd']; ?></textarea>
            </div>
        </div>
        <div class="form-group">
            <label for="inputDesc" class="col-sm-4 control-label">Additional Info</label>
            <div class="col-sm-6">
                <textarea id="inputDesc" name="inputDesc" class="form-control" rows="3"><?php echo $userDetail['additionalInfo']; ?></textarea>
            </div>
        </div>

        <div class="form-group">
            <label for="inputRole" class="col-sm-4 control-label">Select Role</label>
            <div class="col-sm-6">
                <select class="form-control" id="inputRole" name="inputRole">
                    <option value="">----Select----</option>
                    <?php foreach( $roleArr as $rValues ): ?>
                        <option value="<?php echo $rValues['roleID']; ?>" <?php if($rValues['roleID'] == $userDetail['roleID']){ echo "SELECTED"; } ?>><?php echo $rValues['roleName']; ?></option>
                    <?php endforeach; ?>
                </select>                
            </div>
        </div>
        <div class="form-group">
            <label for="inputRolestatus" class="col-sm-4 control-label">Status</label>
            <div class="col-sm-6">
                <select name="inputUserStatus" id="inputUserStatus" class="form-control">
                    <option value="Y" <?php if($userDetail["status"] == "Y"){ echo "SELECTED"; }?>>Active</option>
                    <option value="N" <?php if($userDetail["status"] == "N"){ echo "SELECTED"; }?>>Inactive</option>
                </select>
            </div>
        </div>

    </div>
        
    <div class="form-group">
        <div class="col-sm-offset-4 col-sm-8">
            <button type="submit" class="btn btn-default">Submit</button>&nbsp;
            <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
            <input type="hidden" name="EID" value="<?php echo $userDetail['userID']; ?>" />
            <input type="hidden" name="profile_pic" value="<?php echo $userDetail['profilPic']; ?>" />
        </div>
    </div>

    </form>
</div>

<div class="modal-footer"><p class="text-danger">*All fields are mandatory.</p></div>

<div class="modal-header">
    <button type="button" class="close" data-dismiss="modal"><span class="glyphicon glyphicon-remove-sign"></span></button>
    <h4 class="modal-title text-primary"><b>Add New User</b></h4>
</div>
<div class="modal-body bg-primary">

    <?php echo form_open_multipart('submit-add-user','class="form-horizontal" id="addEmployeeform"'); ?>
        
    <div class="scrollable-body">

        <div class="form-group">
            <label for="inputFirstName" class="col-sm-4 control-label">First Name</label>
            <div class="col-sm-6">
                <input type="text" class="form-control" id="inputFirstName" name="inputFirstName">
            </div>
        </div>
        <div class="form-group">
            <label for="inputLastName" class="col-sm-4 control-label">Last Name</label>
            <div class="col-sm-6">
                <input type="text" class="form-control" id="inputLastName" name="inputLastName">
            </div>
        </div>
        <div class="form-group">
            <label for="inputEmail" class="col-sm-4 control-label">Email</label>
            <div class="col-sm-6">
                <input type="text" class="form-control" id="inputEmail" name="inputEmail">
            </div>
        </div>
        <div class="form-group">
            <label for="inputContact" class="col-sm-4 control-label">Contact</label>
            <div class="col-sm-6">
                <input type="text" class="form-control" id="inputContact" name="inputContact">
            </div>
        </div>
        <div class="form-group">
            <label for="inputParentName" class="col-sm-4 control-label">Parent's Name</label>
            <div class="col-sm-6">
                <input type="text" class="form-control" id="inputParentName" name="inputParentName">
            </div>
        </div>
        <div class="form-group">
            <label for="inputProfilePic" class="col-sm-4 control-label">Upload Profile Pic</label>
            <div class="col-sm-6">
                <input type="file" name="inputProfilePic" id="inputProfilePic" accept="image/*">
            </div>
        </div>
        <div class="form-group">
            <label for="inputAddress" class="col-sm-4 control-label">Address</label>
            <div class="col-sm-6">
                <textarea id="inputAddress" name="inputAddress" class="form-control" rows="3"></textarea>
            </div>
        </div>
        <div class="form-group">
            <label for="inputDesc" class="col-sm-4 control-label">Additional Info</label>
            <div class="col-sm-6">
                <textarea id="inputDesc" name="inputDesc" class="form-control" rows="3"></textarea>
            </div>
        </div>

        <div class="form-group">
            <label for="inputRole" class="col-sm-4 control-label">Select Role</label>
            <div class="col-sm-6">
                <select class="form-control" id="inputRole" name="inputRole">
                    <option value="">----Select----</option>
                    <?php foreach( $roleArr as $rValues ): ?>
                        <option value="<?php echo $rValues['roleID']; ?>"><?php echo $rValues['roleName']; ?></option>
                    <?php endforeach; ?>
                </select>                
            </div>
        </div>   
        <div class="form-group">
            <label for="inputPassword" class="col-sm-4 control-label">Password</label>
            <div class="col-sm-6">
                <input type="password" class="form-control" id="inputPassword" name="inputPassword" value="">
            </div>
        </div>
        <div class="form-group">
            <label for="inputConfirmPassword" class="col-sm-4 control-label">Confirm Password</label>
            <div class="col-sm-6">
                <input type="password" class="form-control" id="inputConfirmPassword" name="inputConfirmPassword" value="">
            </div>
        </div>             
        
    </div>
    
    <div class="form-group">
        <div class="col-sm-offset-4 col-sm-8">
            <button type="submit" class="btn btn-default">Submit</button>&nbsp;
            <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
        </div>
    </div>
    </form>
</div>

<div class="modal-footer"><p class="text-danger">*All fields are mandatory.</p></div>

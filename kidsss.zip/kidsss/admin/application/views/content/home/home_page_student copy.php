<script type="text/javascript" src="<?php echo base_url("assets/js/highcharts.js"); ?>"></script>
<script type="text/javascript" src="<?php echo base_url("assets/js/exporting.js"); ?>"></script>
<script type="text/javascript" src="<?php echo base_url("assets/js/highchart_data.js"); ?>"></script>

<div class="row">

    <div class="col-md-12">

        <div class="panel panel-default">
            <div class="panel-heading text-left">Welcome, <b><?php echo $this->sData['user_first_name'] ." ".$this->sData['user_last_name'] ; ?></b>
            </div>
            <div class="panel-body">
                <div class="row">
                    <div class="col-md-12">
                        <div class="panel panel-default">

                            <div class="panel-body">
                                <div class="col-sm-4">
                                  <h3>13</h3>
                                  <p>Web Users</p>
                              </div>
                              <div class="col-sm-4">
                                  <h3>2</h3>
                                  <p>Paid Users</p>
                              </div>
                              <div class="col-sm-4">
                                  <h3>2</h3> 
                                  <p>Executive count</p>
                              </div>
                          </div>

                      </div>
                  </div>
              </div>
          </div>

            <div class="panel-body">
                <div class="row">
                    <div class="col-md-12">
                        <div class="panel panel-default">
                            <div class="panel-heading text-left">
                                <b>Subject wise - Level status</b>
                            </div>
                            <div class="panel-body">
                                <div id="level_status"></div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
            <!--Tab Content-->

        </div>
    </div>
</div>

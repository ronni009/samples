<?php if ( ! defined('BASEPATH')){ exit('No direct script access allowed'); }
/**
 * 
 * @author  Krishna Gupta
 * @date    19.03.2017
 * 
**/

class Api_model extends CI_Model{
    
    function __construct() { parent::__construct(); }
        
    function getBkzTopper(){
        $sql = "SELECT (count(questionID) * orderBy) AS Marks,a.userID, CONCAT(c.fName, ' ', c.lName) AS user_name,c.profilPic as photo FROM userAnswerTagging a INNER JOIN stagesMaster b ON a.stageID = b.stageID 
                INNER JOIN userMaster c ON a.userID = c.userID 
                WHERE ansStatus = 'Y' GROUP BY a.stageID,a.userID";
        return $this->db->query($sql)->result_array();
    }

    function getSchoolTopper($school){
        $sql = "SELECT (count(questionID) * orderBy) AS Marks,a.userID, CONCAT(c.fName, ' ', c.lName) AS user_name,c.profilPic as photo FROM userAnswerTagging a INNER JOIN stagesMaster b ON a.stageID = b.stageID 
                INNER JOIN userMaster c ON a.userID = c.userID 
                WHERE c.schoolID = '$school' AND ansStatus = 'Y' GROUP BY a.stageID,a.userID";
        return $this->db->query($sql)->result_array();
    }

    function getStudentMarks($userID){
        $sql = "SELECT (count(questionID) * orderBy) AS Marks,a.userID, CONCAT(c.fName, ' ', c.lName) AS user_name,c.profilPic as photo FROM userAnswerTagging a INNER JOIN stagesMaster b ON a.stageID = b.stageID 
                INNER JOIN userMaster c ON a.userID = c.userID 
                WHERE ansStatus = 'Y' AND a.userID = $userID GROUP BY a.stageID,a.userID";
        return $this->db->query($sql)->result_array();
    }
}
<?php if ( ! defined('BASEPATH')){ exit('No direct script access allowed'); }
/**
 *
 * @author  Krishna
 * @date    16.08.2016
 *
**/

class Application extends MY_Controller {

    public function __construct() {

        parent::__construct();
        $this->load->model('application_model');
        $this->load->model('role_model');
    }

    public function index(){

        $Data['groupArr'] = parent::menu();

        $Data['page_title'] = "Manage Applications";
        $Data['load_page'] = "application/view_applications";
        $Data['applicationsArr'] = $this->application_model->getAllApplication();

        $this->load->view("kernel", $Data);
    }

    public function editPrivilegeModal($rID){

        $Data['privilegeDetails'] = $this->application_model->getprivilegeDetails($rID);
        $Data['applicationDetails'] = $this->application_model->getApplicationDetails($rID);
        $Data['getAllRoles'] = $this->role_model->getAllRoles();
        $this->load->view("content/application/edit_privilege_modal", $Data);
    }

    public function editPrivilege(){
            $id1 = $this->input->post('id1');
            $rows = $this->input->post('rows');
            $roles = $this->input->post('roles');
            $allroles = $this->input->post('allroleids');
            $allroles = rtrim($allroles,'!~!');

            $allroleids = explode("!~!",$allroles);
            $roles = ltrim($roles , ',');
            $ex = explode(",",$roles);
            foreach ($allroleids as $key => $value)
            {

                if(in_array($value,$ex))
                {
                   $status = $this->application_model->updatePrivilege($id1,$value,'Y');
                }
                else
                {
                  $status = $this->application_model->updatePrivilege($id1,$value,'N');
                }
            }
     }
}
<?php if ( ! defined('BASEPATH')){ exit('No direct script access allowed'); }
/**
 *
 * @author  Krishna Gupta
 * @date    19.02.2017
 *
**/

class Signup extends CI_Controller{

    function __construct() {
        parent::__construct();
        $this->load->helper('string');
        $this->load->helper('form');
        $this->load->helper('url');
        $this->load->library('pagination');
        $this->load->library('session');
        $this->load->library('email');

        $this->load->model('student_model');
        $this->load->model('employee_model');
        $this->load->model('role_model');
        $this->load->model('board_model');
        $this->load->model('school_model');
        $this->load->model('class_model');
        $this->load->model('subject_model');
        $this->load->model('package_model');
    }

    function index(){

        $sData = $this->session->userdata('user_details');

        if( $sData == TRUE ):
            redirect( base_url('home') );
        else:
            $this->signupForm();
        endif;
    }

    function signupForm(){

        $Data['boardArr'] = $this->board_model->getAllActiveBoards();
        $Data['schoolArr'] = $this->school_model->getAllActiveSchools();
        $Data['classArr'] = $this->class_model->getAllActiveClasses();
        $Data['subjectArr'] = $this->subject_model->getAllActiveSubjects();

        $Data['page_title'] = "Sign Up";
        $Data['load_page'] = "signup/index";
        $this->load->view("kernel", $Data);
    }

    function activateUser($link){

        $Data['status'] = 'Y';
        $Data['loginCount'] = 2;
        $Data['confirmation_value'] = $link;
        $confirmStatus = $this->student_model->activateUser($Data);
        if($confirmStatus){
            $this->session->set_flashdata('message', 'Success! Now you can login using your email id and password.');
        }else{
            $this->session->set_flashdata('warning', 'oops Something went wrong please try again.');
        }
        redirect( base_url('') );
    }


    function paynow($userID){
        $Data['student'] = $this->student_model->getStudentDetails($userID);
        $Data['fees']=1;
        //"T"=>Free Trial,"B"=>Bronze,"S"=>Silver,"G"=>Gold
        switch($Data['student']['userPackageType']){
          case 'T':$Data['fees']=0;$Data['userPackageType']='TRIAL';
            break;
          case 'B':$Data['fees']=500;$Data['userPackageType']='BRONZE';
            break;
          case 'S':$Data['fees']=1400;$Data['userPackageType']='SILVER';
            break;
          case 'G':$Data['fees']=2400;$Data['userPackageType']='GOLD';
            break;
          default : $Data['fees']=0;break;
        }
        $Data['page_title'] = "Payment";
        $Data['load_page'] = "signup/paynow";
        $this->load->view("kernel", $Data);
    }


    function processUserSignup(){

        $this->form_validation->set_rules('inputFirstName', 'User First Name', 'required');
        $this->form_validation->set_rules('inputLastName', ' User Last Name', 'required');
        $this->form_validation->set_rules('inputEmail', 'User Email', 'required|trim');
        $this->form_validation->set_rules('inputContact', 'User Contact', 'required');
        $this->form_validation->set_rules('inputParentName', 'User\'s Parent Name', 'required');
        $this->form_validation->set_rules('inputAddress', 'User Address', 'required');
        $this->form_validation->set_rules('inputBoard', 'User Board', 'required');
        $this->form_validation->set_rules('inputSchool', 'User School', 'required');
        $this->form_validation->set_rules('inputClass', 'User Standard', 'required');
        $this->form_validation->set_rules('inputPackage', 'User Package', 'required');

        if( $this->form_validation->run() === TRUE ){

            if($this->employee_model->getEmployeeCountByEmailid($this->input->post('inputEmail')) > 0){
                $this->session->set_flashdata('warning', 'Email Id is already registered with us,try with another.');
            }else{
                $password = random_string('alnum', 8);

                $postArr['fName'] = $this->input->post('inputFirstName');
                $postArr['lName'] = $this->input->post('inputLastName');
                $postArr['contactNumber'] = $this->input->post('inputContact');
                $postArr['residenceAdd'] = $this->input->post('inputAddress');
                $postArr['emailID'] = $this->input->post('inputEmail');
                $postArr['password'] = $password;
                $postArr['roleID'] = 3;
                $postArr['schoolID'] = $this->input->post('inputSchool');
                $postArr['boardID'] = $this->input->post('inputBoard');
                $postArr['stdID'] = $this->input->post('inputClass');
                $postArr['parentName'] = $this->input->post('inputParentName');
                $postArr['additionalInfo'] = $this->input->post('inputDesc');
                $postArr['status'] = "N";
                $postArr['package'] = $this->input->post('inputPackage');
                $query = $this->student_model->insertEmployee($postArr);
                $insertID = str_pad($query['insertID'], 8, '0', STR_PAD_LEFT);
                $postArr['confirmation_value'] = md5($insertID);
                $postArr['userID'] = $insertID;
                $profile_pic_name = 'profile_pic_'.$insertID.'.jpg';

                $postArr['selectedSubject'] = "";
                //insert user Package type
                if($postArr['package'] == 'B'){
                    $postArr['selectedSubject'] = $this->input->post('inputSubject1');
                    //$query_package = $this->package_model->insertPackageSubject($postArr);
                }elseif($postArr['package'] == 'S'){
                    $postArr['selectedSubject'] = $this->input->post('inputSubject1').'#'.$this->input->post('inputSubject2').'#'.$this->input->post('inputSubject3');
                    //$query_package = $this->package_model->insertPackageSubject($postArr);
                }elseif($postArr['package'] == 'G'){
                    $postArr['selectedSubject'] = $this->input->post('inputSubject1').'#'.$this->input->post('inputSubject2').'#'.$this->input->post('inputSubject3').'#'.$this->input->post('inputSubject4').'#'.$this->input->post('inputSubject5').'#'.$this->input->post('inputSubject6');
                    //$query_package = $this->package_model->insertPackageSubject($postArr);
                }elseif($postArr['package'] == 'T'){
                    $postArr['selectedSubject'] = 0;
                }

                $confirmStatus = $this->student_model->upgradePackage($postArr);

                if($query['status'])
                {
                    if(!empty($_FILES['inputProfilePic']['name'])){

                        $config['upload_path']   = './assets/images/profile_pic/';
                        $config['allowed_types'] = 'jpeg|jpg|png';
                        $config['file_name']     = $profile_pic_name;
                        $config['overwrite']     = TRUE;
                        $config['max_size']      = 0;
                        $config['max_width']     = 0;
                        $config['max_height']    = 0;
                        $this->load->library('upload', $config);
                        $this->upload->initialize($config);
                        if ( ! $this->upload->do_upload('inputProfilePic')) {
                            $error = array('error' => $this->upload->display_errors());
                            $postArr['profilPic'] = '';

                        }
                        else {
                            $data = array('upload_data' => $this->upload->data());
                            $postArr['profilPic'] = $profile_pic_name;
                        }
                    }else{
                        $postArr['profilPic'] = '';
                    }

                    if($this->student_model->updateEmployee($postArr))
                    {
                        $from_email = "admin@promediacamp.in";
                        $to_email = $this->input->post('inputEmail');
                        //$to_email = "krishna.gupta@rocketmail.com";
                        $this->email->set_mailtype("html");
                        $this->email->from($from_email, 'BKZ Admin');
                        $this->email->to($to_email);
                        $this->email->subject('Signup confirmation');
                        $this->email->message('Dear '.$this->input->post('inputFirstName').',<br/>Your password is :'.$password.'<br/> Kindly click to activate your account <a href="'.base_url('activation-link/'.$postArr['confirmation_value']).'">Click here</a>.');

                        //Send mail
                        if($this->email->send()){
                            $this->session->set_flashdata('message', 'Success! Sign up process has been completed,Confirmation link sent on your registered email ID.');
                            redirect( base_url('signup-paynow/'.$insertID) );
                        }
                        else {
                            $this->session->set_flashdata('warning', 'Warning! Sign up process has been completed,Error in sending Email.');
                        }
                    }else{

                       $this->session->set_flashdata('warning', 'Success! Sign up process has been completed But File has not been updaloaded.');
                   }
               }else{
                    $this->session->set_flashdata('warning', 'oops Something went wrong please try again.');
                }
            }
        }else{
              $this->session->set_flashdata('warning', 'All fields are mandetory.');
            }
        //echo 'test';exit;
        redirect( base_url('signup') );
    }

}

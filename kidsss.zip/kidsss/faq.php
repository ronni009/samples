<?php include('header.php'); ?>
		<header id="head" class="secondary">
            <div class="container">
                    <h1>Frequently Asked Questions</h1>
            </div>
		</header>


	<!-- container -->
	<section class="container">
		<div class="row">
			<div class="col-md-12">
				<section id="portfolio" class="page-section section appear clearfix">
					<br />
					<br />
						
								<div style="margin-bottom: 1cm;">
									What is a Big Knowledge Zone ?<br/>
									Big Knowledge Zone is Online Studies Institute.
								</div>
						
								<div style="margin-bottom: 1cm;">
									Who is design study material ?<br/>
									Institute develop own all program through own expert team.
								</div>
						
								<div style="margin-bottom: 1cm;">
									How can Big Knowledge Zone Improve Memory ?<br/>
									Each questions having five options, its answer you right or wrong, and that same question repeat then your memory should strike.
								</div>
						
								<div style="margin-bottom: 1cm;">
									How can Big Knowledge Zone increase Brain Performance ?<br/>
									Each questions having time limit one minute, you should answer within one minute.
								</div>
							</li>
						</ul>


					<!--<div class="row">
						<nav id="filter" class="col-md-12 text-center">
							<ul>
								<li><a href="#" class="current btn-theme btn-small" data-filter="*">All</a></li>
								<li><a href="#" class="btn-theme btn-small" data-filter=".webdesign">Development</a></li>
								<li><a href="#" class="btn-theme btn-small" data-filter=".photography">Designing</a></li>
								<li><a href="#" class="btn-theme btn-small" data-filter=".print">Tools</a></li>
							</ul>
						</nav>
						<div class="col-md-12">
							<div class="row">
								<div class="portfolio-items isotopeWrapper clearfix" id="3">

									<article class="col-sm-4 isotopeItem webdesign">
										<div class="portfolio-item">
											<img src="assets/images/portfolio/img1.jpg" alt="" />
											<div class="portfolio-desc align-center">
												<div class="folio-info">
													<a href="assets/images/portfolio/img1.jpg" class="fancybox">
														<h5>Project Title</h5>
														<i class="fa fa-link fa-2x"></i></a>
												</div>
											</div>
										</div>
									</article>

									<article class="col-sm-4 isotopeItem photography">
										<div class="portfolio-item">
											<img src="assets/images/portfolio/img2.jpg" alt="" />
											<div class="portfolio-desc align-center">
												<div class="folio-info">
													<a href="assets/images/portfolio/img2.jpg" class="fancybox">
														<h5>Project Title</h5>
														<i class="fa fa-link fa-2x"></i></a>
												</div>
											</div>
										</div>
									</article>


									<article class="col-sm-4 isotopeItem photography">
										<div class="portfolio-item">
											<img src="assets/images/portfolio/img3.jpg" alt="" />
											<div class="portfolio-desc align-center">
												<div class="folio-info">
													<a href="assets/images/portfolio/img3.jpg" class="fancybox">
														<h5>Project Title</h5>
														<i class="fa fa-link fa-2x"></i></a>
												</div>
											</div>
										</div>
									</article>

									<article class="col-sm-4 isotopeItem print">
										<div class="portfolio-item">
											<img src="assets/images/portfolio/img4.jpg" alt="" />
											<div class="portfolio-desc align-center">
												<div class="folio-info">
													<a href="assets/images/portfolio/img4.jpg" class="fancybox">
														<h5>Project Title</h5>
														<i class="fa fa-link fa-2x"></i></a>
												</div>
											</div>
										</div>
									</article>

									<article class="col-sm-4 isotopeItem photography">
										<div class="portfolio-item">
											<img src="assets/images/portfolio/img5.jpg" alt="" />
											<div class="portfolio-desc align-center">
												<div class="folio-info">
													<a href="assets/images/portfolio/img5.jpg" class="fancybox">
														<h5>Project Title</h5>
														<i class="fa fa-link fa-2x"></i></a>
												</div>
											</div>
										</div>
									</article>

									<article class="col-sm-4 isotopeItem webdesign">
										<div class="portfolio-item">
											<img src="assets/images/portfolio/img6.jpg" alt="" />
											<div class="portfolio-desc align-center">
												<div class="folio-info">
													<a href="assets/images/portfolio/img6.jpg" class="fancybox">
														<h5>Project Title</h5>
														<i class="fa fa-link fa-2x"></i></a>
												</div>
											</div>
										</div>
									</article>

									<article class="col-sm-4 isotopeItem print">
										<div class="portfolio-item">
											<img src="assets/images/portfolio/img7.jpg" alt="" />
											<div class="portfolio-desc align-center">
												<div class="folio-info">
													<a href="images/portfolio/img7.jpg" class="fancybox">
														<h5>Project Title</h5>
														<i class="fa fa-link fa-2x"></i></a>
												</div>
											</div>
										</div>
									</article>

									<article class="col-sm-4 isotopeItem photography">
										<div class="portfolio-item">
											<img src="assets/images/portfolio/img8.jpg" alt="" />
											<div class="portfolio-desc align-center">
												<div class="folio-info">
													<a href="images/portfolio/img8.jpg" class="fancybox">
														<h5>Project Title</h5>
														<i class="fa fa-link fa-2x"></i></a>
												</div>
											</div>
										</div>
									</article>

									<article class="col-sm-4 isotopeItem print">
										<div class="portfolio-item">
											<img src="assets/images/portfolio/img9.jpg" alt="" />
											<div class="portfolio-desc align-center">
												<div class="folio-info">
													<a href="images/portfolio/img9.jpg" class="fancybox">
														<h5>Project Title</h5>
														<i class="fa fa-link fa-2x"></i></a>
												</div>
											</div>
										</div>
									</article>
								</div>

							</div>


						</div>
					</div> -->

				</section>
			</div>
		</div>

	</section>
	<!-- /container -->
 <?php include("footer.php"); ?>
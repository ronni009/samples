 <!--footer starts-->

        <footer>

            <!--footer-widgets-wrapper starts-->
            <div class="footer-widgets-wrapper">
                <!--container starts-->
                <div class="container">
                    
                    <div class="column dt-sc-one-fourth first">
                        <aside class="widget widget_text">
                            <h3 class="widgettitle red_sketch"> Why Us </h3>
                            <p>Happy <a href=""><strong>Kids Life</strong></a> comes with powerful theme options, which empowers you to quickly and easily build incredible store.</p>
                            <ul>
                                <li> <a href="about.php"> Improve your Grasping Power </a> </li>
                                <li> <a href="about-quiz.php"> Increase your IQ Level </a> </li>
                                <li> <a href="package.php"> Transform your Future </a> </li>
                            </ul>
                        </aside>
                    </div>

                    <div class="column dt-sc-one-fourth first">
                        <aside class="widget widget_text">
                            <h3 class="widgettitle yellow_sketch"> Menu</h3>
                            <!-- <p>Happy <a href=""><strong>Kids Life</strong></a> comes with powerful theme options, which empowers you to quickly and easily build incredible store.</p> -->
                            <ul>
                                <li> <a href="about-quiz.php"> About Quiz</a> </li>
                                <li> <a href="knowledge_standard.php"> Knowledge Standard </a> </li>
                                <li> <a href="publisher_terms.php"> Publisher Terms </a> </li>
                                <li> <a href="terms_of_use.php"> Terms of Use </a> </li>
                                <li> <a href="privacy_policy.php"> Privacy Policy </a> </li>
                                <li> <a href="contact.php"> Contact Us </a> </li>
                            </ul>
                        </aside>
                    </div>
                   <!--  <div class="column dt-sc-one-fourth">
                        <aside class="widget widget_recent_entries">
                            <h3 class="widgettitle green_sketch"> Latest Post </h3>
                            <ul>
                                <li>
                                    <a href="">
                                        <img src="http://placehold.it/60x60" alt="" title="">
                                    </a>    
                                    <h6><a href=""> Amazing post with all  goodies </a></h6>
                                    <span> March 23, 2014 </span>       
                                </li>
                                <li>
                                    <a href="">
                                        <img src="http://placehold.it/60x60" alt="" title="">
                                    </a>
                                    <h6><a href=""> Amazing post with all  goodies </a></h6>
                                    <span> March 23, 2014 </span> 
                                </li>
                                <li>
                                    <a href="">
                                        <img src="http://placehold.it/60x60" alt="" title="">
                                    </a>
                                    <h6><a href=""> Amazing post with all  goodies </a></h6>
                                    <span> March 23, 2014 </span> 
                                </li>
                            </ul>
                        </aside>
                    </div> -->
                    <div class="column dt-sc-one-fourth">
                        <aside class="widget tweetbox">
                            <h3 class="widgettitle green_sketch"> Twitter Feeds </h3>
                            <div id="tweets_container"></div>
                        </aside>
                    </div>
                    <div class="column dt-sc-one-fourth">
                        <aside class="widget widget_text">
                        <h3 class="widgettitle steelblue_sketch">Contact</h3>
                            <div class="textwidget">
                                <p class="dt-sc-contact-info"><span class="fa fa-map-marker"></span> Shop 330, 1st Floor, Rahuleela Mall, Kandivali West. Mumbai 400067.</p>
                                <p class="dt-sc-contact-info"><span class="fa fa-phone"></span> +91-9619452992 </p>
                                <p class="dt-sc-contact-info"><span class="fa fa-envelope"></span><a href="mailto:info@bigknowledgezone.com"> info@bigknowledgezone.com </a></p>
                            </div>
                        </aside>
                       <!--  <aside class="widget mailchimp">
                            <p> We're social </p>Shop 330, 1st Flr, Rahuleela Mall, Kandivali West
                            <form name="frmnewsletter" class="mailchimp-form" action="php/subscribe.php" method="post">
                                <p>
                                    <span class="fa fa-envelope-o"> </span>
                                    <input type="email" placeholder="Email Address" name="mc_email" required />	
                                </p>	
                                <input type="submit" value="Subscribe" class="button" name="btnsubscribe">
                            </form>
                            <div id="ajax_subscribe_msg"></div>
                        </aside> -->
                    </div>
                    
                </div>    
                <!--container ends-->
            </div>
            <!--footer-widgets-wrapper ends-->  
            <div class="copyright">
        		<div class="container">
                   <div class="col-md-10 ">
                        <div class="panel-body">
                            <p class="simplenav">
                               <!--  <a href="index.php">Home</a> |
                                <a href="about.php">About Us</a> |
                                <a href="about-quiz.php">About Quiz</a> |
                                <a href="vision.php">Vision</a> |
                                <a href="package.php">Package</a> |
                                <a href="topper.php">Topper</a> | 
                                <a href="knowledge_standard.php">Knowledge Standard</a> |
                                <a href="publisher_terms.php">Publisher Terms</a> |
                                <a href="terms_of_use.php">Terms of Use</a> |
                                <a href="privacy_policy.php">Privacy Policy</a> |
                                <a href="contact.php">Contact</a>  -->
                                <p class="copyright-info">© Copyright © 2017. <a href="http://themeforest.net/user/designthemes" title="">  </a></p>
                            </p>
                        
                	
        			<div class="footer-links pull-right">
                        <p>Follow us</p>
                        <ul class="dt-sc-social-icons">
                        	<li class="facebook"><a href="#"><img src="images/facebook.png" alt="" title=""></a></li>
                            <li class="twitter"><a href="#"><img src="images/twitter.png" alt="" title=""></a></li>
                            <li class="gplus"><a href="#"><img src="images/gplus.png" alt="" title=""></a></li>
                            <li class="pinterest"><a href="#"><img src="images/pinterest.png" alt="" title=""></a></li>
                        </ul>
                    </div>
                    </div>
                    </div>
        		</div>
        	</div>  
        </footer>
        <!--footer ends-->
        
    </div>
    <!--wrapper ends-->
    <a href="" title="Go to Top" class="back-to-top">To Top ↑</a>
    <!--Java Scripts-->
    <script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript" src="js/jquery-migrate.min.js"></script>

    
	<script type="text/javascript" src="js/jquery.validate.min.js"></script>
	<script type="text/javascript" src="js/jquery-easing-1.3.js"></script>
    <script type="text/javascript" src="js/jquery.sticky.js"></script>
    <script type="text/javascript" src="js/jquery.nicescroll.min.js"></script>
    <script type="text/javascript" src="js/jquery.inview.js"></script>
    <script type="text/javascript" src="js/validation.js"></script>
    <script type="text/javascript" src="js/jquery.tipTip.minified.js"></script>
    <script type="text/javascript" src="js/jquery.bxslider.min.js"></script>       
    <script type="text/javascript" src="js/jquery.prettyPhoto.js"></script>  
    <script type="text/javascript" src="js/twitter/jquery.tweet.min.js"></script>
    <script type="text/javascript" src="js/jquery.parallax-1.1.3.js"></script>   
    <script type="text/javascript" src="js/shortcodes.js"></script>   
    <script type="text/javascript" src="js/custom.js"></script>
    
    <!-- Layer Slider --> 
    <script type="text/javascript" src="js/jquery-transit-modified.js"></script> 
    <script type="text/javascript" src="js/layerslider.kreaturamedia.jquery.js"></script> 
    <script type='text/javascript' src="js/greensock.js"></script> 
    <script type='text/javascript' src="js/layerslider.transitions.js"></script> 
    <!--<script type="text/javascript">var lsjQuery = jQuery;</script>--> 
    <script type="text/javascript">var lsjQuery = jQuery;</script><script type="text/javascript"> lsjQuery(document).ready(function() { if(typeof lsjQuery.fn.layerSlider == "undefined") { lsShowNotice('layerslider_1','jquery'); } else { lsjQuery("#layerslider_4").layerSlider({responsiveUnder: 1240, layersContainer: 1060, skinsPath: 'js/layerslider/skins/'}) } }); </script>
    
    <script type="text/javascript" src="js/jquery.tabs.min.js"></script>

    
    
  
    <script type="text/javascript" src="js/jquery.isotope.min.js"></script>
    <script type="text/javascript" src="js/jquery.carouFredSel-6.2.0-packed.js"></script>  
</body>
</html>

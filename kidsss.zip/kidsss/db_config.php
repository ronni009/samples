<?php
$dbconn=mysql_connect('localhost','bkzquiz_web','bkzpmc@0123');
//$dbconn=mysql_connect('localhost','root','');
mysql_select_db('bkzquiz_web',$dbconn);
?>

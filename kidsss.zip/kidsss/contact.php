<?php include('header.php') ?>
        <!--main starts-->
        <div id="main">
            <!--breadcrumb-section starts-->
            <div class="breadcrumb-section">
                <div class="container">
                    <h1>Contact Us</h1>
                    <div class="breadcrumb">
                        <a href="index.php">Home</a>
                        <span class="fa fa-angle-double-right"></span>
                        <span class="current">Contact us</span>
                    </div>
                </div>
            </div>
            <!--breadcrumb-section ends-->
            <!--container starts-->
            <div class="container">
                <!--primary starts-->
                <section id="primary" class="content-full-width">
                    
                    <!-- <div class="column dt-sc-one-half first">
                        <div class="about-slider-wrapper">
                            <ul class="about-slider">
                                <li> <img src="http://placehold.it/1170x538" alt="" title=""> </li>
                                <li> <img src="http://placehold.it/1170x538" alt="" title=""> </li>
                                <li> <img src="http://placehold.it/1170x538" alt="" title=""> </li>
                            </ul>
                        </div>  
                    </div> -->
                    
                    <!--dt-sc-one-half starts-->
                    <div class="column dt-sc-one-full">                  
                        
    <!-- Header -->
<script type="text/javascript">
function changeSubject(){
if (document.getElementById('subType_t').checked) {
    document.getElementById('subject').value='Testimonial';
}
else {
    document.getElementById('subject').value='';
}
}
function fire_mail(){
name=document.getElementById('name').value;
subject=document.getElementById('subject').value;
message=document.getElementById('message').value;
email=document.getElementById('email').value;
phone=document.getElementById('phone').value;

  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      document.getElementById("finalmsg").innerHTML = this.responseText;
    }
  };
  xhttp.open("POST", "mail.php", true);
  xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  xhttp.send('name='+name+'&email='+email+'&phone='+phone+'&message='+message+'&subject='+subject);
}
</script>
    
    <!-- container -->
    <div class="container">
                <div class="row">
                    <div class="col-md-8">

                        <h3 class="section-title">Your Message</h3>
                        <p></p>
                    <div id='finalmsg'></div>
                        <form class="form-light mt-20" role="form">
                            <div class="form-group">
                                <label>Name</label>
                                <input type="text" class="form-control" placeholder="Your name" name='name' id='name'>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Email</label>
                                        <input type="email" class="form-control" placeholder="Email address" name='email' id='email'>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Phone</label>
                                        <input type="text" class="form-control" placeholder="Phone number" name='phone' id='phone'>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label>Subject : </label>
                                Testimonial : <input type='radio' onclick="changeSubject();" value='Testimonial' id='subType_t' name='subType'>
                                Particular : <input type='radio' onclick="changeSubject();" value='Particular' id='subType' name='subType' checked="True">
                                <input type="text" class="form-control" placeholder="Subject" name='subject' id='subject'>
                            </div>
                            <div class="form-group">
                                <label>Message</label>
                                <textarea class="form-control" id="message" name="message" placeholder="Write you message here..." style="height:100px;"></textarea>
                            </div>
                            <button type="button" class="btn btn-primary" onclick="fire_mail()">Send message</button><p><br/></p>
                        </form>
                    </div>
                   <div class="col-md-4">
                        <div class="row">
                            <div class="col-md-12">
                                <h3 class="section-title">Office Address</h3>
                                <div class="contact-info">
                                    <p>Shop no. 330, 1st Floor, Raghuleela Mall,
Behind Poisar Bus Depot, Kandivali (West),</br> Mumbai 400067.</p>
                            <i class="fa fa-phone"></i> +91-9619452992<br>
             <a href="mailto:info@bigknowledgezone.com" class="mail_link"><span class="fa fa-envelope"></span> info@bigknowledgezone.com</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /container -->



                        <!-- <a href="#" class="dt-sc-button small read-more"> Read More <span class="fa fa-chevron-circle-right"> </span></a>  -->  
                    </div> 
                    <!--dt-sc-one-half ends-->
                    
                    <div class="dt-sc-hr"></div>
                    
                    <!--dt-sc-one-half starts--><!-- 
                    <div class="dt-sc-one-half column first">
                        <h2>Meet Our Founder</h2> 
                        <div class="author-details">
                            <div class="author-thumb">
                                <img class="item-mask" src="images/author-hexa-bg.png" alt="" title="">
                                <img src="http://placehold.it/119x101" alt="" title="">
                            </div>
                            <div class="author-description">
                                <h5><a href="">James Bond</a></h5>
                                <span class="author-role">Music Trainer, Specialist in  <a href="#">Classical Music</a></span>
                                <a href="#" class="students-count"><span class="fa fa-user"></span> 25 STUDENTS</a>
                                <div class="rating-review">
                                    <span class="author-rating rating-4"></span> <a href="#">2 reviews</a>
                                </div>
                                <p>Phasellus lorem augue, vulputate vel orci id, ultricies aliquet risus. Sed cursus ipsum vitae justo scelerisque, ac viverra tellus eleifend. Etiam interdum justo nunc, ac volutpat erat elementum id. Fusce dapibus mauris ac dictum porta. Sed pretium luctus elementum. In sollicitudin felis semper purus imperdiet lobortis. In odio tellus, rhoncus eget dolor in, </p>
                            </div>
                        </div>
                    </div>      
                    <!--dt-sc-one-half ends--> 
                    <!--dt-sc-one-half starts-->
<!--                     <div class="dt-sc-one-half column"> 
                        <h2>Testimonials</h2>
                        <div class="dt-sc-testimonial-carousel-wrapper">
                            <ul class='dt-sc-testimonial-carousel'> 
                                <li>
                                    <div class='dt-sc-testimonial'>
                                        <blockquote><q>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec hendrerit vehicula est, in consequat. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec hendrerit vehiculaest, in consequat. Donec hendrerit vehicula est, in consequat. Donec hendrerit vehicula est, in consequat.</q></blockquote> -->
                                        <!-- <div class='author'>
                                            <img src="http://placehold.it/69x70" alt="" title="">
                                        </div>
                                        <div class="author-meta">
                                            <p> Rooney </p>
                                            <span>CEO &amp; Founder - Dhoom Inc</span>
                                            <span class="author-rating rating-4"></span>
                                        </div>   -->      
                                   <!--  </div>
                                </li>
                                <li>
                                     <div class='dt-sc-testimonial'>
                                        <blockquote><q>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec hendrerit vehicula est, in consequat. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec hendrerit vehiculaest, in consequat. Donec hendrerit vehicula est, in consequat. Donec hendrerit vehicula est, in consequat.</q></blockquote> -->
                                        <!-- <div class='author'>
                                            <img src="http://placehold.it/69x70" alt="" title="">
                                        </div>
                                        <div class="author-meta">
                                            <p> Rooney </p>
                                            <span>CEO &amp; Founder - Dhoom Inc</span>
                                            <span class="author-rating rating-4"></span>
                                        </div>    -->     
                                    <!-- </div>
                                </li>
                                <li>
                                     <div class='dt-sc-testimonial'>
                                        <blockquote><q>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec hendrerit vehicula est, in consequat. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec hendrerit vehiculaest, in consequat. Donec hendrerit vehicula est, in consequat. Donec hendrerit vehicula est, in consequat.</q></blockquote> -->
                                        <!-- <div class='author'>
                                            <img src="http://placehold.it/69x70" alt="" title="">
                                        </div>
                                        <div class="author-meta">
                                            <p> Rooney </p>
                                            <span>CEO &amp; Founder - Dhoom Inc</span>
                                            <span class="author-rating rating-4"></span>
                                        </div>   -->      
                                    </div>
                                </li>
                            </ul>
                            <!-- <div class="carousel-arrows">   
                                <a href="#" class="testimonial-prev"><span class="fa fa-angle-left"></span></a> 
                                <a href="#" class="testimonial-next"><span class="fa fa-angle-right"></span></a>
                            </div> -->
                        </div>
                    </div>      
                    <!--dt-sc-one-half ends--> 
                    
                    <div class="dt-sc-hr"></div>
                   
                    <h2 class="dt-sc-hr-green-title"></h2> <!--
                    <div class="column dt-sc-one-fourth first">
                        <div class="dt-sc-team">    
                            <div class="image">
                                <img class="item-mask" src="images/mask.png" alt="" title="">
                                <img src="http://placehold.it/381x331" alt="" title="">
                                <div class="dt-sc-image-overlay">
                                    <a href="#" class="link"><span class="fa fa-link"></span></a>
                                    <a href="#" class="zoom"><span class="fa fa-search"></span></a>
                                </div>
                            </div>
                            <div class="team-details">
                                <h4> Jack Daniels </h4>
                                <h6> Senior Supervisor </h6>
                                <p> Phasellus lorem augue, vulputate vel orci id, ultricies aliquet risus. </p>
                            </div>
                        </div>
                    </div>
                    <div class="column dt-sc-one-fourth">
                        <div class="dt-sc-team">    
                            <div class="image">
                                <img class="item-mask" src="images/mask.png" alt="" title="">
                                <img src="http://placehold.it/381x331" alt="" title="">
                                <div class="dt-sc-image-overlay">
                                    <a href="#" class="link"><span class="fa fa-link"></span></a>
                                    <a href="#" class="zoom"><span class="fa fa-search"></span></a>
                                </div>
                            </div>
                            <div class="team-details">
                                <h4> Linda Glendell </h4>
                                <h6> Teaching Professor </h6>
                                <p> Phasellus lorem augue, vulputate vel orci id, ultricies aliquet risus. </p>
                            </div>
                        </div>
                    </div>
                    <div class="column dt-sc-one-fourth">
                        <div class="dt-sc-team">    
                            <div class="image">
                                <img class="item-mask" src="images/mask.png" alt="" title="">
                                <img src="http://placehold.it/381x331" alt="" title="">
                                <div class="dt-sc-image-overlay">
                                    <a href="#" class="link"><span class="fa fa-link"></span></a>
                                    <a href="#" class="zoom"><span class="fa fa-search"></span></a>
                                </div>
                            </div>
                            <div class="team-details">
                                <h4> Kate Dennings </h4>
                                <h6> Children Diet </h6>
                                <p> Phasellus lorem augue, vulputate vel orci id, ultricies aliquet risus. </p>
                            </div>
                        </div>
                    </div>
                    <div class="column dt-sc-one-fourth">
                        <div class="dt-sc-team">    
                            <div class="image">
                                <img class="item-mask" src="images/mask.png" alt="" title="">
                                <img src="http://placehold.it/381x331" alt="" title="">
                                <div class="dt-sc-image-overlay">
                                    <a href="#" class="link"><span class="fa fa-link"></span></a>
                                    <a href="#" class="zoom"><span class="fa fa-search"></span></a>
                                </div>
                            </div>
                            <div class="team-details">
                                <h4> Kristof Slinghot </h4>
                                <h6> Management </h6>
                                <p> Phasellus lorem augue, vulputate vel orci id, ultricies aliquet risus. </p>
                            </div>
                        </div>
                    </div> -->
                    <!--
                    <div class="dt-sc-hr"></div>
                    <h2>Our Sponsors</h2>
                     <div class="dt-sc-sponsor-carousel-wrapper">                    
                        <ul class="dt-sc-sponsor-carousel">
                            <li> <a href="" title=""> <img src="http://placehold.it/206x116" alt="" title=""> </a> </li>
                            <li> <a href="" title=""> <img src="http://placehold.it/206x116" alt="" title=""> </a> </li>
                            <li> <a href="" title=""> <img src="http://placehold.it/206x116" alt="" title=""> </a> </li>
                            <li> <a href="" title=""> <img src="http://placehold.it/206x116" alt="" title=""> </a> </li>
                            <li> <a href="" title=""> <img src="http://placehold.it/206x116" alt="" title=""> </a> </li>
                            <li> <a href="" title=""> <img src="http://placehold.it/206x116" alt="" title=""> </a> </li>
                        </ul>
                        
                        <div class="carousel-arrows">
                            <a class="sponsor-prev" href=""> </a>
                            <a class="sponsor-next" href=""> </a>
                        </div>
                    </div> -->
                    
                </section>
                <!--primary ends-->
            </div>
            <!--container ends-->
        </div>
        <!--main ends-->
        
<?php include('footer.php'); ?>
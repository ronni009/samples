<?php include('header.php') ?>
        <!--main starts-->
        <div id="main">
        	<!--breadcrumb-section starts-->
            <div class="breadcrumb-section">
            	<div class="container">
                	<h1>About Quiz</h1>
                    <div class="breadcrumb">
                        <a href="index.php">Home</a>
                        <span class="fa fa-angle-double-right"></span>
                        <span class="current">About quiz</span>
                    </div>
                </div>
            </div>
            <!--breadcrumb-section ends-->
            <!--container starts-->
            <div class="container">
            	<!--primary starts-->
            	<section id="primary" class="content-full-width">
                    
                    <!-- <div class="column dt-sc-one-half first">
                    	<div class="about-slider-wrapper">
                            <ul class="about-slider">
                                <li> <img src="http://placehold.it/1170x538" alt="" title=""> </li>
                                <li> <img src="http://placehold.it/1170x538" alt="" title=""> </li>
                                <li> <img src="http://placehold.it/1170x538" alt="" title=""> </li>
                            </ul>
                        </div>	
                    </div> -->
                    
                    <!--dt-sc-one-half starts-->
                    <div class="column dt-sc-one-full">                  
                        <h2>About Us</h2>
                    <p style="text-align: justify;text-justify: inter-word;">
                  BIGKNOWLEDGEZONE.COM is an ONLINE QUIZ PORTAL that contemplates the PSYCHOLOGICAL & INTELLECTUAL aspects of students, teachers, teenagers, home makers and professionals. This is not the conventional concept of On-the-spot quiz for a day, but a full year learning program in a relaxed atmosphere. It is a modern, innovative and simple concept of gaining knowledge by playing interesting quizzes.
                  </p>
                  <p style="text-align: justify;text-justify: inter-word;">
                  Quizzes are designed in such a way that will help students to gain General Knowledge and Intelligence along with his academic studies as well. Also the format of quiz develops a feeling of competitiveness which will help them to know “How to Compete” amongst the participants which will reflect in their further studies and other challenges in personal and professional life in future.
                  </p>
                  <p style="text-align: justify;text-justify: inter-word;">
                  The simple logic in WE believe is that the way regular physical exercise makes a human body fit and fine, In the same way regular solving of quizzes helps human brain to find different and analytical solutions to every issues related to studies, personal and professional life. The whole process is conceptualized to incite oneself to unleash his hidden persona and acquire confidence that would eventually upsurge their self-esteem and personality.
                </p>                        
                        
                    </div> 

                    <div class="column dt-sc-one-full">                  
                        <h2>Our Founder</h2>
                    <p style="text-align: justify;text-justify: inter-word;">
                  Founded in the year 2010 by Mr. Purshotam kadam. However, this concept got its birth since 1988. Mr. Kadam started researching since he was a lad. His curiosity and inquisitiveness to explore innovative concepts made his idea moulded into BKZ. Also Mr. Kadam’s personal interest was to buy books related to quizzes, puzzles, GK & more. So since childhood, his hobby was to find solutions to the quizzes & puzzles, which in turn helped him to find effective solutions to any issues in his professional and personal life that, led him to become a successful person. He researched that quizzes helps in increasing Knowledge, improve grasping and enhancing IQ level. The quizzes are experimented and tested on the students which eventually helped them to gain excellent results in their academic career who were previously average students. His kitty of achievements also includes exploring the knowledge of Astrology, Reiki, Pranik healing, Crystal therapy, Hyptno therapy, Colour therapy, Vastu astrology, Feng shui, Aroma therapy, Sub-conscious mind power and 20 such other relevant streams. He also conducts seminars and presentations on regular basis to share his above mentioned knowledge. He believes, “knowledge increases when you share it”. Even being a senior management level employee, his aim was to bring a change in the monotonous education system of India. The way his successful research helped few students to explicitly create wonders in their exams, in the same way he wants every student/participant to be embedded with this power. Thus, in order to persuade this aim of his life, he spent long hours on his research after his daily duties and walked an extra mile to work on his ideas. Finally, after the rigorous research and firm determination of approximately 2 decades, he came up with this innovative concept of BKZ.
                  </p>
                  <!-- <p style="text-align: justify;text-justify: inter-word;">
                  Quizzes are designed in such a way that will help students to gain General Knowledge and Intelligence along with his academic studies as well. Also the format of quiz develops a feeling of competitiveness which will help them to know “How to Compete” amongst the participants which will reflect in their further studies and other challenges in personal and professional life in future.
                  </p>
                  <p style="text-align: justify;text-justify: inter-word;">
                  The simple logic in WE believe is that the way regular physical exercise makes a human body fit and fine, In the same way regular solving of quizzes helps human brain to find different and analytical solutions to every issues related to studies, personal and professional life. The whole process is conceptualized to incite oneself to unleash his hidden persona and acquire confidence that would eventually upsurge their self-esteem and personality.
                </p>     -->                    
                        
                    </div> 

                    <div class="column dt-sc-one-full">   
                    <h2>About BKZ Quiz</h2>               
                        <p style="text-align: justify;text-justify: inter-word;">
A quiz is a form of game or mind sport in which the participant attempts to answer questions correctly. We all know the literal meaning of the word “QUIZ”, However, we need to understand its importance as well. Quizzes are important because they help individuals increase the knowledge they may already know on a certain topic. Also, the feeling of competition elicits them to explore their knowledge sources and walk an extra mile to get the correct answers. A participant can also be acquainted with his strengths and weaknesses on specific topics on the basis of quiz results.</p>
<p>Constant solving or practicing quizzes helps to increase the knowledge, grasping power and IQ level. We design the quizzes with an intention to increase the above mentioned mental potency.</p>
<p>The distinctiveness of our quiz is that we also include few questions from the academic studies on the basis of standard of the participant. In simple words, a participant is doing his regular school studies along with the extra knowledge he gets by solving our quizzes. Parents now can be rest assured that their kid is doing his studies as well by playing our exciting quizzes. </p>
<p>Also, our quizzes are designed as per the “Principles of repetition”, meaning there is a possibility of the questions getting repeated in the levels or stages of our quiz. This helps the participants in remembering answers more confidently. </p>
<p>To make it more interesting, we have cluttered questions on different topics in each stage. For example, a kid is now answering a question based on numerical ability, but the following question could be about history or general knowledge. Being time bound, it coerces the participants to think on different topics in that specified time period. This accelerates the thought process tremendously. </p>
<p>This exceptional and fascinating concept is successfully tried and tested on certain students which helped them to come up with flying colours in their following academic examinations. </p>
<p>Our huge database of questions includes topics related to General Knowledge, Numerical Ability, Aptitude test, Logical Reasoning, Intelligence test, Psychometric test, Current Affairs, Science, History, Geography, World Politics, Indian Politics, Sports, etc . Our quiz database keeps on getting upgraded after regular intervals which adds more interesting questions. </p>
<p>Our Quiz products are restricted age group below 5 years. We cater school students, teenagers, teachers, home makers and professionals. </p>
<p>To add a feather in the cap, our Quiz ideology is on the final stage of getting the patent approved by the patenting authorities of India.
              </p>
                        <!-- <a href="#" class="dt-sc-button small read-more"> Read More <span class="fa fa-chevron-circle-right"> </span></a>  -->  
                    </div> 
                    <!--dt-sc-one-half ends-->
                    
                    <div class="dt-sc-hr"></div>
                    
                    <!--dt-sc-one-half starts--><!-- 
                    <div class="dt-sc-one-half column first">
                    	<h2>Meet Our Founder</h2> 
                        <div class="author-details">
                        	<div class="author-thumb">
                                <img class="item-mask" src="images/author-hexa-bg.png" alt="" title="">
                                <img src="http://placehold.it/119x101" alt="" title="">
                            </div>
                            <div class="author-description">
                                <h5><a href="">James Bond</a></h5>
                                <span class="author-role">Music Trainer, Specialist in  <a href="#">Classical Music</a></span>
                                <a href="#" class="students-count"><span class="fa fa-user"></span> 25 STUDENTS</a>
                                <div class="rating-review">
                                	<span class="author-rating rating-4"></span> <a href="#">2 reviews</a>
                                </div>
                                <p>Phasellus lorem augue, vulputate vel orci id, ultricies aliquet risus. Sed cursus ipsum vitae justo scelerisque, ac viverra tellus eleifend. Etiam interdum justo nunc, ac volutpat erat elementum id. Fusce dapibus mauris ac dictum porta. Sed pretium luctus elementum. In sollicitudin felis semper purus imperdiet lobortis. In odio tellus, rhoncus eget dolor in, </p>
                        	</div>
                        </div>
                    </div>      
                    <!--dt-sc-one-half ends--> 
                    <!--dt-sc-one-half starts-->
<!--                     <div class="dt-sc-one-half column"> 
                    	<h2>Testimonials</h2>
                        <div class="dt-sc-testimonial-carousel-wrapper">
                            <ul class='dt-sc-testimonial-carousel'> 
                                <li>
                                    <div class='dt-sc-testimonial'>
                                    	<blockquote><q>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec hendrerit vehicula est, in consequat. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec hendrerit vehiculaest, in consequat. Donec hendrerit vehicula est, in consequat. Donec hendrerit vehicula est, in consequat.</q></blockquote> -->
                                        <!-- <div class='author'>
                                            <img src="http://placehold.it/69x70" alt="" title="">
                                        </div>
                                        <div class="author-meta">
                                        	<p> Rooney </p>
                                            <span>CEO &amp; Founder - Dhoom Inc</span>
                                            <span class="author-rating rating-4"></span>
                                    	</div>   -->      
                                   <!--  </div>
                                </li>
                                <li>
                                     <div class='dt-sc-testimonial'>
                                    	<blockquote><q>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec hendrerit vehicula est, in consequat. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec hendrerit vehiculaest, in consequat. Donec hendrerit vehicula est, in consequat. Donec hendrerit vehicula est, in consequat.</q></blockquote> -->
                                        <!-- <div class='author'>
                                            <img src="http://placehold.it/69x70" alt="" title="">
                                        </div>
                                        <div class="author-meta">
                                        	<p> Rooney </p>
                                            <span>CEO &amp; Founder - Dhoom Inc</span>
                                            <span class="author-rating rating-4"></span>
                                    	</div>    -->     
                                    <!-- </div>
                                </li>
                                <li>
                                     <div class='dt-sc-testimonial'>
                                    	<blockquote><q>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec hendrerit vehicula est, in consequat. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec hendrerit vehiculaest, in consequat. Donec hendrerit vehicula est, in consequat. Donec hendrerit vehicula est, in consequat.</q></blockquote> -->
                                        <!-- <div class='author'>
                                            <img src="http://placehold.it/69x70" alt="" title="">
                                        </div>
                                        <div class="author-meta">
                                        	<p> Rooney </p>
                                            <span>CEO &amp; Founder - Dhoom Inc</span>
                                            <span class="author-rating rating-4"></span>
                                    	</div>   -->      
                                    </div>
                                </li>
                            </ul>
                            <!-- <div class="carousel-arrows">	
                                <a href="#" class="testimonial-prev"><span class="fa fa-angle-left"></span></a>	
                                <a href="#" class="testimonial-next"><span class="fa fa-angle-right"></span></a>
                            </div> -->
                        </div>
                    </div>      
                    <!--dt-sc-one-half ends--> 
                    <!--
                    <div class="dt-sc-hr"></div>
                   
                    <h2 class="dt-sc-hr-green-title"></h2> 
                    <div class="column dt-sc-one-fourth first">
                        <div class="dt-sc-team">	
                            <div class="image">
                                <img class="item-mask" src="images/mask.png" alt="" title="">
                                <img src="http://placehold.it/381x331" alt="" title="">
                                <div class="dt-sc-image-overlay">
                                	<a href="#" class="link"><span class="fa fa-link"></span></a>
                                    <a href="#" class="zoom"><span class="fa fa-search"></span></a>
                                </div>
                            </div>
                            <div class="team-details">
                                <h4> Jack Daniels </h4>
                                <h6> Senior Supervisor </h6>
                                <p> Phasellus lorem augue, vulputate vel orci id, ultricies aliquet risus. </p>
                            </div>
                        </div>
                    </div>
                    <div class="column dt-sc-one-fourth">
                        <div class="dt-sc-team">	
                            <div class="image">
                                <img class="item-mask" src="images/mask.png" alt="" title="">
                                <img src="http://placehold.it/381x331" alt="" title="">
                                <div class="dt-sc-image-overlay">
                                	<a href="#" class="link"><span class="fa fa-link"></span></a>
                                    <a href="#" class="zoom"><span class="fa fa-search"></span></a>
                                </div>
                            </div>
                            <div class="team-details">
                                <h4> Linda Glendell </h4>
                                <h6> Teaching Professor </h6>
                                <p> Phasellus lorem augue, vulputate vel orci id, ultricies aliquet risus. </p>
                            </div>
                        </div>
                    </div>
                    <div class="column dt-sc-one-fourth">
                        <div class="dt-sc-team">	
                            <div class="image">
                                <img class="item-mask" src="images/mask.png" alt="" title="">
                                <img src="http://placehold.it/381x331" alt="" title="">
                                <div class="dt-sc-image-overlay">
                                	<a href="#" class="link"><span class="fa fa-link"></span></a>
                                    <a href="#" class="zoom"><span class="fa fa-search"></span></a>
                                </div>
                            </div>
                            <div class="team-details">
                                <h4> Kate Dennings </h4>
                                <h6> Children Diet </h6>
                                <p> Phasellus lorem augue, vulputate vel orci id, ultricies aliquet risus. </p>
                            </div>
                        </div>
                    </div>
                    <div class="column dt-sc-one-fourth">
                        <div class="dt-sc-team">	
                            <div class="image">
                                <img class="item-mask" src="images/mask.png" alt="" title="">
                                <img src="http://placehold.it/381x331" alt="" title="">
                                <div class="dt-sc-image-overlay">
                                	<a href="#" class="link"><span class="fa fa-link"></span></a>
                                    <a href="#" class="zoom"><span class="fa fa-search"></span></a>
                                </div>
                            </div>
                            <div class="team-details">
                                <h4> Kristof Slinghot </h4>
                                <h6> Management </h6>
                                <p> Phasellus lorem augue, vulputate vel orci id, ultricies aliquet risus. </p>
                            </div>
                        </div>
                    </div> -->
                    <!--
                    <div class="dt-sc-hr"></div>
                    <h2>Our Sponsors</h2>
                     <div class="dt-sc-sponsor-carousel-wrapper">                    
                        <ul class="dt-sc-sponsor-carousel">
                            <li> <a href="" title=""> <img src="http://placehold.it/206x116" alt="" title=""> </a> </li>
                            <li> <a href="" title=""> <img src="http://placehold.it/206x116" alt="" title=""> </a> </li>
                            <li> <a href="" title=""> <img src="http://placehold.it/206x116" alt="" title=""> </a> </li>
                            <li> <a href="" title=""> <img src="http://placehold.it/206x116" alt="" title=""> </a> </li>
                            <li> <a href="" title=""> <img src="http://placehold.it/206x116" alt="" title=""> </a> </li>
                            <li> <a href="" title=""> <img src="http://placehold.it/206x116" alt="" title=""> </a> </li>
                        </ul>
                        
                        <div class="carousel-arrows">
                            <a class="sponsor-prev" href=""> </a>
                            <a class="sponsor-next" href=""> </a>
                        </div>
                    </div> -->
                    
                </section>
                <!--primary ends-->
            </div>
            <!--container ends-->
        </div>
        <!--main ends-->
        
<?php include('footer.php'); ?>
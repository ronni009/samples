<?php include('header.php');
$allTestimonial = json_decode(file_get_contents($host.'/testimonial-all'),true);
$carousel='';$carouselValue='';
file_get_contents($host.'/testimonial-all');
foreach ($allTestimonial as $key => $value) {
$carousel.='<li data-target="#fade-quote-carousel" data-slide-to="'.$key.'"></li>';
$active=($key==0)?'active':'';
$carouselValue.=' <div class="item '.$active.'">
     <div><h2><center>'.$value['name'].'</center></h2></div>
     <blockquote>
         <p>'.$value['message'].'</p>
     </blockquote>
 </div>';
}
?>
        <div id="main">
            <!--breadcrumb-section starts-->
            <div class="breadcrumb-section">
                <div class="container">
                    <h1>About Us</h1>
                    <div class="breadcrumb">
                        <a href="index.php">Home</a>
                        <span class="fa fa-angle-double-right"></span>
                        <span class="current">About Us</span>
                    </div>
                </div>
            </div>
            <!--breadcrumb-section ends-->
            <!--container starts-->
            <div class="container">
                <!--primary starts-->
                <section id="primary" class="content-full-width">
                    
                    <div class="column dt-sc-one-half first">
                        <div class="about-slider-wrapper">
                            <ul class="about-slider">
                                <li> <img src="http://placehold.it/1170x538" alt="" title=""> </li>
                                <!-- <li> <img src="http://placehold.it/1170x538" alt="" title=""> </li>
                                <li> <img src="http://placehold.it/1170x538" alt="" title=""> </li> -->
                            </ul>
                        </div>  
                    </div>
                    
                    <!--dt-sc-one-half starts-->
                    <div class="column dt-sc-one-half">                  
                        <h2>About BKZ</h2>
                        <p>BIGKNOWLEDGEZONE.COM is an ONLINE QUIZ PORTAL that contemplates the PSYCHOLOGICAL & INTELLECTUAL aspects of students, teachers, teenagers, home makers and professionals. This is not the conventional concept of On-the-spot quiz for a day, but a full year learning program in a relaxed atmosphere. It is a modern, innovative and simple concept of gaining knowledge by playing interesting quizzes.</p>
                        <a href="about-quiz.php" class="dt-sc-button small read-more"> Read More <span class="fa fa-chevron-circle-right"> </span></a>   
                    </div> 
                    <!--dt-sc-one-half ends-->
                    
                    <div class="dt-sc-hr"></div>
                    
                    <!--dt-sc-one-half starts-->
                    <div class="dt-sc-one-half column first">
                        <h2>Meet Our Founder</h2> 
                        <div class="author-details">
                            <div class="author-thumb">
                                <img class="item-mask" src="images/author-hexa-bg.png" alt="" title="">
                                <img src="http://placehold.it/119x101" alt="" title="">
                            </div>
                            <div class="author-description">
                                <h5><a href="">Mr. Purshotam Kadam</a></h5>
                                <!-- <span class="author-role">Music Trainer, Specialist in  <a href="#">Classical Music</a></span>
                                <a href="#" class="students-count"><span class="fa fa-user"></span> 25 STUDENTS</a>
                                <div class="rating-review">
                                    <span class="author-rating rating-4"></span> <a href="#">2 reviews</a>
                                </div> -->
                                <p>Founded in the year 2010 by Mr. Purshotam kadam. However, this concept got its birth since 1988. Mr. Kadam started researching since he was a lad. His curiosity and inquisitiveness to explore innovative concepts made his idea moulded into BKZ. Also Mr. Kadam’s personal interest was to buy books related to quizzes, puzzles, GK & more. So since childhood, his hobby was to find solutions to the quizzes & puzzles, which in turn helped him to find effective solutions to any issues in his professional and personal life that, led him to become a successful person. He researched that quizzes helps in increasing Knowledge, improve grasping and enhancing IQ level. </br><a href="about-quiz.php" class="dt-sc-button small read-more"> Read More <span class="fa fa-chevron-circle-right"> </span></a>  </p>
                            </div>
                        </div>
                    </div>      
                    <!--dt-sc-one-half ends--> 
                    <!--dt-sc-one-half starts-->
                    <div class="dt-sc-one-half column"> 
                        <h2>Testimonials</h2>
                        <div class="dt-sc-testimonial-carousel-wrapper">
                            <ul class='dt-sc-testimonial-carousel'> 
                                <li>
                                    <div class='dt-sc-testimonial'>
                                        <blockquote><q> <?php echo $carouselValue; ?></q></blockquote>
                                      <!--   <div class='author'>
                                            <img src="http://placehold.it/69x70" alt="" title="">
                                        </div>
                                        <div class="author-meta">
                                            <p> Rooney </p>
                                            <span>CEO &amp; Founder - Dhoom Inc</span>
                                            <span class="author-rating rating-4"></span>
                                        </div>      -->   
                                    </div>
                                </li>
                                <li>
                                     <div class='dt-sc-testimonial'>
                                        <blockquote><q><?php echo $carouselValue; ?></q></blockquote>
                                    <!--     <div class='author'>
                                            <img src="http://placehold.it/69x70" alt="" title="">
                                        </div>
                                        <div class="author-meta">
                                            <p> Rooney </p>
                                            <span>CEO &amp; Founder - Dhoom Inc</span>
                                            <span class="author-rating rating-4"></span>
                                        </div>      -->   
                                    </div>
                                </li>
                                <li>
                                     <div class='dt-sc-testimonial'>
                                        <blockquote><q><?php echo $carouselValue; ?></q></blockquote>
                                       <!-- <div class='author'>
                                            <img src="http://placehold.it/69x70" alt="" title="">
                                        </div>
                                        <div class="author-meta">
                                            <p> Rooney </p>
                                            <span>CEO &amp; Founder - Dhoom Inc</span>
                                            <span class="author-rating rating-4"></span>
                                        </div>   -->      
                                    </div>
                                </li>
                            </ul>
                            <div class="carousel-arrows">   
                                <a href="#" class="testimonial-prev"><span class="fa fa-angle-left"></span></a> 
                                <a href="#" class="testimonial-next"><span class="fa fa-angle-right"></span></a>
                            </div>
                        </div>
                    </div>      
                    <!--dt-sc-one-half ends--> 
                    
                    <div class="dt-sc-hr"></div>
                    
                    <h2 class="dt-sc-hr-green-title">Our Sponsors</h2>
                    <!-- <div class="column dt-sc-one-fourth first">
                        <div class="dt-sc-team">    
                            <div class="image">
                                <img class="item-mask" src="images/mask.png" alt="" title="">
                                <img src="http://placehold.it/381x331" alt="" title="">
                                <div class="dt-sc-image-overlay">
                                    <a href="#" class="link"><span class="fa fa-link"></span></a>
                                    <a href="#" class="zoom"><span class="fa fa-search"></span></a>
                                </div>
                            </div>
                            <div class="team-details">
                                <h4> Jack Daniels </h4>
                                <h6> Senior Supervisor </h6>
                                <p> Phasellus lorem augue, vulputate vel orci id, ultricies aliquet risus. </p>
                            </div>
                        </div>
                    </div>
                    <div class="column dt-sc-one-fourth">
                        <div class="dt-sc-team">    
                            <div class="image">
                                <img class="item-mask" src="images/mask.png" alt="" title="">
                                <img src="http://placehold.it/381x331" alt="" title="">
                                <div class="dt-sc-image-overlay">
                                    <a href="#" class="link"><span class="fa fa-link"></span></a>
                                    <a href="#" class="zoom"><span class="fa fa-search"></span></a>
                                </div>
                            </div>
                            <div class="team-details">
                                <h4> Linda Glendell </h4>
                                <h6> Teaching Professor </h6>
                                <p> Phasellus lorem augue, vulputate vel orci id, ultricies aliquet risus. </p>
                            </div>
                        </div>
                    </div>
                    <div class="column dt-sc-one-fourth">
                        <div class="dt-sc-team">    
                            <div class="image">
                                <img class="item-mask" src="images/mask.png" alt="" title="">
                                <img src="http://placehold.it/381x331" alt="" title="">
                                <div class="dt-sc-image-overlay">
                                    <a href="#" class="link"><span class="fa fa-link"></span></a>
                                    <a href="#" class="zoom"><span class="fa fa-search"></span></a>
                                </div>
                            </div>
                            <div class="team-details">
                                <h4> Kate Dennings </h4>
                                <h6> Children Diet </h6>
                                <p> Phasellus lorem augue, vulputate vel orci id, ultricies aliquet risus. </p>
                            </div>
                        </div>
                    </div>
                    <div class="column dt-sc-one-fourth">
                        <div class="dt-sc-team">    
                            <div class="image">
                                <img class="item-mask" src="images/mask.png" alt="" title="">
                                <img src="http://placehold.it/381x331" alt="" title="">
                                <div class="dt-sc-image-overlay">
                                    <a href="#" class="link"><span class="fa fa-link"></span></a>
                                    <a href="#" class="zoom"><span class="fa fa-search"></span></a>
                                </div>
                            </div>
                            <div class="team-details">
                                <h4> Kristof Slinghot </h4>
                                <h6> Management </h6>
                                <p> Phasellus lorem augue, vulputate vel orci id, ultricies aliquet risus. </p>
                            </div>
                        </div>
                    </div> -->
                    
                    <!-- div class="dt-sc-hr"></div>
                    <h2>Our Sponsors</h2> -->
                    <div class="dt-sc-sponsor-carousel-wrapper">                    
                        <ul class="dt-sc-sponsor-carousel">
                            <li> <a href="" title=""> <img src="http://placehold.it/206x116" alt="" title=""> </a> </li>
                            <li> <a href="" title=""> <img src="http://placehold.it/206x116" alt="" title=""> </a> </li>
                            <li> <a href="" title=""> <img src="http://placehold.it/206x116" alt="" title=""> </a> </li>
                            <li> <a href="" title=""> <img src="http://placehold.it/206x116" alt="" title=""> </a> </li>
                            <li> <a href="" title=""> <img src="http://placehold.it/206x116" alt="" title=""> </a> </li>
                            <li> <a href="" title=""> <img src="http://placehold.it/206x116" alt="" title=""> </a> </li>
                        </ul>
                        
                        <div class="carousel-arrows">
                            <a class="sponsor-prev" href=""> </a>
                            <a class="sponsor-next" href=""> </a>
                        </div>
                    </div>
                    
                </section>
                <!--primary ends-->
            </div>
            <!--container ends-->
        </div>
        <!--main ends-->
        
<?php include('footer.php'); ?>